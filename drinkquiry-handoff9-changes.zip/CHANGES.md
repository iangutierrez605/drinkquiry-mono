# Changed files from this session — unzip over the repo root

## Session: site chrome + auth everywhere · winner takeover + answer pop · age gate · question lifecycle · admin user management · transactional email (Handoff #9 §F–§K)

**⚠️ Open item 1 — MIGRATIONS ARE NOT IN THE ZIP (by design).** This session
adds model fields (accounts.User.limit_overrides; trivia.Question.deleted_at
+ Question.replaced_by) but the generated migration files are deliberately
excluded per the deliverable box: after unzipping, run
`python manage.py makemigrations && python manage.py migrate` (in prod: run
makemigrations, commit the files, then deploy — the prod entrypoint only runs
`migrate`). All changes are additive (a defaulted JSONField, a nullable
DateTimeField, a nullable self-FK) — safe against the live database.

**⚠️ Open item 2 — compose runs (owner-run).** No Docker in this build
sandbox (same as #7/#8), so the environment-parity rule's compose runs
(suite + smoke through Postgres + Redis) are OWNER-RUN. Verified here
instead: the full suite 155 → **204 tests** green on the SQLite fallback;
`backend_smoke_test.py` (extended with §K's password flows) green TWICE
against a live local server on pristine seed (twice = the change-password
round-trip really is re-runnable); the library / revise / delete / users
endpoints additionally hand-exercised live with a staff account (revise
lineage visible in ?deleted=only, staff delete 200→409, users PATCH
round-trip, is_staff-in-body 400); `npm run build` clean.

**⚠️ Open item 3 — Resend / DNS / email verification (owner-run).** The
suite verifies email logic against Django's locmem backend and the live
smoke sees the console backend print real reset links; a REAL end-to-end
send can only be done by you:
1. Resend dashboard → add **drinkquiry.com** as a domain and create the
   SPF/DKIM DNS records it shows you. **No new API key is needed** — Resend
   keys are ACCOUNT-scoped; domains are verified per-domain within the
   account, so your existing eventquiry key sends for drinkquiry.com once
   the domain is verified.
   (Answering your question directly: sending `From: …@eventquiry.com`
   WOULD work today since that domain is already verified — but the
   from-domain vs link-domain mismatch (links point at drinkquiry.com)
   reads phishy to humans and spam filters. Fine as a brief stopgap by
   pointing DEFAULT_FROM_EMAIL at eventquiry.com; not recommended to keep.)
2. Prod `.env`: set `RESEND_API_KEY`, `DEFAULT_FROM_EMAIL`,
   `FRONTEND_BASE_URL` (all documented in .env.production.example, which
   this zip updates). Unset key = console backend (dev-safe default).
3. `docker compose build api` — requirements.txt gained **django-anymail**
   (the plain package; the Resend backend speaks HTTP via requests, no
   [resend] extra exists to install — verified against anymail 15.0,
   pinned `>=13`).
4. Run one real flow on prod (forgot-password to your own address is the
   easiest full round-trip).

### §F — Site chrome: SiteNav + auth everywhere

- **frontend/src/components/SiteNav.jsx (new):** wordmark→/, links Host /
  Make questions / Profile (+ Moderate only when the PROFILE says is_staff —
  cosmetic gate as always, per-token cached in module state), auth corner
  (signed out → "Log in" → /login; signed in → display name + Log out).
  Logout calls the real `/api/auth/logout/` (Knox revokes server-side,
  best-effort .catch), clears dq_auth, navigates home. Chalkboard-native:
  thin --line bottom border, --dim links hover --paper, active route --gold,
  wraps on mobile (no hamburger — the link count is small).
- **Where it renders:** App.jsx wraps a `ChromeLayout` (SiteNav + Outlet)
  around `/`, `/login`, `/reset-password`, `/host`, `/create`, `/moderate`,
  `/profile`. NOT on `/board/:code` (clean TV) and NOT on
  `/game/buzzer/:code`. **Delegated extension:** you said "except the game
  board"; the buzzer is excluded for the same reason (full-screen party
  surface for account-less guests). One-line revert: move its `<Route>`
  inside ChromeLayout in App.jsx. Note: the board route in the tree is
  `/board/:code` (the handoff doc said `/game/board/` — followed the tree).
- **Live auth state:** storage.js saveAuth/clearAuth now dispatch a
  `dq-auth-changed` window event; the nav (and each auth-gated page)
  listens, so a login from any inline AuthScreen or a logout from the nav
  updates everything instantly. api.js's dead-token cleanup now calls
  clearAuth() instead of a raw removeItem for the same reason.
- **frontend/src/components/AuthScreen.jsx (new; §F1):** extracted verbatim
  from HostPage.jsx (behavior identical), plus §K1's "Forgot password?"
  path. HostPage re-exports it (`export { default as AuthScreen } ...`) so
  any old import path keeps working; ProfilePage imports from the new home.
- **/login route (§F3):** renders AuthScreen; after auth navigates to
  `?next=` if present, else /host. /create and /moderate's "Go to login"
  buttons now point at `/login?next=…` instead of /host.
- **Header dedup (delegated call, flagged):** with the SiteNav carrying
  identity + cross-links + logout, the per-page pageheads on /host (create
  screen), /create, /moderate and /profile were REMOVED — one identity bar
  per page, not two stacked ones. The live host panel keeps its
  game-specific header (code chip, connection dot, board link, finish)
  minus the now-duplicate wordmark. /host and /profile keep their inline
  AuthScreen fallback exactly as before. The landing footer's
  Host/Make questions/Profile links were removed (same list as the nav
  directly above); wordmark + drink-responsibly line stay.

### §G — Board feel: winner takeover + the answer pops

Frontend-only, zero backend change — both features render snapshot fields
that already exist, so WS and polling boards get them identically (§C2).

- **G1 takeover (BoardPage):** when `current_cell.last_judgment.correct ===
  true`, a fixed full-screen overlay (chalkboard-dark, teal radial glow)
  takes the TV: "✔ CORRECT" eyebrow, the winner's NAME at
  clamp(56px, 13vw, 200px) in the display face — one line,
  nowrap/hidden/ellipsis at max-width 92vw (your call: truncation over
  shrink-to-fit), the revealed answer beneath it in the §G2 card, and the
  drink attribution line rendered LIVE on the overlay (the drink is
  assigned while it's up). Lifetime == the judgment marker's; #8's clearing
  semantics (close, reset, explicit reopen, next buzz, next cell) already
  cover every exit. WRONG keeps #8's red banner only — no takeover. Scale/
  fade entrance; the existing global prefers-reduced-motion kill-switch
  covers all new animations.
- **G2 answer card (BoardPage):** diagnosis per the handoff — the answer was
  big but competing. Fix by subtraction: while `revealed_answer != null`
  the question text, media and value chip drop to 0.25 opacity
  (`.tv__question--revealed`, CSS transition), and the answer moves into
  `.tv__answercard`: near-black rounded card, faint gold border,
  strengthened glow, small "THE ANSWER" eyebrow, ~200ms scale-in. Built as
  one reusable class — the same card renders inside the G1 takeover
  (slightly smaller text via a --takeover modifier) and for the host's
  explicit "nobody got it" reveal on the dimmed page. The old bare
  `.tv__answer` style is superseded on the board (class left in CSS,
  harmless).

### §H — Age gate

- **frontend/src/components/AgeGate.jsx (new):** rendered at the App level
  above ALL routes (buzzer and board included). Title "One thing first —",
  body "Drinkquiry is trivia with drinking-game references. Points mode is
  for everyone; drinks mode is for adults." Primary "I'm of legal drinking
  age" (autofocused; Escape does nothing — it must be answered), secondary
  "I'm not" → friendly decline note ("come back with the grown-ups, or ask
  your host to run points mode") with a back link. Permanent "Drink
  responsibly. 🍻" line on both paths. It's a good-faith notice and the copy
  doesn't pretend otherwise.
- **Persistence:** localStorage key **dq_age_ack_v1** (ISO timestamp) via
  new storage.js helpers loadAgeAck/saveAgeAck — versioned so a future copy
  change can re-prompt; confirmed once → never again on that browser.
- **Noted wrinkle:** on a TV/QR-scan flow the modal renders above the join
  screen once; first tap dismisses it and the join form is right there —
  acceptable friction, by design.

### §I — Question lifecycle: soft delete, versioned edits, admin library

- **Model (trivia/models.py):** `Question.deleted_at` (null = active; the
  ONLY liveness flag, no boolean twin) and `Question.replaced_by`
  (self-FK, SET_NULL, related_name="replaces") — the §I3 lineage pointer.
- **The absence audit** — every "active questions" surface now filters
  `deleted_at__isnull=True`, each pinned by its own test:
  `games/services.usable_questions` (game builds AND the §J3 replace pool),
  `Category.usable_question_count`, `QuestionViewSet.get_queryset` (public
  + owner listings; get_object routes through it, so a deleted question
  404s on retrieve/PATCH/DELETE/report), the moderation pending queue AND
  the counts badge (so the number matches the list), the flags list
  (belt-and-suspenders — delete/revise resolve flags themselves), the
  similarity candidate pool, and the bulk-upload duplicate check (deleting
  a question and re-uploading the same text works). **Audit finding beyond
  the handoff's list:** the QUOTA counters (accounts/quotas.questions_used
  and storage_bytes_used) also had to exclude deleted rows — otherwise a
  user who deletes everything stays at their limit forever, and the
  existing SMOKE_MEDIA cleanup's "quota freed" guarantee would silently
  break. Deliberate small mismatch, documented in the code: a deleted
  question's media FILES stay on disk/bucket (live snapshots of games
  containing it still serialize the media) but stop counting against
  storage quota. Deleted rows deliberately REMAIN in: board cells,
  snapshots, finished reports, game history, usage_count aggregates.
- **Owner delete (§I2):** QuestionViewSet.perform_destroy → soft delete,
  usual 204. Uniform rule, no never-played special case — this also makes
  the latent bug unreachable (BoardCell.question is PROTECT, so
  hard-deleting any ever-played question was a guaranteed ProtectedError
  500). Pinned: deleting a PLAYED question succeeds and the finished
  report still shows its text.
- **Staff delete (§I2):** POST /api/moderation/questions/<id>/delete/ —
  any owner's question; 409 if already deleted; resolves open flags (the
  report rows persist as history). Restore/un-delete punted (§M — the row
  is intact, cheap later).
- **Revise (§I3):** POST /api/moderation/questions/<id>/revise/ with any
  subset of {question_text, answer, difficulty (1–5), visibility}. One
  transaction: NEW row copying all fields + edits, same owner/category,
  media files kept BY NAME REFERENCE (two rows, ONE stored file — a future
  hard-purge must never delete files a replacement still references;
  media re-upload is §M); new row is **approved** (delegated default:
  staff edits don't re-enter their own queue — one line to flip to
  PENDING); old row soft-deleted + replaced_by set + open flags resolved.
  409 on already-deleted. Returns the new row (201) in the moderation
  serializer shape. **Games already built keep the OLD text** — cells
  point at the old row; a mid-game swap under players would be worse
  (stated in the docstring, pinned by test).
- **Library API (§I4):** ModerationQuestionViewSet.list grew:
  `?search=` (question_text OR answer icontains), `?category=<id>`,
  `?status=` gains the NEW value `all` (existing values and the queue's
  pending default untouched — C4-style additive), `?owner=` (email
  icontains; the value `official` → owner__isnull=True), `?deleted=`
  active(default)/only/all — the ONE staff surface where deleted rows are
  visible (serializer now carries deleted_at + replaced_by), `?ordering=`
  whitelisted to created_at/-created_at/usage_count/-usage_count (id
  tiebreak for deterministic pages), page_size 25 (LibraryPagination).
  Filters COMPOSE — the frontend always sends status=all for the library.
  Review actions (approve/reject) now 409 on a deleted question. The
  pending-queue default view is pinned unchanged by a dedicated test; the
  queue tabs' allPages just sees smaller pages (25 vs 50) and behaves
  identically.
- **Library UI (§I5):** fourth /moderate tab "Library" (staff chrome/toast
  plumbing reused, as prescribed). Debounced (~300ms) search with a
  stale-response sequence guard, selects for category/status/deleted/
  ordering (component state — URL-string state skipped as not "easy" in
  this tree, noted), compact rows (2-line-clamped text, answer, badges for
  status/deleted/superseded-by-#id, usage, owner, created/deleted date),
  prev/next + "page X of Y · N questions" from count. Per-row: Edit →
  inline ReviseForm → on 201 the row swaps to the NEW question with a
  toast; Delete → one-click inline confirm → deleted badge (409 from a
  racing reviewer handled). Deleted-only view is read-only. **The library
  fetch returns {results, count, next, previous} as-is via
  api.moderationLibrary — never allPages** (that helper stays for the
  small queue worklists).

### §J — Admin user management

- **Payments truth (stated in the UI, the module docstring, and here):**
  there is NO payment system in the codebase — nothing to "view". `plan`
  is hand-set. "Grant create access" and "override payment for a demo" are
  both plan=creator (a demo adds plan_expires_at — the existing expiry
  machinery lapses it to free automatically); "up their allowances" is the
  new per-user override. The Users tab shows plan + expiry + an explicit
  "billing: not wired yet — plans are set manually here" note. Stripe is
  §M.
- **§J1 — User.limit_overrides (JSONField, default dict):** same keys as a
  PLAN_LIMITS entry (games_per_month/categories/questions/storage_bytes),
  all optional; a key REPLACES the plan value; null = unlimited; missing =
  plan default. Wired in exactly ONE place — quotas.limits_for() does
  `dict(plan_base).update(overrides)` — so every quota check, every
  structured 403's `limit`, and the profile meters pick overrides up with
  no other change (pinned: boundary 403 carries the OVERRIDDEN limit).
  **Pinned as intended:** overrides apply to the EFFECTIVE plan's base,
  i.e. they survive a plan lapse — a grant to the USER, not the plan.
  Validation (quotas.validate_overrides, shared with the PATCH): known
  keys only, values null or int ≥ 0, bools rejected. Module docstring
  updated ("per-plan defaults + per-user JSON overrides").
- **§J2 — API (accounts/admin_api.py + admin_urls.py, new):** mounted at
  /api/moderation/users/ from config/urls.py BEFORE trivia's include
  (static-before-parameterized house rule; staff namespace stays uniform
  while the code lives with accounts). GET list: page_size 25, ?search=
  (email OR display_name icontains), ?plan=, ?is_staff=, -date_joined
  default; row = id/email/display_name/plan/**effective_plan** (so a
  lapsed demo is visible as creator-but-effectively-free)/plan_expires_at/
  is_staff/date_joined/limit_overrides + the usage block via
  quotas.usage() (a few COUNTs per row × 25 — fine, not prematurely
  optimized, per the handoff). PATCH <id>/: accepts plan/plan_expires_at/
  limit_overrides ONLY; **any other body field → 400** (the delegated
  ignored-or-400 pick: silently ignoring a privilege-looking field like
  is_staff would be worse than refusing; pinned). is_staff/email/password
  are NOT editable here — staff-granting stays in Django admin/shell so a
  compromised moderator account can't mint staff (docstring). Both
  endpoints IsAdminUser (non-staff 403 / anon 401 pinned).
- **§J3 — UI:** fifth /moderate tab "Users". Search + plan filter,
  paginated like the library. Row header: name/email, staff badge
  (read-only), plan chip with "(lapsed → free)" when expiry has passed, a
  "custom limits" badge when overrides exist. Expanded card: plan select +
  expiry date input with the demo recipe spelled out ("Demo access:
  creator + an expiry — it lapses to free automatically"); the four
  allowance fields as number inputs each with an "unlimited" checkbox
  (null) and the plan/effective limit as placeholder, current usage
  beside each; Save → PATCH → toast; the honest payments note.

### §K — Transactional email (Resend via Anymail)

- **Settings (env-driven, zero-code domain switch):** RESEND_API_KEY set →
  anymail Resend backend; unset → console backend (dev + local smoke; the
  suite uses Django's locmem regardless). DEFAULT_FROM_EMAIL (default
  "Drinkquiry <hello@drinkquiry.com>") and FRONTEND_BASE_URL (reset links;
  default the Vite dev origin). Three vars documented in
  .env.production.example with the full domain guidance (see Open item 3).
- **accounts/emails.py (new):** ONE send body (_send) — default from,
  catch-Exception, log a warning, never raise. **Sending never breaks the
  action** (pinned twice: a raising backend doesn't 500 approve, doesn't
  500 password-change). Plain text; HTML templates are §M.
- **§K1 forgot/reset:**
  POST /api/auth/password/forgot/ {email} — ALWAYS the identical 200 body
  whether or not the account exists (pinned, suite + smoke). Existing
  account → link `{FRONTEND_BASE_URL}/reset-password?uid=<b64 pk>&token=…`
  via Django's default_token_generator. Cooldown: per-user 60s via
  cache.add (atomic set-if-absent) — hitting it silently SKIPS THE SEND
  and never changes the body (enumeration again; pinned). Per-IP limiting
  is §M. POST /api/auth/password/reset/ {uid, token, new_password} —
  generic 400 on bad/expired token (never "no such user"), Django password
  validators, then **revokes EVERY Knox token** for the user (pinned: old
  token 401s). Frontend: "Forgot password?" on AuthScreen's login mode →
  tiny email form with always-success copy; new /reset-password route
  (ResetPasswordPage.jsx) reads uid/token from the query, new-password ×2
  form, success → /login.
- **§K2 change password:** POST /api/auth/password/change/
  {current_password, new_password} — Knox-authed; wrong current → 400;
  validators; keeps THIS request's AuthToken and deletes every other one;
  sends the "if this wasn't you…" notification (fail-silent). Frontend: a
  collapsible "Change password" panel on /profile (current + new + confirm,
  success toast).
- **§K3 approval notifications:** the queue's _act (approve AND reject) and
  the flag-resolve reject all call one helper,
  send_moderation_outcome_email(item, approved, actor). Approve: "Your
  {question|category} was approved" naming the item (+ category for
  questions). Reject includes the moderation note — **delegated default:**
  you asked for approved; reject-with-reason is the same hook and kinder
  than silence (one `else` branch to remove). Skips: owner is None
  (official) and actor == owner (staff self-review noise). All pinned
  (content, both skips, category flavor, flag-resolve path, raising
  backend).

### Tests & smoke (§L)

- Suite **155 → 204** (`python backend/manage.py test accounts trivia
  games`), all green on the SQLite fallback. New: the §I absence audit
  (one test per surface incl. the quota counters), destroy-on-played +
  report intact, revise lineage/validation/409s/media-by-reference/
  played-games-keep-old-text, library search/owner=official/deleted-only/
  ordering-whitelist/pagination-shape/25-page-size, pending-queue-default
  pinned, staff-only 403s, review-actions-409-on-deleted; §J limits_for
  merge semantics, overridden-boundary 403, profile meters,
  lapse-with-overrides, validate_overrides, users list/search/filters/
  PATCH round-trip/validation/is_staff-400/staff-only+anon; §K forgot
  parity + cooldown + token round-trip killing Knox + bad-token 400s +
  weak-password 400, change wrong-current/keeps-current-kills-others/
  notification/anon-401/raising-backend, §K3 email content + all skip
  rules + flag-resolve + raising-backend-on-approve.
- Smoke: §K4 additions only — password_flows() runs LAST (its second
  change revokes the run's original token, used by nothing afterwards):
  wrong-current 400 → change → current token survives + old password
  rejected → re-login with the new password → change BACK → original
  login works (RE-RUNNABLE, proven by running the whole smoke twice on
  one DB); forgot with the real smoke email vs a randomized ghost email →
  identical 200s (randomized so the cooldown can't diverge quick
  re-runs). No delivery assertions in smoke (console backend prints to
  the server log — verified the reset email + working link appears
  there). Full smoke green end-to-end on pristine seed_demo (the 5×5
  usable_question_count assumption is untouched by the soft-delete
  filters — verified live). Approval-email flows stay suite-only (smoke
  has no staff user by design — its non-staff 403 checks depend on that).

### Files

New: backend/accounts/admin_api.py, backend/accounts/admin_urls.py,
backend/accounts/emails.py, frontend/src/components/AuthScreen.jsx,
frontend/src/components/SiteNav.jsx, frontend/src/components/AgeGate.jsx,
frontend/src/pages/ResetPasswordPage.jsx.
Modified: backend/accounts/{models,quotas,views,urls,tests}.py,
backend/config/{settings,urls}.py, backend/games/services.py,
backend/trivia/{models,views,serializers,moderation,similarity,
bulk_upload,tests}.py, backend/requirements.txt (django-anymail — rebuild
the api image), backend_smoke_test.py, .env.production.example,
frontend/src/App.jsx, frontend/src/lib/{api,storage}.js,
frontend/src/pages/{BoardPage,HostPage,CreatePage,ModeratePage,
ProfilePage}.jsx (BuzzerPage untouched), frontend/src/styles.css,
CHANGES.md.
(Generated locally but NOT shipped: accounts/migrations/0003_user_limit_
overrides.py, trivia/migrations/0004_question_deleted_at_question_
replaced_by.py — see Open item 1.)


---

## Session: gameplay feel + drinks overhaul + board polish + content tooling (Handoff #8 §F–§K)

**⚠️ Open item 1 — MIGRATIONS ARE NOT IN THE ZIP (by design).** This session
adds model fields/tables (Game.judged_participant/judged_correct,
BoardCell.drinks_assigned, trivia.QuestionReport) but the generated migration
files are deliberately excluded per the handoff's deliverable box: after
unzipping, run `python manage.py makemigrations && python manage.py migrate`
(in prod: exec into the api container, or just `docker compose up -d --build`
AFTER makemigrations has produced the files and they're committed — the prod
entrypoint only runs `migrate`, it does NOT makemigrations). All changes are
additive (nullable FKs / defaulted bool / a new table), safe against the live
database.

**⚠️ Open item 2 — compose runs.** This session's environment had no Docker
(same as #7), so the environment-parity rule's compose runs (Django suite +
smoke through Postgres + Redis) are OWNER-RUN. Verified here instead: the
full suite 109 → **155 tests** green on the SQLite fallback;
`backend_smoke_test.py` (extended, see below) green end-to-end against a live
local server; every new endpoint additionally hand-exercised live (host-seat
token equality with the created game's token, board detail + replace with
no-duplicate assertion, flag 201→409 with status untouched); the frontend
builds clean with the one new dependency.

New files:
- backend/trivia/similarity.py — §K1 dependency-free near-duplicate ranking:
  normalize (casefold, strip punctuation, drop stopwords), Jaccard on the
  remaining significant words, candidates from the same category with a
  global fallback when the category pool is thin (< 5), top 5 returned with
  the §J1 usage count and the answer. A review AID only — nothing acts on it.
- (generated locally, NOT shipped): games/migrations/0004_*,
  trivia/migrations/0003_questionreport.py — regenerate on your side.

Backend (modified):
- backend/games/models.py — §F: Game.judged_participant (nullable FK,
  SET_NULL) + judged_correct (nullable bool), the persisted marker behind the
  snapshot's current_cell.last_judgment; clearing points documented on the
  field. §G: BoardCell.drinks_assigned (default False), the once-per-cell
  marker.
- backend/games/services.py — the big one. (1) §F judge_buzz moved here from
  the consumer: judging CORRECT now ALSO performs the reveal via the same
  _perform_reveal body the explicit reveal uses (rule 5: revealed_answer
  stays the only vehicle; no new answer path) and sets the judgment marker;
  judging WRONG sets the marker, does NOT reveal, and keeps the automatic
  buzzer reopen — which deliberately does NOT clear the marker (the "✘ WRONG"
  banner must be visible). Marker cleared at: open_cell, close_cell,
  reset_buzzer, EXPLICIT host open_buzzer, the NEXT buzz (a new team
  supersedes the old verdict on screen), finish_game; lock_buzzer keeps it.
  (2) §G assign_drink: single mutation for the player's give_drink and the
  host's assign_drinks fallback; validates drinks mode + judged-correct
  current cell + (for non-host actors) sender IS the winner; checks-and-sets
  drinks_assigned inside the row-locked transaction; second attempt raises
  StructuredActionError with the documented {"detail", "code":
  "drinks_already_assigned"} payload (lesson C4: exact shape). ANY seat is a
  valid target — host included — and self-assignment is allowed (comment
  marks the one-line forbid spot). The old host-path exclusion of the winner
  as a target is gone (owner-approved). Winner credit (drinks_given + score)
  unchanged. (3) §J2 draw preference: usable questions annotated with
  host_uses (cells in THIS host's games) + global_uses (all games), ordered
  difficulty → host_uses → global_uses → random. Difficulty stays the primary
  key (same difficulty-slot behavior; Python's stable sort preserves the
  preference within each difficulty), the 3× fetch window and the shortage
  400 contract are unchanged, and usage is DERIVED from the cells table — no
  counter columns (§J1 derive-first). (4) §J3 replace_cell_question:
  lobby-only single-cell redraw — same category, closest difficulty to the
  outgoing question (Abs(F(difficulty) − old)), §J2 preference order,
  excluding every question already on the board. (5) The remaining consumer
  bodies (register_buzz, set_buzzer, reset_buzzer) moved here too since §F
  changes them (marker clearing); behavior otherwise byte-identical,
  including the check ORDER in register_buzz (locked-check before the
  duplicate-buzz IntegrityError, as before).
- backend/games/consumers.py — thin database_sync_to_async wrappers around
  services for everything now; NEW player action give_drink
  {target_participant_id} handled BEFORE the host-only gate; assign_drinks
  routes into the same services.assign_drink; the error relay spreads a
  StructuredActionError's payload into the frame ({"type","detail","code"})
  while plain ActionErrors stay {"type","detail"} exactly as before. Header
  docstring updated. No reveal event is emitted on judge-correct — both
  frontends already prefer the snapshot's revealed_answer (§B4), and the
  judgment broadcast IS a snapshot.
- backend/games/serializers.py — OpenCellSerializer gains last_judgment
  ({participant_id, name, correct} | null; reads the root serializer's Game
  instance so no extra query in the nested case), drinks_assigned, and
  drink_assignment ({from/to ids+names, amount} | null; oldest assignment
  first so pre-#8 games that had host-spam duplicates show their first).
  Still deliberately NO question id in the open cell (an authenticated user
  could resolve an id to its answer via /api/questions/ — a rule-5 side
  door; noted in the docstring). New host-private BoardDetail* serializers
  (§J3): per-cell question_id + text + ANSWER + difficulty — the host's own
  board, never any part of a snapshot.
- backend/games/views.py — §H1: join name normalized .strip().upper() BEFORE
  the uniqueness/create logic, so the name-taken 400 and the IntegrityError
  race path both see the normalized value; rejoin is by token so pre-§H1
  mixed-case seats keep reclaiming (pinned by test). §I: GameHostSeatView
  (GET /api/games/<code>/host-seat/, Knox host-only → {participant,
  participant_token}) — the ONE new endpoint resume needed; history already
  listed unfinished games (no status filter) so it only gained a pinned test
  + docstring. §J3: GameBoardDetailView (GET .../board/, host-only) and
  CellReplaceView (POST .../cells/<id>/replace/, host-only; ActionErrors →
  plain {"detail"} 409: started / no-such-cell / nothing-left-to-swap). The
  snapshot view select_relates judged_participant (no N+1 for the marker).
- backend/games/urls.py — the three new routes.
- backend/trivia/models.py — §K2 QuestionReport (question FK, reporter FK,
  optional reason, status open/resolved, created_at) with a PARTIAL unique
  constraint: one OPEN report per (question, reporter) — the trivial rate
  limiter; once resolved the same host may flag again. Filing never touches
  moderation_status (the feature's explicit ask). Docstring documents what
  reject actually does to an approved question.
- backend/trivia/views.py — §K2 POST /api/questions/<id>/report/: any
  AUTHENTICATED host (get_permissions bypasses IsCreator for this action —
  flagging isn't content creation, so free-plan hosts can flag; visibility
  scoping still applies via get_queryset). Second open flag → 409 (pinned;
  the doc said pick 400 or 409 — 409 matches the moderation double-act
  guard's flavor). IntegrityError caught OUTSIDE the atomic block (house
  pattern).
- backend/trivia/serializers.py — §J1 _UsageCountMixin (annotation-first with
  a counting fallback) on both moderation serializers: questions = cells
  referencing it across all games; categories = board columns (unique per
  (game, category), so column count == game count). §K2
  FlaggedQuestionSerializer: the moderation question shape + open reports
  (reporter, reason, created_at) + report_count.
- backend/trivia/moderation.py — §J1 usage_count annotations in both
  viewset querysets. §K1 GET /api/moderation/questions/<id>/similar/ — a
  detail sub-endpoint (chosen over a `similar` block on the list serializer
  so the queue page stays snappy; the frontend fetches per card); works for
  any status so the Flagged tab reuses it. §K2 ModerationFlagsView (GET
  /api/moderation/flags/ — questions with open reports, oldest flag first,
  unpaginated worklist) + ModerationFlagResolveView (POST
  .../flags/<qid>/resolve/ {"action": "dismiss"} or {"action": "reject",
  "note": ...}; reject applies the SAME field semantics as the queue's
  reject — status=rejected + note, note required — and both resolve all open
  reports; resolving with nothing open → 409 mirroring the double-act
  guard). The pending queue's approve/reject endpoints are UNTOUCHED (still
  pending-only 409 — pinned by a new test); /api/moderation/counts/ keeps
  its exact pre-#8 shape (smoke asserts set(counts) == {categories,
  questions}) — the Flagged tab counts from its own list instead.
- backend/trivia/urls.py — the two flag routes (static, before the router).

Frontend (modified):
- frontend/package.json (+ package-lock.json) — ONE new dependency per the
  §H4 policy: qrcode.react (^4.2.0, tiny, maintained, renders SVG locally,
  zero network calls). Everything else is dep-free as before.
- frontend/src/lib/api.js — gameHostSeat, gameBoard, replaceCell,
  reportQuestion, moderationSimilar, moderationFlags, moderationFlagResolve.
- frontend/src/pages/BoardPage.jsx — §F: with a verdict present the board
  LEADS with a big "✔ CORRECT — TEAM" / "✘ WRONG — TEAM" banner
  (teal-gradient / chalk-red) and the revealed answer directly under it;
  while a verdict OR revealed answer is on screen the buzzer-lock chip is
  not rendered AT ALL (no green→red flash — the lock is implied) and the
  buzz list yields the floor. All derived from snapshot fields, so WS and
  polling boards behave identically (§B4) — zero hook changes. §G: drink
  attribution line ("TEAM A sends 1 drink to QUIZMASTER 🍺") from
  current_cell.drink_assignment; the footer drink tallies gain a labeled
  🎤 host row ONCE the host has taken a drink (chosen presentation: labeled
  row, drink displays only, never score displays — a permanent zero-row for
  the host read as noise). §H4: QR on the lobby (absolute buzzer URL from
  window.location.origin — never a hardcoded domain) on a white rounded
  tile with quiet-zone margin, sized to scan from a couch.
- frontend/src/pages/BuzzerPage.jsx — §H1: join input uppercases the VALUE
  in the change handler + .capsinput CSS (server normalizes again; cosmetic
  per rule 4). §F: verdict banner ("You got it! 🎉" / "Wrong — drink's
  coming 🍻" for the judged team, "X got it" / "X whiffed — buzz in!" for
  the rest) from last_judgment + own participant id. §G: when this seat IS
  the judged-correct winner and current_cell.drinks_assigned is false, a
  "Who drinks N 🍺? Your call." picker over ALL seats — themselves labeled
  "(us!)", the host labeled "(the host)" — sending the new give_drink
  action; once assigned, an attribution line ("… sends 1 🍺 to YOU — drink
  up!" when targeted). Enabled/disabled all snapshot-derived (rule 1).
- frontend/src/pages/HostPage.jsx — §G: the assign panel now leads with
  "THEIR phone picks who drinks" (the winner assigns; the host panel is the
  labeled fallback), targets ALL seats (winner "(the winners)", host
  "(you)"), hides once current_cell.drinks_assigned and shows the
  attribution + "one per question" note instead. §I: resumeHostGame()
  exported helper (host-seat fetch → saveSeat + saveHostGame) + a "Pick up
  where you left off" panel on the create screen listing unfinished games
  with Resume. §J3: LobbyPreview panel in the lobby — per-category
  expandable question lists from the host-private board detail (question +
  answer + value), per-row ↻ Replace (patches the returned cell in place;
  409s toast) and 🚩 flag. §K2: FlagButton (exported) also under the
  host-private answer card on the open cell — question_id comes from the
  §F1 answer endpoint's response (captured alongside the answer), NOT from
  the public snapshot. A host 409 on flag renders as already-done.
- frontend/src/pages/ProfilePage.jsx — §I: unfinished history rows get a
  ▶ Resume control (shared resumeHostGame, then navigate to /host where the
  normal connect flow reattaches).
- frontend/src/pages/ModeratePage.jsx — §K: third "Flagged" tab (own
  endpoint; tab count from the list length — counts/ shape untouched);
  FlaggedCard shows the question + answer + open reports with reporters and
  reasons + §J1 usage badge + §K1 lookalikes, resolved by "Dismiss flags
  (keep it)" or Reject-with-note whose UI copy documents the ACTUAL
  behavior ("unlists it from public categories and future game builds;
  games already built keep their copy"). §K1: SimilarMatches under every
  pending question card (per-card fetch; failure degrades to nothing —
  approve/reject never blocked). §J1: usage badges on question AND category
  cards.
- frontend/src/App.jsx — §H5: a real landing page. Hero keeps the join-code
  input as the undisputed #1 job (one screen-ish on mobile), new one-line
  pitch ("Bar trivia where the losers drink."), Host CTA, a three-step
  how-it-works strip (laptop → TV → phones), footer with nav + a wink.
- frontend/src/styles.css — §H2: .tv__answer scaled to clamp(44px, 7.5vw,
  96px) gold with glow (the star of the moment). §H3: .tv__joiner,
  .tv__score, .scorecard rebuilt as 3D chalk buttons (bigger radius,
  layered drop + inset shadows, subtle gradient; offline state gets a
  pressed-in inset so connected/offline still reads; buzz flash untouched).
  New: verdict banners (board + phone), drink picker/attribution styles, QR
  tile, resume rows, lobby preview list, flag/similar/usage styles, landing
  page sections. Token block untouched.

Tests (109 → 155):
- backend/games/tests.py — JudgmentFlowTests (judge-correct reveals WITH the
  judgment + marker shape; judge-wrong doesn't reveal and the marker
  SURVIVES the auto-reopen; clears at close/reset/explicit-reopen/next-buzz
  and next cell opens clean; lock keeps it; idempotent when host revealed
  first), DrinkAssignmentTests (winner-from-phone; second attempt BOTH
  paths → StructuredActionError with the exact 2-key payload; non-winner
  rejected; host fallback consumes the same marker; host-as-target;
  self-target; snapshot assigned+attribution shape; no drinks without a
  judged-correct current cell; points mode refused),
  JoinNameNormalizationTests (uppercased server-side; case variants collide
  → 400; pre-existing mixed-case seat rejoins by token → 200 name
  unchanged), ResumeTests (history flags lobby/active/finished; host-seat
  exact shape + token; rival 403 with no token leak; anon 401; unknown
  404), DrawPreferenceTests (next game avoids this host's used questions
  when alternatives exist; falls back to repeats when they don't; other
  hosts' usage only breaks ties; shortage message pinned verbatim; a USED
  easy question still beats an UNUSED hard one for the top row — difficulty
  slotting wins), BoardDetailAndReplaceTests (host sees questions+answers;
  rival 403/anon 401 with no SECRET- leak; replace picks the
  closest-difficulty spare and excludes the board; 409 when nothing left;
  409 after start; host-private). One pre-existing assertion updated for
  §H1 ("Team A" → "TEAM A" in the snapshot) — the only test the session
  changed rather than added.
- backend/trivia/tests.py — SimilarQuestionsTests (planted near-duplicate
  ranks first with usage_count + answer; never matches itself; staff-only;
  list carries usage_count after a real game references a question),
  QuestionFlagTests (free-plan host can flag; second open flag 409 pinned,
  different reporter fine; anon 401; flagging changes NOTHING — status,
  category listings, usable_questions all untouched; Flagged tab staff-only
  with report_count/reports/usage/answer; dismiss keeps + closes + re-flag
  possible + double-resolve 409; reject requires note, applies the queue's
  field semantics, unlists from public listing while a game can still hold
  the question; a flag does NOT make an approved question actionable in the
  pending queue — its 409 guard pinned).
- backend_smoke_test.py — extended per §L and re-verified green live:
  lowercase 'team a' joins come back 'TEAM A' and 'team b' hits the
  name-taken 400 (§H1; all downstream name assertions updated to caps);
  judge-wrong asserts the marker + answer-still-hidden; judge-correct
  asserts revealed_answer arrives WITH the judgment (the explicit reveal
  MOVED to after the judgment so this is actually proven — it still runs and
  still asserts the legacy answer_reveal event); the WINNING team's socket
  gives the drink TO THE HOST SEAT, attribution asserted; second attempt
  from the winner AND the host fallback both assert the exact
  {"type","detail","code":"drinks_already_assigned"} frame with tallies
  untouched; reconnect/report assertions follow the drink to the host row.
  Teams A/B keep playing to the finish exactly as before.

Decisions made (owner-approved via the handoff doc; each trivially
revertible):
- Judgment marker clearing points as listed above; "next buzz clears the old
  verdict" chosen so the board flips from "✘ WRONG — X" to the fresh buzz
  the instant another team is in.
- Drinks: once-per-cell as a BoardCell bool (serializes cleanest; the
  DrinkAssignment row is the attribution record); self-assignment allowed;
  host row appears in DRINK tallies only, labeled, only once nonzero.
- Flag re-file: 409 (not 400). Board-detail endpoint: host-only, any status
  (harmless host-private; the UI only surfaces it in the lobby). Lobby
  preview includes ANSWERS (host-private, same trust level as the §F1
  answer endpoint and the finished report — the host can't vet a question
  without its answer).
- counts/ endpoint shape unchanged; Flagged tab self-counts.

NOT done / carried to §M: forbid-self-drinks toggle (comment marks the
spot), auto-flag threshold, trigram/embedding similarity, per-question
quality stats, QR table tents — plus everything already in §M.

---

## Session: media hardening + player cap + production deploy + buzzer sounds (Handoff #7 §F/§G/§H/§I)

**⚠️ Open item — compose runs.** This session's environment had no Docker, so
the environment-parity rule's compose runs (Django suite + smoke through
Postgres + Redis) are STILL OWNER-RUN and remain the prerequisite before/while
following DEPLOY.md (its top box has the exact commands). Verified here
instead: the full suite (86 → **109 tests**) green AND warning-free with
warnings escalated to errors (the `UnorderedObjectListWarning` is fixed — see
below); `backend_smoke_test.py` green end-to-end against a live local server
in BOTH media modes (local disk, and s3 against a real S3-API server — moto);
the §F1 s3 path verified end-to-end (see below); the frontend builds clean.

New files:
- backend/trivia/images.py — §F2/§F3 shared implementation: header-only
  decompression-bomb guard (`check_image_pixels`, > 40 MP rejected BEFORE any
  full decode; PIL's own `MAX_IMAGE_PIXELS` backstop set at 2× so our check —
  not a nondeterministic Pillow warning inside DRF's image field — produces
  the reject message), `maybe_resize_image` (EXIF orientation FIRST via
  exif_transpose, downscale to ≤ 1920 px longest edge, JPEG q82 for photos /
  optimized PNG when alpha, EXIF stripped by re-encode, animated GIFs left
  byte-for-byte intact, PIL-unparseable files left alone — the fake-PNG test
  fixtures pin that), and `prepare_media`, the models' save()-time choke
  point: resize runs BEFORE the file hits storage (verified: the bucket only
  ever receives the resized object) and `media_bytes`/`photo_bytes` are
  recomputed post-resize. Targeted saves (moderation's update_fields) skip
  the recount — no storage round-trips per approval.
- backend/trivia/migrations/0002_category_photo_bytes_question_media_bytes.py
  and 0003_backfill_media_bytes.py — §F3 columns + best-effort backfill from
  existing files (missing files count 0, never crash).
- backend/games/migrations/0003_participant_buzzer_sound.py — §I field.
- frontend/src/lib/sounds.js — §I: 4 distinct sub-second WebAudio-synthesized
  buzzer voices (no audio files, no deps, no licensing); `ensureAudio()` for
  gesture-time unlock, `playBuzz(n)` used by both surfaces. Display-only.
- docker-compose.prod.yml, frontend/Dockerfile, Caddyfile,
  backend/entrypoint.prod.sh, .env.production.example, DEPLOY.md — §H, the
  production stack (see below).
- docker-compose.minio.yml — §F1 opt-in overlay: MinIO + api flipped to s3
  mode for local verification of the Spaces code path. NOT in the default dev
  compose. Browser note for signed URLs documented in the file.

Backend (modified):
- backend/config/settings.py — §F1 addendum: s3 OPTIONS also wire
  `location` from AWS_S3_LOCATION (optional key prefix for sharing one
  bucket between apps, e.g. eventquiry-prod/drinkquiry/...; empty = bucket
  root, the previous behavior). Verified end-to-end against the S3-API
  server: keys land under the prefix and signed URLs include it.
- backend/config/settings.py — §F2 limits: MAX_IMAGE_BYTES 5→10 MB (now the
  reject ceiling), MAX_AUDIO_BYTES 10→8 MB, MAX_VIDEO_BYTES 50→25 MB; new
  MAX_IMAGE_PIXELS (40 MP), IMAGE_RESIZE_THRESHOLD_BYTES (1 MB),
  IMAGE_MAX_DIMENSION (1920), IMAGE_JPEG_QUALITY (82).
  DATA_UPLOAD_MAX_MEMORY_SIZE 60→10 MB with the real semantics documented:
  per the Django docs it covers the NON-file body (multipart file data is
  excluded), so the true ceilings are the per-file validators, the bulk zip
  cap (200 MB in bulk_upload.py), and the reverse proxy. §F1: s3 OPTIONS now
  wire access_key/secret_key EXPLICITLY from env (AWS_S3_* or plain AWS_*
  names) instead of boto3's implicit discovery, plus querystring_expire
  (default 1 h; snapshot refetch cadence makes expiry a non-issue — noted in
  DEPLOY.md). §F3: PLAN_LIMITS gains "storage_bytes" (free 0, creator
  500 MB; None = unlimited; a MISSING key also reads unlimited so pre-§F3
  PLAN_LIMITS overrides in tests keep working). §G:
  MAX_PLAYERS_PER_GAME = 6. §H: SECURE_PROXY_SSL_HEADER behind
  DJANGO_BEHIND_PROXY (opt-in — trusting the header off-proxy would be
  spoofable), set true in the prod env template.
- backend/trivia/validators.py — validate_image additionally runs the §F2
  pixel guard when it holds a readable file (direct path); the bulk path runs
  the SAME check on the zip member stream. Error style unchanged (DRF field
  errors / bulk row errors).
- backend/trivia/models.py — photo_bytes / media_bytes columns; Category.save
  + Question.save call images.prepare_media — the ONE choke point both the
  serializer path and bulk create_rows funnel through.
- backend/trivia/bulk_upload.py — §F2: image members get the pixel guard via
  a lazy PIL open of the member stream (no full extraction), surfaced as the
  usual row error; §F3: ParseResult.media_bytes_total accumulates the
  uncompressed bytes of accepted media rows (per row, matching what
  create_rows stores) for the batch storage check.
- backend/trivia/views.py — FIX for the compose-run warning: the Question
  list queryset (the view that tripped UnorderedObjectListWarning) and the
  Category list queryset now end in .order_by("id"). Chosen over
  Meta.ordering deliberately: the list-view fix can't regress other callers
  (board building's explicit ordering, bulk dedupe, moderation). §F3:
  storage_quota_denial on category/question create AND update-with-file
  (conservative: a replaced file's old bytes count until the row saves), and
  batch_storage_quota_denial in bulk after the questions check (denial order:
  categories → questions → storage).
- backend/accounts/quotas.py — §F3: storage_bytes_used (Sum over the
  persisted columns — never lists a bucket; row deletion frees quota because
  the columns go with the row), usage() gains the "storage" block,
  storage_quota_denial / batch_storage_quota_denial through the same
  contract: payload numbers are raw BYTES in exactly
  {"detail","code":"quota_storage","used","limit"} (+"requested" bytes from
  the batch helper), human text formats MB. quota_denial/batch_quota_denial
  untouched — no keys added to the documented shape.
- backend/games/models.py — §I: Participant.buzzer_sound (1–4, default 1,
  display-only; host seat gets one, never plays it).
- backend/games/views.py — §G: join is now atomic — select_for_update() on
  the Game row, count role=player, at/over 6 → 409 with the NEW separate
  contract {"detail","code":"game_full","limit":6} via Response(payload, 409)
  (NOT the quota helpers). The locked queryset has no select_related (lesson
  C2). Rejoin-with-valid-token is checked BEFORE the cap → still 200 at a
  full table (reload flow pinned by tests + smoke). Name-taken 400 unchanged;
  the IntegrityError is caught OUTSIDE the atomic block so the rollback is
  clean. §I: buzzer_sound assigned in the same transaction,
  (player_count % 4) + 1.
- backend/games/serializers.py — ParticipantSerializer + buzzer_sound (in
  snapshot + join response); GameStateSerializer + top-level max_players from
  settings so lobby copy stays a dumb render (rule 1). Answer serialization
  untouched (rule 5).

Frontend (modified):
- frontend/src/pages/BuzzerPage.jsx — §G: joins detect code === "game_full"
  → friendly chalkboard "table's full, share a teammate's buzzer" screen
  (cosmetic; server is the gate), with reclaim-seat offered if a token is
  held. §I: buzz press plays the player's OWN sound (press = the autoplay
  gesture; instant feedback pre-round-trip); sound id from the snapshot self.
- frontend/src/pages/BoardPage.jsx — §I: 🔊 sound toggle (default OFF, no
  persistence; the click unlocks WebAudio). WS mode consumes the hook's
  existing lastBuzz (rule 2 — useGameSocket UNTOUCHED); polling mode extends
  the same buzz-count snapshot diff the flash already used to identify the
  newest buzz and play its team's sound (§B4's house technique). Sound id
  from the snapshot's participants; falls back to the buzz order if a stale
  backend omits the field. §G: lobby shows "N/6 teams" from max_players.
- frontend/src/pages/HostPage.jsx — lobby "Teams joined (N/6)" +
  table-full hint, both from the snapshot's max_players.
- frontend/src/pages/CreatePage.jsx — §F2 copy: image ≤ 10 MB (auto-resized),
  audio ≤ 8 MB, video ≤ 25 MB in MEDIA_LIMITS, the media type options, the
  photo hint, and the bulk panel hint. §F3: usage meters gain a storage line
  through the shared UsageMeterLine (bytes formatted where the entries are
  built — fmtMB local to the page — NOT inside the shared component; entry
  skipped against older backends without the block); quotaMessage() handles
  quota_storage incl. the batch "requested" (bytes → MB at the message).
- frontend/src/pages/ProfilePage.jsx — same storage meter line, same
  build-time formatting.
- frontend/src/styles.css — tv__teamcount + tv__soundtoggle (chalkboard
  token-friendly, additive only).
- frontend/src/components/shared.jsx, lib/api.js, lib/useGameSocket.js,
  lib/storage.js — UNTOUCHED (rules 2/3; quotaError already matches
  quota_storage via its quota_* prefix; mediaUrl's contract unchanged).

Production deploy (§H, all new files above):
- docker-compose.prod.yml: db (named volume, password REQUIRED via
  ${POSTGRES_PASSWORD:?}), redis, api (image is the code — no source bind
  mount, which is what makes git-pull-and-rebuild the deploy; entrypoint runs
  migrate + collectstatic --noinput then daphne; expose-only, no host port),
  web (Caddy; ports 80/443; cert volumes persist across rebuilds), restart
  policies on everything.
- frontend/Dockerfile: node:22 builds dist → COPIED into caddy:2-alpine
  (copy chosen over a shared volume: volumes serve stale files after
  rebuilds; the copy makes `up -d --build` ship every frontend change).
  Build context = repo root so the image takes the root Caddyfile too.
- Caddyfile: {$DOMAIN} from env → automatic Let's Encrypt; /api /ws /admin
  reverse-proxied to api:8000 (WS upgrade native); /static served from the
  collectstatic volume via file_server (DELIBERATE deviation from the
  handoff's "proxy /static to api:8000" line: Django doesn't serve static
  with DEBUG=false and the doc's own settings-check bullet says "static via
  collectstatic + Caddy"); /media served from the media volume in LOCAL mode
  and simply never matched in Spaces mode (documented in-file); SPA fallback
  try_files → index.html so /host, /profile, /board/CODE survive hard
  reloads.
- .env.production.example: EVERY required var with a comment — DOMAIN,
  DJANGO_SECRET_KEY (generate command included), DJANGO_DEBUG=false,
  DJANGO_ALLOWED_HOSTS (one entry; also gates wss Origins via
  AllowedHostsOriginValidator — same-origin, so one domain covers both),
  CSRF_TRUSTED_ORIGINS (admin logins), DJANGO_BEHIND_PROXY, POSTGRES_*,
  MEDIA_BACKEND + the full Spaces block, AWS_QUERYSTRING_EXPIRE.
- DEPLOY.md: droplet (Ubuntu 24.04, 2 GB) → DNS A record BEFORE first boot →
  ufw 22/80/443 → Docker install → clone → env → up -d --build →
  createsuperuser → seed/bulk content → 8-point verification checklist
  ending in prod smoke WITH the loud smoke-writes-data warning → the
  git-pull update workflow (incl. the one-line-change acceptance loop) →
  pg_dump cron backups (+ managed-Postgres note) → logs. Prerequisite box on
  top: the owner-run compose suite+smoke.

backend_smoke_test.py:
- Profile usage shape now includes "storage".
- After the reclaim check: asserts snapshot max_players == 6, joins Teams
  C–F, asserts the 7th join's 409 is EXACTLY {"detail","code","limit"} with
  game_full/6, asserts reclaim still 200 AT the cap, and asserts
  buzzer_sound in the snapshot with the 1,2,3,4,1,2 round-robin. The extra
  teams only prove the cap — the WS flow continues with Teams A/B unchanged
  (history's participant_count assertion updated 2 → 6 accordingly).
- OPT-IN media round-trip (SMOKE_MEDIA=1 + SMOKE_CREATOR_EMAIL/PASSWORD +
  pip install pillow): uploads a 2600 px photo through the API, asserts the
  URL fetches and the stored object is the resized one (≤ 1920 px, smaller
  than input), asserts signed bucket URLs when the media host differs from
  the app host (Spaces mode), then deletes the rows (frees §F3 quota).
  Default smoke still runs with zero setup. Verified green in BOTH modes
  this session (local disk; s3 via a moto S3 server).

§F1 verification performed this session (no Spaces credentials available; no
Docker for MinIO — used a moto S3-API server, same wire protocol): with
MEDIA_BACKEND=s3 + the explicit env credentials, an uploaded 2600×1400 photo
landed in the bucket under questions/images/, the serialized URL was absolute
and signed with an expiry, the UNSIGNED URL was denied (private ACL), and the
ONLY object ever stored was the already-resized file (11.7 KB vs the 58 KB
input) — resize-before-storage confirmed at the bucket. The owner re-proves
this against real DO Spaces via DEPLOY.md §5–§7 or docker-compose.minio.yml.

Tests (86 → 109, green and warning-free with -W error::RuntimeWarning):
- trivia.MediaProcessingTests (§F2): per-type oversize rejects on the direct
  path with the existing error surface; decompression-bomb fixture (64 MP,
  < 1 MB of bytes) → clean 400 on BOTH entrances, never an OOM; resize to
  ≤ 1920 px + smaller-than-input + JPEG re-encode + EXIF (incl. a GPS tag)
  stripped; EXIF Orientation=6 fixture transposed BEFORE the fit (portrait
  out); PNG-with-alpha stays PNG; small images stored byte-for-byte; the
  same resize through the bulk zip entrance. Existing oversize row-error test
  updated to the new 10 MB ceiling.
- trivia.StorageQuotaTests (§F3): counted from persisted post-resize sizes;
  single-file 403 in EXACTLY the documented shape; PATCH-with-file checked;
  batch 403 carries requested = total batch bytes; deletion frees quota;
  free plan reports storage 0 and is blocked by the questions quota first;
  category photos count.
- games.JoinCapAndSoundTests (§G/§I): 6th join 201, 7th → the exact 409
  shape (int limit — Response, not coerced exception detail); host seat
  excluded from the count; rejoin at cap → 200; name-taken 400 unchanged;
  max_players in the snapshot; round-robin 1,2,3,4,1; buzzer_sound in
  snapshot participants (host seat included) and the join response.

Also:
- .gitignore: + frontend/node_modules/, frontend/dist/ (droplet/build
  hygiene; docker builds them inside the image anyway).

Punted / carried forward additions: SMOKE_MEDIA leaves no rows (it cleans
up), but the media FILES it stores are not deleted (Django never deletes
storage on row delete) — folds into the existing "smoke cleanup pass" item.
Stale media_bytes if a PATCH clears a file via update_fields-less partial
edits is prevented (full saves recount), but a hypothetical
save(update_fields=...) with a fresh file from new code would need
media_bytes added to update_fields — documented in images.prepare_media.


## Session: host-private answers + reveal-for-polling-boards + game history/profile (Handoff #6 §F/§G/§H)

Backend (new):
- backend/games/tests.py — NEW suite (27 tests): the games app's first regression
  gate. §F1 answer endpoint (shape, host-only 403, anon 401, no-cell 409, 404),
  §F2/rule-5 money tests (snapshot `revealed_answer` null → answer → null across
  close and the next opened cell, with the answer string asserted absent from the
  ENTIRE serialized pre-reveal payload), §G1 outcomes (finished_at + winners, tie
  stores all, drinks-mode reading, abandoned games, idempotent finish, finish
  clears reveal), §G2 history (requester-scoped, newest-first, paginated,
  "history" not swallowed by the code route) and report (401/403/404, the pinned
  409-until-finished rule, finished report full detail with answers).
- backend/games/migrations/0002_game_answer_revealed_game_winners.py — adds
  Game.answer_revealed (bool) and Game.winners (M2M → Participant).
- frontend/src/pages/ProfilePage.jsx — NEW /profile route (see Frontend below).

Backend (modified):
- backend/games/models.py — Game.answer_revealed: true only between reveal and
  close_cell (rule 5's one sanctioned snapshot path); Game.winners: outcome
  persisted once at finish, never derived on read; empty = abandoned or no
  players.
- backend/games/services.py — the four live mutations §F/§G touch moved here from
  the consumer (open_cell, reveal_answer, close_cell, finalize_game) so the test
  suite exercises exactly what the socket runs; ActionError moved along (consumer
  re-imports it). open_cell/close_cell now also clear answer_revealed.
  reveal_answer persists the flag and returns the answer text for the unchanged
  WS event; it fetches the cell separately from the locked game row (the
  select_for_update+select_related(nullable FK) Postgres foot-gun from CHANGES).
  finalize_game (§G1): sets finished_at, computes winners = highest `score` among
  role=player participants, ties included, idempotent on repeat finish.
  **Documented drinks-mode winner reading: `score` is the credit side — the
  consumer already adds cell.value to the correct answerer's score on
  assign_drinks ("drinks dealt double as the leaderboard"), so highest score ==
  most drinks dealt; drinks_taken is the penalty side and never decides the
  winner.** Pinned by test_drinks_mode_winner_is_highest_score_credits.
- backend/games/consumers.py — open_cell/close_cell/finish_game delegate to the
  services above (behavior identical + the reveal/winners additions);
  reveal_answer now persists Game.answer_revealed, sends the `answer_reveal`
  event EXACTLY as before (WS boards/hook untouched — §B4-style dual path), and
  then also falls through to the usual snapshot broadcast per the house
  persist-then-broadcast pattern.
- backend/games/serializers.py — GameStateSerializer gains top-level
  `revealed_answer` (SerializerMethodField: the open cell's answer iff
  answer_revealed, else null) — assembled at the snapshot, OpenCellSerializer
  untouched and still answer-free. New purpose-built read serializers, separate
  from the live-snapshot ones: GameHistorySerializer (code, mode, status,
  created_at, finished_at, winners as sorted names, participant_count = player
  seats — the host's control seat is not a team; fed by a view annotation),
  GameReportSerializer (+ ReportColumn/ReportQuestion: participants with final
  tallies, winners as {id, name} for highlight-by-id, and every cell WITH
  question_text + answer + answered_by_name/answered_correctly).
- backend/games/views.py — GameAnswerView: GET /api/games/{code}/answer/ (Knox;
  host-only 403 for any other Knox user, 409 when no cell is open, 404 unknown
  code; works pre-reveal — that's its point; returns {"question_id","answer"}).
  GameHistoryView: GET /api/games/history/ — requester's games, newest-first,
  DRF-paginated, player_count annotation. GameReportView: GET
  /api/games/{code}/report/ — 401 anon, 403 non-host, **chosen non-finished
  behavior: 409 until status == finished** (so a report can never exist for a
  live game and rule 5 can't be violated through it).
- backend/games/urls.py — games/history/ registered BEFORE games/<code>/ so the
  static path can't be swallowed by the code lookup (pinned by test);
  + games/<code>/answer/ and games/<code>/report/.
- backend/accounts/tests.py, backend/trivia/tests.py — docstring run commands
  updated to the canonical `python manage.py test accounts trivia games`.
- backend_smoke_test.py — after open_cell: §F1 round-trip (host 200 with exact
  shape, second Knox user 403, anon 401) and the pre-reveal polled snapshot
  asserted answer-free; after reveal: `revealed_answer` present in the polled
  snapshot (the polling-board path's first live coverage); after close_cell:
  gone again; after finish_game: /api/games/history/ shows the game with
  winners ["Team B"] + participant_count 2, its /report/ carries tallies,
  winners and every answer, and the free user's Knox token 403s on it (anon
  401). rest() now returns both Knox tokens to ws_flow.

Frontend:
- frontend/src/pages/ProfilePage.jsx — NEW /profile (§G3): Knox-gated with the
  SAME login screen as /host (imported AuthScreen, not forked; a 401 mid-visit
  falls back to it since api.js already clears dq_auth). Identity + plan panel
  from GET /api/auth/profile/ with the shared UsageMeterLine (games this month +
  content quotas); game history via allPages (newest-first): code, mode, date,
  status, winners, team count. Selecting a finished game loads its report:
  tallies sorted by score with winner rows highlighted by id, then the full
  board with every question's answer (teal chalk-hand). Non-finished games
  render a "no report — recorded at finish" note and are never fetched (the 409
  route). Chalkboard styling reusing panel/h2/footnote/final__*.
- frontend/src/pages/HostPage.jsx — AuthScreen exported for /profile; Profile
  link in the creation header next to ModerationLink; HostGame takes the Knox
  auth and, when the SNAPSHOT shows a newly opened cell (tracked by cell id —
  rule 1: display data only, all gating still snapshot-derived), fetches
  /answer/ and shows it in a visually distinct dashed-teal card labelled
  "Answer (only you see this)", hidden once the reveal happens (the gold room
  card takes over). Fetch failure keeps the panel fully usable: judging buttons
  live, WS reveal as fallback, inline Retry. Answers are tagged with their cell
  id so a slow response for a closed cell can never render; cleared on close.
  Reveal display + the Reveal-answer button now derive from the snapshot's
  `revealed_answer` with the hook's event value as fallback (hook untouched).
- frontend/src/pages/BoardPage.jsx — reveal derives from the snapshot's
  `revealed_answer` in BOTH transports (rule 1 done properly): polling boards
  finally show reveals; WS boards prefer the field and keep the event-driven
  value as a fallback for older backends, so nothing regresses. Buzzer ignores
  the field (unchanged).
- frontend/src/pages/CreatePage.jsx — meter formatting moved to the shared
  UsageMeterLine (UsageMeters is now a thin wrapper feeding live counts);
  Profile link added to the header.
- frontend/src/components/shared.jsx — ProfileLink; UsageMeterLine (single
  meter renderer for /create and /profile; entries {used, block, noun},
  limit null = unlimited, null used skipped).
- frontend/src/lib/api.js — gameAnswer / gameHistory (allPages) / gameReport.
- frontend/src/styles.css — .answercard--private (+ __err), profile classes
  (.idblock*, .planchip*, .history*, .historyrow*, .report*, .reportq*,
  .final__list--report); existing tokens/classes reused everywhere else.

Docs:
- README.md + prior imperative "Run" lines in this file — canonical test
  command is now `python manage.py test accounts trivia games` (historical
  "Verified:" lines record what was actually run then and are unchanged).

Contracts unchanged (deliberately): OpenCellSerializer still excludes `answer`;
the WS `answer_reveal` event payload is byte-identical; useGameSocket untouched
(rule 2); storage/token contract untouched; quota payloads untouched.

Verified: `python manage.py test accounts trivia games` = 86 tests
(13 accounts + 46 trivia + 27 games) green and the FULL extended smoke suite
green (including the new §F1/§F2/§G live checks), both on the local fallback
(SQLite + in-memory channels). Frontend builds clean (`vite build`).
**⚠️ Compose parity (Postgres + Redis) — including the Handoff #5 backlog — was
NOT run this session: no Docker in the build environment. It remains the open
item from Handoff #5 §C and must be run per the environment-parity rule before
calling this done** (`docker compose cp backend_smoke_test.py api:/tmp/ &&
docker compose exec api sh -c "pip install requests websockets && python
/tmp/backend_smoke_test.py"` after `python manage.py test accounts trivia games`
inside the api container).

Still open / punted (carried forward from Handoff #6 §I): deleting/archiving
hosted games from /profile; player-side history (waits for participant
accounts); everything else in §I unchanged.

## Session: moderation review queue (Handoff #4 §F) + bulk question upload (§G)

Backend (new):
- backend/trivia/moderation.py — staff-only review API (all IsAdminUser):
  GET /api/moderation/{categories,questions}/ (paginated, oldest-first, ?status=
  filter defaulting to pending; detail lookups see every status so double-acting →
  409, not 404), POST …/{id}/approve/ (clears any stale note) and …/{id}/reject/
  (requires non-empty {"note"} → 400 without; writes moderation_note), and
  GET /api/moderation/counts/ for the nav badge. Approving a category does NOT
  touch its questions — every item is vetted separately.
- backend/trivia/bulk_upload.py — CSV parsing/validation for the bulk importer:
  UTF-8 (BOM tolerated), required header, ≤500 rows / ≤1 MB, row numbers 1-based
  including the header and counted by CSV *record* (multi-line quoted cells don't
  skew them), category matched by name (exact then case-insensitive; own > official
  > public precedence, ambiguity → row error), duplicate detection by
  (category, question_text) per owner including intra-file repeats.
- backend/trivia/tests.py — NEW suite (25 tests): every §H case for both features.
  Run `python manage.py test accounts trivia games` (inside compose for parity).

Backend (modified):
- backend/trivia/views.py — POST /api/questions/bulk/ action: parse/validate ALL
  rows, then all-or-nothing in one transaction; row errors → 400 {created: 0,
  errors: [{row, field, message}], skipped}; success → 201; dry_run → 200, nothing
  written; skip_duplicates default true (idempotent re-uploads); batch quota check
  (used + rows_to_create > limit → structured 403 + "requested"), applied on dry
  runs too; official=true is staff-only (else plain-detail 403) and creates
  owner-less public/approved quota-exempt rows against official categories only.
- backend/trivia/models.py — Category.accepts_questions_from(user): the shared
  "may add questions here" rule (official | own | publicly-visible), used by both
  QuestionSerializer.validate and the bulk importer instead of duplicating it.
- backend/trivia/serializers.py — validate() now calls the shared helper;
  ModerationCategorySerializer/ModerationQuestionSerializer add owner_email,
  owner_display_name (+ category_name for questions). Question `answer` stays in
  these — needed for review; OpenCellSerializer still excludes it from snapshots.
- backend/trivia/urls.py — moderation routes registered (counts path + router).
- backend/trivia/permissions.py — IsCreator lets the "bulk" action through like
  "create": the view's quota/staff checks govern it, so free users get the
  structured 403 and free-plan staff can still seed official content.
- backend/accounts/quotas.py — refactored through a shared _denial(user, kind,
  count); quota_denial() unchanged in shape, new batch_quota_denial() adds
  "requested" for bulk (denies when used + count > limit).
- backend/accounts/serializers.py — is_staff exposed read-only on the profile
  (the only accounts change; frontend gates /moderate on it cosmetically).
- backend_smoke_test.py — new live-surface checks: non-staff → 403 on
  /api/moderation/*, free-user bulk CSV dry-run → structured quota 403 with
  "requested", and an optional staff round-trip (reject-needs-note → approve →
  409 on repeat) when SMOKE_STAFF_EMAIL/SMOKE_STAFF_PASSWORD are exported.

Frontend:
- frontend/src/pages/ModeratePage.jsx — NEW /moderate route: tabs
  Categories/Questions with pending counts, cards oldest-first showing question,
  answer, difficulty, category, owner, visibility, and rendered media via
  mediaUrl() (img / audio / video controls); Approve, and Reject with an inline
  required note. Cards leave the list on action; a 409 (another reviewer got
  there first) drops the card and resyncs. Non-staff get a "Staff only" panel;
  plain REST + refresh, no WS.
- frontend/src/pages/CreatePage.jsx — "Bulk upload" panel below the question
  form: picking a file auto-runs a dry_run upload; results render as a summary
  line plus a row/column/problem error table; "Import N questions" does the real
  POST; "Download template" serves /question-template.csv; staff see an
  "Official content" checkbox (toggling re-runs the dry run, since official
  matches official categories only). quotaMessage() now uses "requested"
  ("This file has 60 questions but your plan has 40 left"). Shell shows the
  staff moderation link.
- frontend/src/components/shared.jsx — ModerationLink: /moderate link with the
  pending-count badge (rendered only when profile.is_staff — cosmetic; the
  server enforces IsAdminUser).
- frontend/src/lib/api.js — bulkQuestions, moderationCounts/List/Approve/Reject.
- frontend/src/pages/HostPage.jsx — CreateScreen keeps the full profile (games
  meter derived as before) and shows the moderation link for staff.
- frontend/src/App.jsx — /moderate route.
- frontend/src/styles.css — .pendingbadge, .modcard*, .bulkerrors table,
  .bulksummary, .bulkofficial (chalkboard tokens throughout).
- frontend/public/question-template.csv — NEW downloadable template.

Verified: `python manage.py test accounts trivia` (38 tests) green;
backend_smoke_test.py fully green against a live server including the staff
round-trip branch; §J steps 2–6 walked at the API level (bad-row 400 → fix →
dry-run → import → duplicate skip → moderate reject-with-note visible to owner
→ official upload usable instantly and quota-exempt → non-staff 403).
Still on you per §C/§J: the same two commands through docker compose
(Postgres + Redis), and the §J.1 realtime walkthrough (nothing realtime was
touched, but verify anyway).

---

## Session: paid tiers (Handoff #3 §D) + optional contract repairs (§E)

Backend:
- backend/accounts/models.py — `is_creator` column replaced by `plan` (free/creator) +
  `plan_expires_at`; `is_creator`/`effective_plan` are derived properties (expiry in the
  past collapses to free), so IsCreator and the profile serializer needed no call-site changes.
- backend/accounts/migrations/0002_plan_fields.py — adds fields, backfills
  plan="creator" where is_creator was true, drops the old column (reversible).
- backend/accounts/quotas.py — NEW: all quota counting + the structured 403 payload
  ({detail, code: "quota_*", used, limit}). Views return it via Response(…, 403) rather
  than PermissionDenied(dict) because DRF coerces ints/None in detail dicts to strings.
- backend/config/settings.py — PLAN_LIMITS. Product decision: free games_per_month is
  None (hosting stays ungated, as today); set a number to enable free game limits —
  enforcement/profile/frontend already handle it. Creator: 25 categories / 500 questions.
- backend/trivia/permissions.py — IsCreator is a plan check. POSTs pass through to the
  view's quota gate (free limits are 0), so free users get the structured quota 403;
  updates/deletes still require an active paid plan (plain 403), as before.
- backend/trivia/views.py, backend/games/views.py — quota gates on category/question/game
  creation, checked before validation/uploads.
- backend/accounts/serializers.py — profile now returns plan (the *effective* plan, so
  clients never do expiry math), plan_expires_at, and the usage block from the handoff.
- backend/accounts/admin.py — plan + plan_expires_at editable/filterable; this is the
  manual grant flow now (replaces "tick is_creator"). Derived boolean shown read-only.
- backend/games/consumers.py — §E1: invalid WS token is now accept-then-close 4001
  (was handshake 403 → browser 1006); §E2: incremental {type:"buzz", participant_id,
  name, order} emitted before each post-buzz snapshot. Frontend fallbacks untouched.
- backend/accounts/tests.py — NEW: 13 tests for §D6 (quota shapes, tiny-limit
  boundaries via override_settings, expiry-as-free, profile usage accuracy).
  Run: python manage.py test accounts trivia games

Frontend:
- frontend/src/lib/api.js — quotaError() helper for the structured quota 403s.
- frontend/src/pages/CreatePage.jsx — gate is plan !== "free" (upsell copy unchanged);
  usage meters ("2 of 25 categories · 41 of 500 questions", live counts from the loaded
  lists); quota 403s get friendly limit/upsell copy, other 403s keep the old path.
- frontend/src/pages/HostPage.jsx — creation screen shows "N of M games left this month"
  only when a limit applies (nothing today); quota_games 403 → upgrade copy.

Tests/docs:
- backend_smoke_test.py — new checks: profile shape (D3), free-user structured quota
  403, §E1 close-code 4001 (replaces the handshake-403 assertion), §E2 buzz event.
  Quota *boundaries* live in the Django suite, not here, so repeat runs never trip limits.
- README.md — monetisation section rewritten for the plan model + admin grant flow.

Verified: python manage.py test accounts (13/13) and the full smoke suite green against
a live server. Env-parity note: this session's changes are plain count queries + one
consumer event (no locking/select_related changes), but per the standing rule, run the
suite once through docker compose (Postgres + Redis) before shipping.

---

## Previous session

Backend (two fixes, both verified on real Postgres 16 + Redis):
- backend/games/consumers.py — judge/assign_drinks/close_cell used
  select_for_update().select_related("current_cell"); Postgres rejects FOR UPDATE on the
  nullable side of an outer join, crashing the consumer mid-action (SQLite masked it).
  select_related removed from the three locking queries; semantics unchanged.
- backend/requirements.txt — pins redis>=4.6,<8 (redis-py 8 crashes channels-redis
  consumers after ~20s idle: "Timeout reading from redis:6379").

Apply both with: docker compose up --build

New:
- HANDOFF_3.md — next-chat handoff: both production incidents + environment-parity rule,
  frontend socket-lifecycle fix, paid-tier spec, remaining items, smoke tests
- frontend/src/pages/CreatePage.jsx — creator content UI (/create)
- backend_smoke_test.py — automated REST+WS end-to-end test (point DATABASE_URL/REDIS_URL
  at real services for production parity)

Modified (frontend):
- frontend/src/lib/useGameSocket.js — REWRITTEN: single-socket lifecycle, invalid-token
  detection (rejected-handshake + REST probe), lastBuzz from snapshot diffs
- frontend/src/pages/HostPage.jsx — "Your content" link; "Reconnecting — controls paused"
  banner whenever the socket is down
- frontend/src/lib/api.js — allPages() pagination, content update/delete helpers,
  401 clears stored Knox auth
- frontend/src/App.jsx — /create route; landing join-code validation
- frontend/src/styles.css — chalkboard restyle + /create styles + reconnect banner
- frontend/index.html — Bebas Neue + Caveat fonts; theme-color
- frontend/README.md — backend deviations, /create docs

After unzipping: docker compose up --build
Then: cd frontend && npm install && npm run dev
