"""Paid-tier tests (Handoff #3 §D6).

Run: `python manage.py test accounts trivia games`
Works against SQLite or, with DATABASE_URL set, real Postgres — quota logic is
plain counting, but running it once through Postgres before shipping keeps the
environment-parity rule honest.
"""
from datetime import timedelta

from django.test import override_settings
from django.utils import timezone
from rest_framework.test import APITestCase

from accounts.models import User
from trivia.models import Category, ModerationStatus, Question, Visibility

TINY_LIMITS = {
    "free": {"games_per_month": 2, "categories": 0, "questions": 0},
    "creator": {"games_per_month": None, "categories": 2, "questions": 3},
}


def make_official_category(name="Movies", questions=3):
    cat = Category.objects.create(
        owner=None, name=name, visibility=Visibility.PUBLIC, moderation_status=ModerationStatus.APPROVED
    )
    for i in range(questions):
        Question.objects.create(
            category=cat,
            owner=None,
            question_text=f"Q{i}?",
            answer=f"A{i}",
            difficulty=(i % 5) + 1,
            visibility=Visibility.PUBLIC,
            moderation_status=ModerationStatus.APPROVED,
        )
    return cat


class QuotaTestBase(APITestCase):
    def setUp(self):
        self.free = User.objects.create_user("free@test.com", "sturdy-pass-123", display_name="Free")
        self.paid = User.objects.create_user(
            "paid@test.com", "sturdy-pass-123", display_name="Paid", plan="creator"
        )

    def auth(self, user):
        self.client.force_authenticate(user=user)

    def create_category(self, name):
        return self.client.post("/api/categories/", {"name": name, "visibility": "private"})

    def create_question(self, category_id, text="What?"):
        return self.client.post(
            "/api/questions/",
            {
                "category": category_id,
                "question_text": text,
                "answer": "That",
                "difficulty": 2,
                "media_type": "none",
                "visibility": "private",
            },
        )

    def assert_quota_403(self, response, code, used, limit):
        self.assertEqual(response.status_code, 403, response.content)
        body = response.json()
        self.assertEqual(body["code"], code)
        self.assertEqual(body["used"], used)
        self.assertEqual(body["limit"], limit)
        self.assertIn("detail", body)


class ContentQuotaTests(QuotaTestBase):
    def test_free_user_blocked_with_quota_shaped_403(self):
        self.auth(self.free)
        r = self.create_category("Nope")
        self.assert_quota_403(r, "quota_categories", used=0, limit=0)

        official = make_official_category()
        r = self.create_question(official.id)
        self.assert_quota_403(r, "quota_questions", used=0, limit=0)

    def test_creator_within_limits_succeeds(self):
        self.auth(self.paid)
        r = self.create_category("Mine")
        self.assertEqual(r.status_code, 201, r.content)
        r = self.create_question(r.json()["id"])
        self.assertEqual(r.status_code, 201, r.content)

    @override_settings(PLAN_LIMITS=TINY_LIMITS)
    def test_category_limit_boundary(self):
        self.auth(self.paid)
        self.assertEqual(self.create_category("One").status_code, 201)
        self.assertEqual(self.create_category("Two").status_code, 201)
        self.assert_quota_403(self.create_category("Three"), "quota_categories", used=2, limit=2)

    @override_settings(PLAN_LIMITS=TINY_LIMITS)
    def test_question_limit_boundary(self):
        self.auth(self.paid)
        cat_id = self.create_category("Mine").json()["id"]
        for i in range(3):
            self.assertEqual(self.create_question(cat_id, f"Q{i}?").status_code, 201)
        self.assert_quota_403(self.create_question(cat_id, "Q3?"), "quota_questions", used=3, limit=3)

    def test_expired_plan_behaves_as_free(self):
        self.paid.plan_expires_at = timezone.now() - timedelta(days=1)
        self.paid.save()
        self.assertFalse(self.paid.is_creator)
        self.auth(self.paid)
        self.assert_quota_403(self.create_category("Late"), "quota_categories", used=0, limit=0)

    def test_unexpired_plan_still_creator(self):
        self.paid.plan_expires_at = timezone.now() + timedelta(days=30)
        self.paid.save()
        self.assertTrue(self.paid.is_creator)
        self.auth(self.paid)
        self.assertEqual(self.create_category("On time").status_code, 201)

    def test_downgraded_user_cannot_edit_but_error_is_not_quota_shaped(self):
        # Writes other than create still go through the plain IsCreator gate.
        self.auth(self.paid)
        cat_id = self.create_category("Mine").json()["id"]
        self.paid.plan = "free"
        self.paid.save()
        self.auth(self.paid)
        r = self.client.patch(f"/api/categories/{cat_id}/", {"description": "edit"})
        self.assertEqual(r.status_code, 403)
        self.assertNotIn("code", r.json())


class GameQuotaTests(QuotaTestBase):
    def setUp(self):
        super().setUp()
        self.official = make_official_category(questions=3)

    def create_game(self):
        return self.client.post(
            "/api/games/",
            {"mode": "drinks", "categories": [self.official.id], "questions_per_category": 1},
            format="json",
        )

    def test_default_settings_leave_hosting_unlimited(self):
        self.auth(self.free)
        for _ in range(3):
            self.assertEqual(self.create_game().status_code, 201)

    @override_settings(PLAN_LIMITS=TINY_LIMITS)
    def test_game_limit_boundary_for_free(self):
        self.auth(self.free)
        self.assertEqual(self.create_game().status_code, 201)
        self.assertEqual(self.create_game().status_code, 201)
        self.assert_quota_403(self.create_game(), "quota_games", used=2, limit=2)

    @override_settings(PLAN_LIMITS=TINY_LIMITS)
    def test_creator_games_unlimited(self):
        self.auth(self.paid)
        for _ in range(3):
            self.assertEqual(self.create_game().status_code, 201)


class ProfileTests(QuotaTestBase):
    @override_settings(PLAN_LIMITS=TINY_LIMITS)
    def test_profile_usage_matches_reality(self):
        self.auth(self.paid)
        cat_id = self.create_category("Mine").json()["id"]
        self.create_question(cat_id)
        official = make_official_category(questions=3)
        self.client.post(
            "/api/games/",
            {"mode": "drinks", "categories": [official.id], "questions_per_category": 1},
            format="json",
        )
        p = self.client.get("/api/auth/profile/").json()
        self.assertEqual(p["plan"], "creator")
        self.assertIsNone(p["plan_expires_at"])
        self.assertTrue(p["is_creator"])
        self.assertEqual(p["usage"]["categories"], {"used": 1, "limit": 2})
        self.assertEqual(p["usage"]["questions"], {"used": 1, "limit": 3})
        self.assertEqual(p["usage"]["games_this_month"], {"used": 1, "limit": None})

    def test_expired_plan_reports_free_with_free_limits(self):
        self.paid.plan_expires_at = timezone.now() - timedelta(days=1)
        self.paid.save()
        self.auth(self.paid)
        p = self.client.get("/api/auth/profile/").json()
        self.assertEqual(p["plan"], "free")
        self.assertFalse(p["is_creator"])
        self.assertEqual(p["usage"]["categories"]["limit"], 0)

    def test_free_profile_shape(self):
        self.auth(self.free)
        p = self.client.get("/api/auth/profile/").json()
        self.assertEqual(p["plan"], "free")
        self.assertFalse(p["is_creator"])
        self.assertEqual(p["usage"]["questions"], {"used": 0, "limit": 0})
        self.assertIsNone(p["usage"]["games_this_month"]["limit"])  # hosting ungated today


# ---------------------------------------------------------------------------
# Handoff #9 §J — per-user limit overrides + the staff user-management API
# ---------------------------------------------------------------------------

from unittest.mock import patch

from django.core import mail
from django.core.cache import cache

from accounts import quotas


@override_settings(PLAN_LIMITS=TINY_LIMITS)
class LimitOverrideTests(QuotaTestBase):
    def test_limits_for_merge_semantics(self):
        # replace / null-unlimited / fall-through, in one dict
        self.paid.limit_overrides = {"questions": 10, "categories": None}
        limits = quotas.limits_for(self.paid)
        self.assertEqual(limits["questions"], 10)          # replaced
        self.assertIsNone(limits["categories"])            # null = unlimited
        self.assertIsNone(limits["games_per_month"])       # missing key → plan default
        # untouched user: pure plan defaults
        self.assertEqual(quotas.limits_for(self.free)["categories"], 0)

    def test_free_user_with_override_hits_the_overridden_boundary(self):
        cat = make_official_category(questions=0)
        self.free.limit_overrides = {"questions": 2}
        self.free.save(update_fields=["limit_overrides"])
        self.auth(self.free)
        for i in range(2):
            self.assertEqual(self.create_question(cat.id, f"Q{i}?").status_code, 201)
        res = self.create_question(cat.id, "One too many?")
        # The structured 403 carries the OVERRIDDEN limit, not the plan's 0.
        self.assert_quota_403(res, "quota_questions", used=2, limit=2)

    def test_profile_usage_reflects_overrides(self):
        self.free.limit_overrides = {"questions": 7, "storage_bytes": None}
        self.free.save(update_fields=["limit_overrides"])
        self.auth(self.free)
        usage = self.client.get("/api/auth/profile/").data["usage"]
        self.assertEqual(usage["questions"]["limit"], 7)
        self.assertIsNone(usage["storage"]["limit"])
        self.assertEqual(usage["categories"]["limit"], 0)  # untouched key

    def test_overrides_survive_plan_lapse(self):
        """Pinned as intended (§J4): an override is a grant to the USER, not
        to the plan — it still applies after the paid plan lapses to free."""
        self.paid.plan_expires_at = timezone.now() - timedelta(days=1)
        self.paid.limit_overrides = {"questions": 5}
        self.paid.save(update_fields=["plan_expires_at", "limit_overrides"])
        self.assertEqual(self.paid.effective_plan, "free")
        limits = quotas.limits_for(self.paid)
        self.assertEqual(limits["questions"], 5)           # override on top of FREE base
        self.assertEqual(limits["categories"], 0)          # free's default, not creator's

    def test_validate_overrides(self):
        quotas.validate_overrides({"questions": 0, "storage_bytes": None})  # fine
        for bad in ({"bogus": 1}, {"questions": -1}, {"questions": True}, {"questions": "9"}, ["questions"]):
            with self.assertRaises(ValueError):
                quotas.validate_overrides(bad)


class AdminUserApiTests(QuotaTestBase):
    def setUp(self):
        super().setUp()
        self.staff = User.objects.create_user("staff@test.com", "sturdy-pass-123", is_staff=True)

    def test_staff_only(self):
        self.auth(self.free)
        self.assertEqual(self.client.get("/api/moderation/users/").status_code, 403)
        self.assertEqual(self.client.patch(f"/api/moderation/users/{self.free.id}/", {}).status_code, 403)
        self.client.force_authenticate(user=None)
        self.assertEqual(self.client.get("/api/moderation/users/").status_code, 401)
        self.assertEqual(self.client.patch(f"/api/moderation/users/{self.free.id}/", {}).status_code, 401)

    def test_list_shape_search_and_filters(self):
        self.auth(self.staff)
        res = self.client.get("/api/moderation/users/")
        self.assertEqual(res.status_code, 200)
        data = res.data
        self.assertTrue(set(data) >= {"results", "count", "next", "previous"})
        row = next(r for r in data["results"] if r["email"] == "paid@test.com")
        expected_keys = {
            "id", "email", "display_name", "plan", "effective_plan",
            "plan_expires_at", "is_staff", "date_joined", "limit_overrides", "usage",
        }
        self.assertEqual(set(row), expected_keys)
        self.assertEqual(set(row["usage"]), {"games_this_month", "categories", "questions", "storage"})
        # search by email fragment and by display name
        res = self.client.get("/api/moderation/users/?search=paid@")
        self.assertEqual([r["email"] for r in res.data["results"]], ["paid@test.com"])
        res = self.client.get("/api/moderation/users/?search=Free")
        self.assertEqual([r["email"] for r in res.data["results"]], ["free@test.com"])
        res = self.client.get("/api/moderation/users/?plan=creator")
        self.assertEqual({r["email"] for r in res.data["results"]}, {"paid@test.com"})
        res = self.client.get("/api/moderation/users/?is_staff=true")
        self.assertEqual({r["email"] for r in res.data["results"]}, {"staff@test.com"})
        self.assertEqual(self.client.get("/api/moderation/users/?plan=platinum").status_code, 400)

    def test_patch_round_trip(self):
        self.auth(self.staff)
        expiry = (timezone.now() + timedelta(days=14)).isoformat()
        res = self.client.patch(
            f"/api/moderation/users/{self.free.id}/",
            {"plan": "creator", "plan_expires_at": expiry, "limit_overrides": {"questions": 50}},
            format="json",
        )
        self.assertEqual(res.status_code, 200, res.content)
        self.assertEqual(res.data["plan"], "creator")
        self.assertEqual(res.data["effective_plan"], "creator")
        self.assertEqual(res.data["limit_overrides"], {"questions": 50})
        self.free.refresh_from_db()
        self.assertEqual(self.free.plan, "creator")
        self.assertEqual(self.free.limit_overrides, {"questions": 50})
        # a lapsed demo reads creator-but-effectively-free in the same row
        past = (timezone.now() - timedelta(days=1)).isoformat()
        res = self.client.patch(f"/api/moderation/users/{self.free.id}/",
                                {"plan_expires_at": past}, format="json")
        self.assertEqual(res.data["plan"], "creator")
        self.assertEqual(res.data["effective_plan"], "free")

    def test_patch_validation(self):
        self.auth(self.staff)
        url = f"/api/moderation/users/{self.free.id}/"
        # unknown override key / bad value → 400
        res = self.client.patch(url, {"limit_overrides": {"bogus": 1}}, format="json")
        self.assertEqual(res.status_code, 400)
        res = self.client.patch(url, {"limit_overrides": {"questions": -3}}, format="json")
        self.assertEqual(res.status_code, 400)
        res = self.client.patch(url, {"plan": "platinum"}, format="json")
        self.assertEqual(res.status_code, 400)
        # is_staff (or anything else) in the body → 400, pinned: silently
        # ignoring a privilege-looking field would be worse than refusing.
        res = self.client.patch(url, {"is_staff": True}, format="json")
        self.assertEqual(res.status_code, 400)
        self.free.refresh_from_db()
        self.assertFalse(self.free.is_staff)
        res = self.client.patch(url, {"email": "hijack@test.com"}, format="json")
        self.assertEqual(res.status_code, 400)


# ---------------------------------------------------------------------------
# Handoff #9 §K1/§K2 — password flows
# ---------------------------------------------------------------------------

from knox.models import AuthToken  # noqa: E402


class PasswordFlowTestBase(QuotaTestBase):
    def setUp(self):
        super().setUp()
        cache.clear()  # the forgot-cooldown must never leak between tests

    def knox_login(self, email, password):
        res = self.client.post("/api/auth/login/", {"email": email, "password": password})
        self.assertEqual(res.status_code, 200, res.content)
        return res.data["token"]

    def bearer(self, token):
        return {"HTTP_AUTHORIZATION": f"Token {token}"}


class ForgotPasswordTests(PasswordFlowTestBase):
    def test_identical_200s_for_existing_and_unknown_email(self):
        r1 = self.client.post("/api/auth/password/forgot/", {"email": "free@test.com"})
        r2 = self.client.post("/api/auth/password/forgot/", {"email": "nobody@test.com"})
        self.assertEqual(r1.status_code, 200)
        self.assertEqual(r2.status_code, 200)
        self.assertEqual(r1.data, r2.data)  # no enumeration
        self.assertEqual(len(mail.outbox), 1)  # one real send, zero for the ghost
        self.assertEqual(mail.outbox[0].to, ["free@test.com"])
        self.assertIn("/reset-password?uid=", mail.outbox[0].body)

    def test_cooldown_skips_the_send_silently(self):
        r1 = self.client.post("/api/auth/password/forgot/", {"email": "free@test.com"})
        r2 = self.client.post("/api/auth/password/forgot/", {"email": "free@test.com"})
        self.assertEqual(r1.data, r2.data)  # body identical either way
        self.assertEqual(len(mail.outbox), 1)  # second send skipped

    def test_token_round_trip_resets_and_kills_all_sessions(self):
        token = self.knox_login("free@test.com", "sturdy-pass-123")
        self.client.post("/api/auth/password/forgot/", {"email": "free@test.com"})
        body = mail.outbox[0].body
        query = body.split("/reset-password?")[1].split()[0]
        params = dict(pair.split("=", 1) for pair in query.split("&"))
        res = self.client.post("/api/auth/password/reset/",
                               {"uid": params["uid"], "token": params["token"],
                                "new_password": "fresh-pass-456"})
        self.assertEqual(res.status_code, 200, res.content)
        # every Knox session is dead
        self.assertEqual(self.client.get("/api/auth/profile/", **self.bearer(token)).status_code, 401)
        self.assertEqual(AuthToken.objects.filter(user=self.free).count(), 0)
        # old password out, new password in
        self.assertEqual(
            self.client.post("/api/auth/login/", {"email": "free@test.com", "password": "sturdy-pass-123"}).status_code,
            400,
        )
        self.knox_login("free@test.com", "fresh-pass-456")

    def test_bad_or_expired_token_400s_generically(self):
        self.client.post("/api/auth/password/forgot/", {"email": "free@test.com"})
        body = mail.outbox[0].body
        query = body.split("/reset-password?")[1].split()[0]
        params = dict(pair.split("=", 1) for pair in query.split("&"))
        res = self.client.post("/api/auth/password/reset/",
                               {"uid": params["uid"], "token": "garbage-token",
                                "new_password": "fresh-pass-456"})
        self.assertEqual(res.status_code, 400)
        self.assertNotIn("free@test.com", str(res.data))  # generic message
        res = self.client.post("/api/auth/password/reset/",
                               {"uid": "!!!!", "token": params["token"], "new_password": "fresh-pass-456"})
        self.assertEqual(res.status_code, 400)
        # weak password still rejected AFTER a valid token
        res = self.client.post("/api/auth/password/reset/",
                               {"uid": params["uid"], "token": params["token"], "new_password": "123"})
        self.assertEqual(res.status_code, 400)
        self.assertIn("new_password", res.data)


class ChangePasswordTests(PasswordFlowTestBase):
    def test_wrong_current_400(self):
        token = self.knox_login("free@test.com", "sturdy-pass-123")
        res = self.client.post("/api/auth/password/change/",
                               {"current_password": "wrong", "new_password": "fresh-pass-456"},
                               **self.bearer(token))
        self.assertEqual(res.status_code, 400)
        self.assertIn("current_password", res.data)
        self.assertEqual(len(mail.outbox), 0)

    def test_change_keeps_current_session_kills_others_and_notifies(self):
        token_here = self.knox_login("free@test.com", "sturdy-pass-123")
        token_elsewhere = self.knox_login("free@test.com", "sturdy-pass-123")
        res = self.client.post("/api/auth/password/change/",
                               {"current_password": "sturdy-pass-123", "new_password": "fresh-pass-456"},
                               **self.bearer(token_here))
        self.assertEqual(res.status_code, 200, res.content)
        self.assertEqual(self.client.get("/api/auth/profile/", **self.bearer(token_here)).status_code, 200)
        self.assertEqual(self.client.get("/api/auth/profile/", **self.bearer(token_elsewhere)).status_code, 401)
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("password was changed", mail.outbox[0].subject.lower() + mail.outbox[0].body.lower())
        self.knox_login("free@test.com", "fresh-pass-456")

    def test_anonymous_401(self):
        res = self.client.post("/api/auth/password/change/",
                               {"current_password": "x", "new_password": "y"})
        self.assertEqual(res.status_code, 401)

    def test_email_failure_never_breaks_the_change(self):
        token = self.knox_login("free@test.com", "sturdy-pass-123")
        with patch("accounts.emails.send_mail", side_effect=RuntimeError("ESP down")):
            res = self.client.post("/api/auth/password/change/",
                                   {"current_password": "sturdy-pass-123", "new_password": "fresh-pass-456"},
                                   **self.bearer(token))
        self.assertEqual(res.status_code, 200, res.content)
        self.knox_login("free@test.com", "fresh-pass-456")
