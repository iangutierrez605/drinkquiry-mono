# Changed files from this session — unzip over the repo root

## Session: HOTFIX #14b — prod connection exhaustion + the unhealthy healthcheck (incident of Aug 1, ~03:13)

**⚠️ Deploy runbook (in this order):**
1. **Recover NOW (no zip needed):**
   `docker compose -f docker-compose.prod.yml restart api` — instantly
   releases the leaked pile. Until the fix below is deployed it WILL
   recur under sustained clicking, so do steps 2–3 soon after.
2. **Ship the fix:** unzip this over the repo root, then
   `docker compose -f docker-compose.prod.yml up -d --build`.
3. **Fix the healthcheck env** on the droplet's `.env`:
   `DJANGO_ALLOWED_HOSTS=yourdomain.com,localhost` then
   `docker compose -f docker-compose.prod.yml up -d api`.
4. **Verify:** `docker compose -f docker-compose.prod.yml ps` shows api
   `(healthy)` — for the FIRST time ever; and while clicking around the
   app, `... exec db psql -U drinkquiry -c "select count(*) from
   pg_stat_activity;"` stays flat at a handful instead of climbing.
5. If the smoke ever partially ran against prod, also check for stray
   `host@test.com` / `free-…@test.com` users and "Smoke Cup …"
   tournaments (none exist if it was never pointed at the domain).

**The incident.** ~13 minutes after deploying #14 the owner's §N
walkthrough produced steady request traffic; at 03:13 Postgres refused new
connections (`FATAL: sorry, too many clients already`, default
max_connections=100) and unrelated endpoints started 500ing — observed at
the moderate → Categories click, but the captured 500 was
`/api/categories/public/` (the anon browse surface): global exhaustion,
not an endpoint bug. The moderate page did nothing wrong; it was request
~101.

**Root cause (pre-existing since the #7 prod stack, latent until a long
click-through):** `conn_max_age=600` under daphne. Persistent connections
are a WSGI-era feature — under ASGI every request runs its ORM work on
its own short-lived thread (`ThreadSensitiveContext`), so the thread-local
connection outlives its thread and is stranded for up to 10 minutes.
Every request leaked one connection. **Fix:** `conn_max_age` removed
(dj-database-url default 0 = connect per request, ~1ms on the compose
network), with a loud settings comment so no future session "optimizes"
it back. If pooling is ever actually wanted: Django's native psycopg pool
(`DATABASES OPTIONS {"pool": ...}` + `psycopg[binary,pool]`) — never
conn_max_age on ASGI.

**Companion bug (same log, different problem):** the api container's own
healthcheck probes `http://localhost:8000/api/health/`; prod
`DJANGO_ALLOWED_HOSTS` was domain-only, so every 30s probe 400'd with
`DisallowedHost` and the container has read **(unhealthy)** since #10
shipped the healthcheck — masked in dev because DEBUG=true wildcards
hosts. Fix is env + docs only: `.env.production.example` now ships
`…,localhost` with the rationale (port 8000 is expose-only, nothing
outside the docker network can present that Host — this widens nothing),
and DEPLOY.md §9b notes it beside its `(healthy)` promise.

**Files changed:** `backend/config/settings.py` (one line + comment),
`.env.production.example`, `DEPLOY.md`, `CHANGES.md`. **Zero migrations**
(`makemigrations --check` clean). Not related to the #14 restyle (CSS/
assets only) — the walkthrough it prompted merely exposed the latent leak.

**Gates, on the fixed tree:** full suite **350 tests OK** (with
`TURNSTILE_SECRET_KEY` set); `backend_smoke_test.py` green **TWICE**
(60/60 checks each, full tournament story, server restarted between
runs); zero migrations.

## Session: NIGHT MARKET — full visual re-theme, zero logic changes (Handoff #14)

**⚠️ Open item 1 — VISUAL ACCEPTANCE IS OWNER-RUN.** No browser in this
build sandbox, so visual QA here was disciplined CSS reading plus
programmatic gates: a WCAG contrast audit of every text/surface and
control pair in the new palette (**24/24 pass** — worst pair 5.99:1
blue-on-panel, most 6–17:1), zero stale tokens or palette hexes by grep,
and a clean `vite build`. The real acceptance is your §N walkthrough on
real hardware: host console, TV board from couch distance, phone buzzer
(all four states), verdicts, finale, tournament screens. One extra look:
the sandbox can't reach Google Fonts, so confirm **Archivo Black / Inter /
Shantell Sans** actually load (a bad fonts URL fails SILENTLY into system
fallbacks — check the network tab once).

**⚠️ Open item 2 — Turnstile build coupling (DEPLOY.md §5 + §8).** This
session rebuilds the frontend by definition. If `TURNSTILE_SECRET_KEY` is
set in prod, the rebuild must bake in `VITE_TURNSTILE_SITE_KEY` or
registration breaks. Same rule as #12/#13 — it just always rides a
frontend zip.

**⚠️ Open item 3 — compose parity pass (standing, C3).** No Docker in the
sandbox; run the suite + `backend_smoke_test.py` through Postgres + Redis
as usual. **ZERO migrations this session** (`makemigrations --check`
clean), so there are no new schema stakes — this is only the standing
carry-over (the four partial uniques + Redis throttle counters). Backups /
monitor items (DEPLOY.md §9/§9c) unchanged. Smoke replication note: the
full tournament story lights up only when `host@test.com` is a creator (I
pre-created + promoted it in the sandbox db; this zip does not touch your
db).

**The theme.** Night Market, per the style-directions file (option 1, the
file's default and its own recommendation): deep navy air with lantern
glows — neon mint, lantern blue, marquee lemon, coral. Fully replaces the
chalkboard identity (and with it the black+orange adjacency that started
this).

**Token mapping (old → new), all renames swept with exact-count checks:**
- `--ink` #232b26 → **#0d1622** page navy; `--ink-2` → **#0a111b**
  recessed wells (tournament round columns, buzzer rim); `--ink-3` →
  **#142232** panels/cards; NEW **`--ink-4` #1b2d40** for inputs, chips
  and cards ON panels. Depth language INVERTED on purpose: surfaces now
  layer LIGHTER as they rise (the demo's system), replacing the chalk
  "dark smudge" recesses. `--line` is a hairline rgba(190,223,225,.17);
  `--paper` #f4fbf8; `--dim` #aabdc8.
- `--gold` + `--teal` **MERGED → `--accent`** mint #4de2b1 (66 + 42 refs,
  zero stragglers). The theme demo itself sets success ≡ primary; mint now
  means values, wins, OPEN, CTAs, ok/live/correct, selected.
- `--pink` → **`--blue`** #6f9bff: the buzz EVENT (TV flash, buzz order
  numbers), drinks, and the host-private answer card.
- NEW **`--warn`** lemon #f4cf69: `.btn--gold` is now the MARQUEE flavor.
  It could NOT merge into mint — `btn--gold` and `btn--primary` co-occur
  on TournamentDetailPage — so the "money" actions took the lemon slot.
  Lemon also = pending/waiting badges, staff badge, paid plan chip.
- `--red` → coral #ff6f7d. NEW `--focus` #a8ffdf (3px ring, offset 3).
  NEW dark on-colors (`--onaccent/--onblue/--onwarn/--onred`) replace all
  17 hardcoded dark-text hexes.
- NEW ***-rgb channel triplets**: every glow/tint is now
  `rgba(var(--x-rgb), a)` — the palette lives in ONE place (C1). rgba was
  chosen over the demo's `color-mix()` deliberately: bar TVs run old
  embedded browsers; rgba is bulletproof.

**State language, preserved distinctions:** open = mint EVERYWHERE (cells,
buzzstate chip, and the buzzer — the old gold ball w/ orange border is now
a glowing mint orb); buzzed = paper; locked = coral stripes; verdicts
mint/coral with light gradient tops (#8ff0cf / #ffa3ab); the buzz event
and buzz order = blue. The #6 §F1 host-private answer card distinction is
re-expressed: room-facing = mint solid, private = blue DASHED.

**Fonts:** Bebas/Patrick Hand/Barlow → **Archivo Black** (the demo's
"Arial Black" register), **Shantell Sans** (keeps #11's upright,
single-story hand rule for ANSWERS), **Inter** (the demo's own body
stack), IBM Plex Mono unchanged. Inter is loaded at exactly the weights
the CSS uses (400/600/700/800). Wide-face fit retunes — brand/fit only,
the §F-protected gameplay clamps are untouched: wordmark 34→30px +
tracking .14→.06em, hero clamp down, stepper value min-width 34→46,
`final__rank` 26→36px, `buzzover__title` clamp down (14vw Archivo
overflowed a 375px phone; it's a phone finale, not a §F TV surface).

**Texture:** chalk-dust radials → dual lantern radials (mint top-left,
blue top-right); 2px chalk borders → 1px hairlines; every irregular
hand-drawn radius → clean (16/14/12/10); `0 Npx 0` 3D chalk-button
shadows → soft floats; chalk text drop-shadows → neon glows. Dashed
borders KEPT only where dashing MEANS something: placeholder/empty
(`catcard--short`, `buzzlist--empty`, `roundcol--next`, `similar`,
`librow--deleted`, `removedbadge`, `drinkassign--done`), private
(`answercard--private`), dropzone (file input). The QR tile stays
#ffffff with its quiet zone (scannability); only the dark modules moved
#1e2621 → #0d1622 (`BoardPage.jsx` — the single JSX touch), hint text
#33414f on white (10.4:1). `favicon.svg` is the theme file's mark: mint
rounded square, dark serif lowercase "d" (the handoff comment explicitly
blesses keeping the d monogram). Identity header rewritten; comments that
now lied about color fixed; handoff citations preserved. No net-new CSS
rules, so no appended #14 section — everything edited in place per §G.

**Files changed:** `frontend/src/styles.css`, `frontend/index.html`,
`frontend/src/pages/BoardPage.jsx`, `frontend/public/favicon.svg`,
`CHANGES.md`. Zero backend files. Zero migrations.

**Gates, all from the final tree:** full suite **350 tests OK** run WITH
`TURNSTILE_SECRET_KEY` set (exercises the C16 TESTING guard);
`makemigrations --check` clean; `backend_smoke_test.py` green **TWICE**
back-to-back (60/60 checks each, FULL tournament story, server restarted
between runs so the C10 register counters reset); `vite build` clean
(45.1 kB CSS); WCAG contrast audit 24/24.

## Session: bigger TV branding · "Hi <name>" emails · host-owned per-game buzz sound · TOURNAMENT MODE v1 (Handoff #13 §F–§J)

**⚠️ Open item 1 — compose runs (owner-run, C3) — REAL schema rides on it
this time.** No Docker in this build sandbox, so the environment-parity
compose runs (suite + smoke through Postgres + Redis) are OWNER-RUN, and #13
adds actual stakes: TWO migrations (`games/0006`, `games/0007`) and the
**FOURTH house partial unique constraint** —
`unique_tournament_name_per_owner` on `(owner, name) WHERE deleted_at IS
NULL` — joining the category/theme/participant three, plus a plain unique on
advancer rows. SQLite accepts all of it (proof below); Postgres must be seen
accepting it once through compose. Standing carry-overs still ride along:
Redis-backed throttle counters + the forgot-password cooldown. Verified in
the sandbox instead: full suite 304 → **350 tests green**;
`backend_smoke_test.py` green **twice** end to end with the full tournament
story; `npm run build` clean (53 modules); the C9 pristine-tree migration
drill (item 2).

**⚠️ Open item 2 — MIGRATIONS ARE IN THE ZIP (0006 + 0007) + the forward
path is PROVEN.** `0006_game_buzz_sound` (one column, default 1);
`0007_...tournament...` (Tournament + TournamentAdvancer tables,
`Game.tournament` SET_NULL FK + `Game.round_number`, both constraints). C9
restart rule: dev `docker compose restart api` isn't enough when schema
changes — the prod deploy (`up -d --build`) migrates on start via the
entrypoint, dev needs `manage.py migrate` (or a compose rebuild) before the
new code runs. Forward-path drill done in-sandbox the honest way: a REAL
mid-play game was created on the PRISTINE (pre-#13, 0005-era) tree, its
`db.sqlite3` copied under this session's code, `migrate` applied 0006+0007,
and the old game then rendered exactly as before — `buzz_sound: 1` (the
migration default), `tournament: null`, mid-play state intact — while the
new tournament tables worked on the same db. Also reversed to `games 0005`
and forward again cleanly.

**⚠️ Open item 3 — Turnstile deployment coupling is now PROMINENT in
DEPLOY.md (§J1).** DEPLOY.md §5 gains a dedicated section: the THREE env
names in one table (`TURNSTILE_SECRET_KEY` — turns the feature on, verify
fails CLOSED; `TURNSTILE_SITE_KEY`; `VITE_TURNSTILE_SITE_KEY` — must be
baked into EVERY production frontend build), the one-directional failure
mode spelled out (secret set + a VITE-less rebuild = silent registration
breakage), and a reminder embedded in the §8 update workflow itself. Dev,
the suite and the smoke stay keyless (feature entirely absent). Bonus fix
while in there: **two leftover debug `print()`s from #12's register path
removed** (`accounts/views.py` printed "check turnstile" on every register
call, and one printed a function object rather than its value) — log noise,
no behavior change, register/turnstile tests green after.

**⚠️ #12 open item 4 (support@ mailbox) — RESOLVED, dropped from the carry
list.** The forward/alias exists per the handoff; the mailto surfaces
(footer, auth, 404, buzzer) now point at a real mailbox.

**⚠️ Open item 4 — backups + uptime remain owner-ops (carry).** Nightly
`pg_dump` + the media copy (or bucket versioning in Spaces mode) + a free
monitor on `GET /api/health/` — DEPLOY.md §9/§9c has the recipes. Nothing in
#13 changes this; it just stays true until acted on.

**⚠️ Open item 5 — the smoke's FULL tournament story needs a creator
account (zero-setup runs print a SKIP line).** Tournament creation is
plan-gated, and the smoke keeps its hard register budget (2 calls/run, NO
new accounts — §L), so the story is two-layered: the structured
`quota_tournaments` 403 plan-gate pin ALWAYS runs (on the guaranteed-free
account), and the full round-trip (create → attach → join → the pinned 409 →
WS finish → advance → detail) runs when `host@test.com` can create. Promote
it to creator in `/admin` (or grant it a `tournaments` limit override) and
the story lights up; until then the run stays green with a visible
`SKIP full tournament story` line — the same convention as the opt-in
`media_round_trip`. Re-runnable by construction: tournament names are
timestamped (`Smoke Cup <epoch>`), chosen over delete-at-end so the record
stays inspectable after a run.

### §F — the TV wears the venue's face properly now

- `.brandlogo--tvlobby` roughly doubled: `clamp(160px, 24vh, 220px)` tall /
  up to 480px wide (was ~96px); `.brandlogo--tvhead` up to 64px;
  `.tv__brandline` up to 32px. New `.tv__identity` / `.tv__identity--lobby`
  wrappers group wordmark + logo (+ §I's tournament block/chip) so the
  identity scales as one unit instead of three floats.
- The buzzer join screen's `.joinbrand` logo is deliberately untouched — the
  ask said the GAME BOARD (C5: resisting the adjacent-surface "improvement").

### §G — transactional emails greet a person, not an address

- `accounts/emails.py` gains `greeting_name(user)`: `display_name`, else the
  email's LOCAL PART — never the full address (the SiteNav §I/#12 rule,
  now applied to mail).
- The C6 grep found **FOUR** `Hi {`-style sites, not the two the doc
  remembered — the moderation-outcome mail has separate approved and
  rejected branches. All four swept through the helper.
- Four tests pin the literal greeting lines ("Hi Free," for a display name,
  "Hi sam.quiz," for a bare address) and assert the full address appears
  nowhere in any body.

### §H — the buzz sound is the HOST's choice, one per game

- `Game.buzz_sound` (1–4, default 1; migration 0006), set at creation ONLY
  (mid-game change is §M). Validated in the serializer AND the service
  (rule 4 lives where the mutation lives — the suite calls services
  directly); 0, 5 and "x" all 400 with the field named.
- Snapshot gains top-level `buzz_sound` — both transports carry it for free
  (C2), so the board (WS and polling paths alike) and every phone play THE
  GAME's sound.
- Host create screen: a four-card picker (Classic buzzer / Ding-ding /
  Honk / Triple beep); tapping an option selects it AND previews it — the
  tap is the user gesture WebAudio's autoplay policy wants, so the preview
  always sounds.
- The board's audio-ENABLE control moved out of the header's "weird spot" to
  a quiet fixed corner icon (`.tv__soundcorner`, 🔇/🔊). It STAYS on the
  board device — autoplay law: the gesture must happen on the device that
  plays the audio, so a host's laptop click can never legally unlock the
  TV's speakers — but it no longer offers any choice (the host picked at
  creation); it is purely "this TV may make noise". Default OFF, unchanged.
- C12 kept: `Participant.buzzer_sound` still rides every payload untouched
  and its round-robin tests still pin it; the coordinated removal is #14's
  (§M).
- Six new tests (valid 1–4, invalid 400s with nothing half-created, default,
  service-level validation, snapshot carriage, the pre-#13 default pin);
  the smoke pins `buzz_sound: 3` on the create response AND the first WS
  frame — zero new requests (§L).

### §I — TOURNAMENT MODE v1: named rounds of ordinary games

**Models (migration 0007).** `Tournament` — owner FK, name ≤80, optional
location ≤120, `finished_at` (null = live), `deleted_at` (the house
liveness flag; soft delete keeps attached games' history and frees the name
instantly via the partial constraint). `Game` — nullable `tournament`
(SET_NULL: an admin hard-delete can never take games with it) +
`round_number`; BOTH null = a plain game, which is what every pre-#13 row
migrates to. `TournamentAdvancer` — **names as text, not Participant FKs**,
on purpose: buzzer seats are per-game and anonymous, so advancing "TEAM A"
means the NAME goes through and re-joins the next round's game by typing
it — cheap, honest, and exactly how bars run this. Unique per
(tournament, round, source_game, name); rank is competition-style. There is
deliberately NO Round table in v1 (§M if rounds ever grow their own state).

**The plan gate IS the quota choke point.** `PLAN_LIMITS["tournaments"]`:
0 free (that's the creator gate), 25 creator; the structured
`quota_tournaments` 403 with used/limit; a staff `limit_overrides` grant on
a free account just works; the profile usage block gains the meter (one
existing admin shape pin extended accordingly — `usage()` is shared, the
extension is the point). `_denial` now reads limits via `.get` — a missing
PLAN_LIMITS key means unlimited, the convention the settings comment and
`_storage_limit` already documented, which keeps older test override dicts
working as new kinds land.

**API (all host-private Knox; every lookup owner-scoped → foreign, unknown
and soft-deleted ids all read as a plain 404, no existence leak).**
`GET/POST /api/tournaments/` (duplicate live name → 400 `{"name": [...]}`
via IntegrityError caught OUTSIDE the atomic block — DRF can't
auto-validate a conditional constraint, so the DB is the truth, the
join-name pattern); `GET /api/tournaments/<id>/` (the control-room payload:
games ordered by round with standings, plus advancers — fully prefetched);
`DELETE` (soft); `POST .../finish/` (idempotent — a second finish keeps the
first `finished_at`, history never rewritten);
`POST .../rounds/<n>/advance/ {per_game: 1|2}` (strict ints; bools
rejected). Game creation accepts optional `tournament` + `round_number`
(both-or-neither, enforced in the SERVICE; ownership/liveness/finished
resolved in the VIEW — the quota_denial placement pattern).

**Pinned NEW error codes (C4), exact `{detail, code}` shapes:**
`tournament_finished` (one module-level payload shared by attach AND
advance — reopen isn't a thing), `tournament_round_incomplete` (names the
still-playing game codes), `tournament_round_empty`.

**Advancement: host-CONFIRMED, server-COMPUTED, RE-RUNNABLE.**
`game_standings()` reads the SAME truths as `finalize_game` (active
role=player seats, score desc, removed excluded, the documented drinks-mode
credit-side reading) with competition ranking (1, 1, 3) — ties advance,
exactly as ties share the winners crown. `advance_round()` locks the
tournament row, rejects empty/unfinished rounds, then REPLACES the round's
rows wholesale — a second call is a mind-change (top-1 → top-2), pinned by
tests, and a rejection leaves prior rows intact (atomic). IntegrityError is
caught OUTSIDE the transaction at every call site (the house rule).

**Snapshot block.** `tournament: {name, location, round_number} | null`,
with `location` resolved SERVER-side — the tournament's own location, else
the host's `brand_name`, else their display name, else null (clients stay
dumb renderers). `select_related("tournament")` added to ALL THREE snapshot
callers (the cells_remaining N+1 lesson). DECISION, documented: the block
is NOT plan-gated on serve — creation was the gate, and hiding "ROUND 2"
because a card expired mid-tournament would break a live event.

**Rule 5, pinned the grep way (the #12 pattern):** a full cell is played
(open → buzz → judge → close → finalize), then `SECRET-`, `question_text`
and `answer` are asserted absent from the serialized detail AND advance
payloads — in the suite and again in the smoke.

**Frontend.** `/tournaments` — list + create; the gate renders off the
server's OWN usage meter (`usage.tournaments.limit === 0` → upsell panel),
so overrides just work without frontend knowledge. `/tournaments/:id` — the
control room: rounds as horizontal columns, per-game cards with standings,
the round's confirmed advancers, Advance-winners / Advance-top-2 buttons
with inline 409 detail, arm-to-confirm Finish/Delete (the CreatePage
two-tap pattern), and "+ game in round N" / "New game in round N+1" linking
into the ordinary create screen. HostPage reads `?tournament=&round=`:
a banner names the tournament and round (display only — the SERVER
re-validates ownership/liveness/finished on create; a stale URL just
errors), carries the ids in the create payload, and shows the **§I5
difficulty NUDGE** for rounds > 1 ("later rounds usually want a harder
board…") — a hint, not machinery; auto-hard-mode is §M. SiteNav gains
Tournaments.

**TV + buzzer.** Lobby: the tournament block (name big, "ROUND N" in gold,
the hosted-by line) sits ABOVE the venue brand inside the §F identity
wrapper. DECISION: when a tournament is present the brand's own "tonight's
trivia at" line is suppressed — hosted-by already says whose night it is —
while the LOGO still shows. In-play: a compact 🏆 name·R chip in the header
identity row. Buzzer join: a compact "🏆 name — Round N" line above the
hosted-by line at BOTH render sites (form and table-full).

**Tests: 36** across CRUD (exact shapes, per-owner name reuse after soft
delete, owner-scoped 404s), quotas (free 403, expired-plan collapse,
override grant, slot freed by delete, the profile meter), attach (persist +
snapshot, the pinned 409/404s, pairing, round ≥ 1), advancement (competition
ranks, ties, top-2, re-run replaces, rounds independent, removed players
excluded, per_game strictness, atomicity on rejection, owner scoping),
detail + rule 5, and snapshots (plain-game null — the forward-path shape —
exact block, the full location fallback chain, the join response).

### §J — deploy + docs

- DEPLOY.md: the Turnstile section (item 3 above) in §5 + the §8 reminder.
- This CHANGES.md entry; #12's mailbox item closed out.
- §M additions from this session's decisions: mid-game buzz-sound change;
  the coordinated `Participant.buzzer_sound` removal (#14); a Round table
  if rounds grow state; auto-seeding / brackets / elimination trees;
  auto-hard-mode per round (the §I5 nudge is v1); plan-gating tournament
  SERVING (deliberately not done); cross-venue anything.

### Gate results (sandbox)

Suite: 304 → **350 green** (+4 §G, +6 §H, +36 §I; one admin usage-shape pin
extended). Smoke: green **twice** back-to-back with the full tournament
story on a creator host, and the zero-setup SKIP branch verified separately
on a demoted host — both paths end `ALL SMOKE CHECKS PASSED`. Frontend:
`npm run build` clean, 53 modules. C9: the pristine-tree forward-path drill
in item 2. Compose parity (Postgres + Redis) remains owner-run per item 1.

**Post-package fix (first browser run):** `/host` crashed with
`useSearchParams is not defined` — the §I4 HostPage edit USED the hook but
the scripted edit that should have added its react-router import never
wrote the file, and **Vite's build does not fail on free variables**, so
"build clean" never covered it. Fixed (one import line), and the gate that
was actually missing is now in place: an ESLint `no-undef` pass over ALL of
`frontend/src` (flat config, JSX-aware — unimported COMPONENTS in JSX are
caught too) runs clean apart from two pre-existing non-findings (`Event` in
storage.js is a real browser global; two `react-hooks` disable-comments
reference a plugin the audit doesn't load). Lesson for #14's checklist:
`npm run build` is not a reference check — pair it with the `no-undef`
lint, and any scripted multi-edit must be verified by re-reading the file,
not by the script's own print.

**Post-package fixes, round 2 (owner's compose test run + first tournament
night):**

- **The suite now survives a Turnstile-configured environment.** Running
  `manage.py test` where `.env` sets `TURNSTILE_SECRET_KEY` (the compose api
  container, a configured droplet) leaked the feature into the suite — 6
  register-touching tests 400'd with "Verification failed" because
  verification fails CLOSED and tests send no token. The "suite runs
  keyless" promise is now ENFORCED in settings: under the test runner the
  Turnstile keys are blanked (`TESTING` guard); `TurnstileTests` still
  exercises the ON behavior through its own explicit `override_settings`.
  Proven by running the full 350 WITH the secret set in the env — green.
- **`MediaTemplateZipTests` is environment-aware without weakening the
  invariant.** The docker api image contains only the backend, so inside the
  container the whole `frontend/` tree is legitimately absent — the two
  tests now SKIP with a visible reason there. If `frontend/` EXISTS and the
  zip is missing (the C5 packaging-loss scenario), they still FAIL: the skip
  keys off the tree, never off the file. Defensively, the committed
  `frontend/public/question-media-template.zip` ships in this package again.
- **The smoke fails ACTIONABLY against a Turnstile-enabled server.** It
  can't solve a challenge, so the register assert now names the problem and
  the fix (run against an env without the key) instead of a bare 400.
- **Tournaments can actually run many games now.** The HostPage wrapper
  gated the create screen behind "no stored active game", so after game 1
  every "+ game in round N" click landed back in game 1's console — one
  game per tournament in practice. Arriving with `?tournament=` now forces
  the create screen (that URL IS the create-another intent); the params
  clear on create/resume so the wrapper falls through to the new game's
  console; and every unfinished game card on `/tournaments/:id` gains a
  **Host console** button (the `resumeHostGame` path /profile already uses)
  so the host can hop between heats. Backend was never the limit — no
  uniqueness on (tournament, round).
- **Won board cells no longer shrink.** `.board__col` is a flex column and
  cells had no flex share, so swapping the big gold value for the small
  winner name changed a cell's intrinsic height — it shrank and its
  siblings absorbed the space. Cells now take an equal `flex: 1 1 0` share
  (66px floor on the host board, even stretch on the TV) with
  `overflow: hidden`, so content changes never resize them.

A site-wide THEME change is queued for the next round: the owner is
supplying an index.html of candidate themes and will name the pick; all
pages then restyle. Nothing themed shipped in this package.

---

## Session: bot protection on register (honeypot + opt-in Turnstile) · public category browsing + funnel · support@ everywhere it helps · navbar identity · production polish (Handoff #12 §F–§J)

**⚠️ Open item 1 — compose runs (owner-run, C3).** No Docker in this build
sandbox, so the environment-parity compose runs (suite + smoke through
Postgres + Redis) are OWNER-RUN. The standing carry-overs still ride on it:
Redis-backed throttle counters + the forgot-password cooldown, and Postgres
accepting the THREE partial unique constraints
(`unique_category_name_per_owner`, `unique_active_theme_name`,
`unique_participant_name_per_game`). Nothing in #12 adds schema (see item
2), but §F's throttle-adjacent behavior and §G's new endpoint should both be
seen once through compose. Verified in the sandbox instead: full suite
286 → **304 tests green** on the SQLite fallback; `backend_smoke_test.py`
green **twice** end to end against a live server; `npm run build` clean;
the §N honeypot curl live (`{"detail": "Registration failed."}`, no row).

**⚠️ Open item 2 — ZERO migrations, confirmed.** `makemigrations --check`
reports no changes: §F is env + a request-time check, §G is a read-only
endpoint over existing models, §H/§I/§J are frontend + docs. Nothing to
migrate; C9's restart rule still applies to the plain code changes (dev:
`docker compose restart api`; prod: the deploy IS `up -d --build`, the
entrypoint migrates on start — a no-op this time).

**⚠️ Open item 3 — Turnstile owner setup (§F2; OFF until you act).** Create
a Turnstile widget in the Cloudflare dashboard (free), then set
`TURNSTILE_SECRET_KEY` + `TURNSTILE_SITE_KEY` in the backend env AND
`VITE_TURNSTILE_SITE_KEY` at frontend build time, and rebuild the frontend.
With the keys unset (today's state) the feature is entirely absent: no
script, no widget, no token sent, stray tokens ignored server-side — the
site runs exactly as before. When ON, register requires a solved challenge;
verification FAILS CLOSED (a Cloudflare outage/timeout reads as
"not verified" → 400; a signup retries, a bot flood can't be undone).
Scope is register ONLY — login keeps its throttle as its defense and
forgot-password keeps throttle + cooldown (a challenge there hurts
locked-out humans most); those are the documented extension points.
Email verification remains the escalation AFTER Turnstile (§M).

**⚠️ Open item 4 — the support@ MAILBOX must exist (§H; owner-run).**
Resend is SEND-ONLY: nothing in this repo receives mail. Create
`support@drinkquiry.com` as a forward/alias at the domain registrar or the
domain's mail hosting, or every mailto in the new footer/auth/404/buzzer
surfaces bounces.

**⚠️ Open item 5 — backups + uptime are owner-ops (§J3/§J4).** DEPLOY.md §9
now spells out the media half (local `backend/media/` needs its own nightly
copy; S3/Spaces mode = turn on bucket versioning) and the restore recipe;
§9c points any free monitor at `GET /api/health/` (expected
`{"status": "ok"}`). All owner-run, untestable from the sandbox.

**⚠️ C5 finding — frontend/public arrived EMPTY; template zip
reconstructed.** The uploaded tree's `frontend/public/` had NO files —
`question-media-template.zip` (a #11 §K2 committed invariant, read by
`trivia.tests.MediaTemplateZipTests` from disk) was lost in packaging, as
was everything else in the directory. Rebuilt it in this session FROM the
tests' own pinned assertions: root `questions.csv` (3 rows — a Movies media
row "What film is this frame from?" carrying `media/example.png`, the
`TV|80s` pipe row "Who shot J.R.?", and a second Movies row) +
`media/example.png` (a small generated PNG). The suite's dry-run + real
round-trip on the committed bytes is green, and the 286 baseline was
confirmed WITH the reconstructed zip before any #12 work. The zip ships in
this package; if you hold the original #11 artifact, either set of bytes
satisfies the pins.

### §F — bot gates on the public signup surface

- **What bots abuse is the anonymous POST surface, not the page:**
  `/api/auth/register/` (junk accounts) and secondarily forgot-password
  (already throttled + cooled down). Layered defenses, cheapest first; game
  join and the polling snapshot stay unthrottled and challenge-free (a bar
  behind one NAT is the normal case — pin untouched).
- **F1 honeypot (always on, zero deps):** the register form renders a decoy
  `website` input, off-screen-absolute (`.hp-field`; NOT display:none alone
  — some form-fillers skip hidden inputs), `aria-hidden`, `tabIndex={-1}`,
  `autoComplete="off"`. Server-side, `RegisterView.create` (a view
  override, not middleware — the gate belongs to the one view it protects)
  rejects any body with a non-empty `website` BEFORE the serializer:
  **NEW pinned body** 400 `{"detail": "Registration failed."}` —
  deliberately vague, never names the field or mechanism (C4: added shape,
  nothing mutated). Empty/absent `website` proceeds exactly as before, so
  every existing client and the smoke's register calls are untouched (C12
  grep: RegisterView, RegisterRateThrottle, AuthScreen, api.js register,
  the smoke's two register posts — all reviewed).
- **F2 Turnstile (opt-in via env, the escalation):** `accounts/turnstile.py`
  posts to Cloudflare's siteverify (`requests`, 5s timeout, never raises,
  fail closed). ON iff `TURNSTILE_SECRET_KEY` is set (the Resend pattern;
  dev/suite/smoke run keyless). When ON, register requires
  `turnstile_token`; failure/missing/timeout → **NEW pinned body** 400
  `{"detail": "Verification failed — please try again."}`. Frontend renders
  the widget (explicit render, script loaded once) in REGISTER mode only,
  only when `VITE_TURNSTILE_SITE_KEY` is baked in; login stays widget-free.
  Gate order pinned: honeypot first — a bot that filled it never costs a
  verify round-trip.
- **requirements.txt: `requests>=2.31` added explicitly** — it was already
  installed transitively (anymail base dep) but we now import it
  first-party; depending on a transitive dep by accident is how builds
  break later (§D's one sanctioned requirements change).
- **Tests (+10):** filled/whitespace/empty/absent honeypot (exact body, no
  user row); Turnstile off-by-default ignores a stray token; ON (override
  settings + mocked `requests.post`): missing 400, verify-false 400 (and
  the verify call carried our secret + token), verify-true 201,
  verify-timeout fails closed; honeypot-beats-turnstile ordering. Both new
  classes clear the throttle cache in setUp (C10 — the register throttle
  bit the first run, exactly as documented).

### §G — public category browsing (the logged-out funnel)

- **`GET /api/categories/public/`** — AllowAny, list-only,
  `authentication_classes = ()` so a STALE Knox token in a browser can
  never 401 the marketing surface (pinned). Registered BEFORE trivia's
  router include (static-before-parameterized; precedence pinned the
  history way — anonymous 200, never the viewset's 401). DELIBERATELY
  UNTHROTTLED: it joins game join + the snapshot on the pinned list (the
  accounts unthrottled test now hammers it post-429 too).
- **Queryset:** active (`deleted_at__isnull=True`) categories that are
  OFFICIAL (owner null) or PUBLIC+APPROVED; private/pending/rejected/
  deleted each pinned absent. **New `PublicCategorySerializer`** (NOT a
  CategorySerializer reuse — that leaks owner identity + moderation
  internals): exactly `{id, name, description, photo, question_count}`,
  pinned as the now-public shape. `question_count` is a single annotated
  `Count(filter=…, distinct=True)` over active official/public-approved
  questions (no N+1; NOT the per-user usable_question_count machinery —
  that takes a user). **Rule 5 pinned the SnapshotReveal way:** the raw
  payload is grepped for seeded answer strings AND question text — counts
  only, no question ids. Photos serve anonymously (moderated content; S3
  signs server-side regardless). Ordering name A→Z; DRF default pagination
  (50).
- **Frontend:** new public route `/categories` (ChromeLayout — SiteNav on
  top; AgeGate still above ALL routes, deliberate for a drinking product).
  Browse grid on the catcard look (photo/name/description/"N questions"),
  cards NOT selectable — a shop window, not the create screen. CTA banner:
  logged-out "Like what you see? …" / logged-in "Host a game with these",
  both → /host (the AuthScreen funnel already exists there). SiteNav gains
  "Categories" (logged-out AND logged-in). The Landing page gains a light
  teaser strip (same endpoint, sliced client-side, hidden on failure/empty)
  with "browse all →". Loading/empty/error states with hooks first, early
  returns after (C11).
- **Tests (+8) + smoke:** anon 200; authed 200 (no perverse 403);
  private/pending/rejected/deleted absent; exact 5-key payload; no answer
  text anywhere; question_count correct incl. a soft-deleted question NOT
  counting; A→Z; route precedence; stale-token 200. Smoke: ONE anonymous
  GET asserting ≥5 official categories with the exact key set (unthrottled,
  free, trivially re-runnable) — and NO new register calls (§L: the
  register budget is 5/min with 2 calls/run already; two back-to-back runs
  = 4).

### §H — support@drinkquiry.com

- **One constant** (`SUPPORT_EMAIL` in lib/api.js — the file every surface
  already imports; C1) rendered as mailto links: (1) a small footer inside
  ChromeLayout — every chrome page free; the TV board and buzzer stay
  chrome-free (outside the layout already); (2) AuthScreen, under the form
  — login trouble is THE support moment; (3) the buzzer join form's
  no-such-game 404 line; (4) §J2's 404 page. README gains a Support line.
- Deliberately NOT built: a contact form / ticketing (§M — a mailto is the
  right size, and a form is a new bot surface §F just fought).

### §I — navbar identity

- **C5 reality check held:** SiteNav already preferred display_name — the
  owner was seeing the FALLBACK (blank names and/or a stale cached
  `dq_auth.user`). Root causes fixed, not the symptom:
- **Never a full email in the nav:** fallback is now the email LOCAL-PART
  ("sam", not "sam@gmail.com"); full address stays in the title tooltip.
  The Profile Account panel's identity line follows the same rule.
- **Set the name where you'd look:** the Account panel gains an inline
  display-name edit (input + save; PATCHes `display_name` via the existing
  profile PATCH — zero backend change, the field was already writable).
- **Staleness killed:** every successful profile PATCH (name save,
  branding save/clear) routes through `applyFreshProfile`, which merges the
  fresh USER into the stored auth as `saveAuth({token, user: fresh})` —
  shape handled carefully: `api.updateProfile` returns the USER object
  directly while login returned `{token, user}`; the token is preserved.
  The existing AUTH_EVENT plumbing flips the SiteNav instantly. (Plumbing
  note: ProfilePage's `onAuthGone` became a `useCallback` — the saveAuth
  announce re-renders the page, and an inline arrow would have handed
  ProfileBody a fresh callback and re-run its load effect on every save.)
- Register keeps display_name OPTIONAL (forcing it is §F-style friction for
  zero security; the local-part fallback covers the lazy path forever).
  No server-side tests (no backend change): §N eyeball + `npm run build`.

### §J — production polish

- **§J1:** index.html gains one honest `<meta name="description">`,
  og:title/og:description/og:type (no og:image — punted with real SEO, §M),
  and `<link rel="icon">` → `public/favicon.svg` (chalk "D" on chalkboard
  green #232b26). `public/robots.txt` allows everything. Honest caveat: the
  SPA is client-rendered — crawlers get the tags and whatever they execute;
  prerender/SSG/sitemap are §M. Verified in dist/ after build:
  `ls dist/ → favicon.svg, robots.txt, question-media-template.zip` all
  present.
- **§J2:** catch-all `<Route path="*">` inside ChromeLayout — wordmark,
  "That page doesn't exist", links to / and /categories, §H's support
  address. Stateless (C11 trivially holds); the two chrome-free game routes
  still out-rank `*` (React Router ranks by specificity).
- **§J3/§J4:** DEPLOY.md §9 extended with the MEDIA backup story (local
  volume needs its own nightly copy — sample tar cron line; Spaces mode =
  bucket versioning) + the restore recipe (psql from the dump + the media
  copy); new §9c: point any free monitor at `GET /api/health/`, expected
  `{"status": "ok"}`. All stated plainly as owner-run.

### Decisions worth a line

- Honeypot renders in REGISTER mode only (form-filling bots are in that
  mode; API-scripting bots never see the form either way — the server
  check is mode-agnostic).
- Turnstile fail-CLOSED on register (documented in turnstile.py): a signup
  can retry; a bot flood slipping through an outage cannot be undone.
- The buzzer's 404 support mention is plain text inside the existing error
  string (the error path is a string pipeline; a full mailto there wasn't
  worth restructuring it — the footer/auth/404 mailtos cover the clickable
  cases).
- `.sitefoot` is a simple block, not a sticky footer (#root isn't a flex
  column; pages that fill the viewport push it below the fold, which is
  fine for a support line).

### Files

Backend: `accounts/views.py` (§F gates), `accounts/turnstile.py` (NEW),
`accounts/tests.py` (+10 §F, unthrottled pin extended to §G),
`config/settings.py` (Turnstile env keys), `requirements.txt` (requests
pinned explicitly), `trivia/serializers.py` (PublicCategorySerializer),
`trivia/views.py` (PublicCategoryListView), `trivia/urls.py` (static path
before the router), `trivia/tests.py` (+8 §G).

Frontend: `index.html` (§J1 meta), `public/favicon.svg` (NEW),
`public/robots.txt` (NEW), `public/question-media-template.zip`
(RECONSTRUCTED — see the C5 finding), `src/App.jsx` (teaser, footer,
/categories route, 404), `src/components/AuthScreen.jsx` (honeypot,
Turnstile, support line), `src/components/SiteNav.jsx` (Categories link,
local-part fallback), `src/lib/api.js` (SUPPORT_EMAIL, publicCategories),
`src/pages/CategoriesPage.jsx` (NEW), `src/pages/ProfilePage.jsx`
(DisplayNameEdit, applyFreshProfile, stable onAuthGone),
`src/pages/BuzzerPage.jsx` (404 support line), `src/styles.css` (#12
block).

Root: `README.md` (Support line), `DEPLOY.md` (§9 media/restore, §9c
uptime), `backend_smoke_test.py` (§G anon GET), `CHANGES.md` (this entry).

Suite: 286 → **304 green** (SQLite sandbox; compose pass owner-run per
open item 1). Smoke green twice. `npm run build` clean. Zero migrations
(`makemigrations --check`: no changes). Package verified: unzipped over a
fresh copy of the uploaded tree, diffed against the worked tree minus
exclusions — empty; then migrate (no-op) + seed + the new tests once from
the verified tree.

---

## Session: player removal (host kicks) · answered-cell winner names · venue branding · trademark-safe copy · legible hand font · production cleanup (Handoff #11 §F–§K)

**⚠️ Open item 1 — compose runs (owner-run, C3).** No Docker in this build
sandbox, so the environment-parity compose runs (suite + smoke through
Postgres + Redis) are OWNER-RUN. Three things ride on it now: the two #10
carry-overs (Redis-backed throttle counters + forgot-password cooldown;
Postgres accepting the partial unique constraints) **plus this session's
THIRD partial constraint** (`unique_participant_name_per_game` gains
`condition=Q(removed_at__isnull=True)` — same house pattern as
categories/themes, verified on SQLite here, needs the Postgres pass).
Verified in the sandbox instead: full suite 252 → **286 tests green** on the
SQLite fallback; `backend_smoke_test.py` green **twice** end to end against
a live server (re-runnability holds — §F's removal sequence builds a fresh
game per run); `npm run build` clean.

**⚠️ Open item 2 — MIGRATIONS ARE IN THE ZIP (standing rule since #10).**
Two files, both auto-generated, no hand-written data steps:
`games/migrations/0005_remove_participant_unique_participant_name_per_game_and_more.py`
(adds `Participant.removed_at`; swaps the name constraint to the partial
form) and
`accounts/migrations/0004_user_brand_logo_user_brand_logo_bytes_and_more.py`
(brand_name / brand_logo / brand_logo_bytes). **You run only
`python manage.py migrate`** (prod: the entrypoint already does). **The
forward path was TESTED against a database seeded from the PRISTINE tree**
(seed_demo + a played, finished pre-#11 game): after migrating, the old
game's participants/winners/cells were intact, an active duplicate team name
still collides, and a removed seat's name is immediately reusable. Rollback:
both migrations are mechanically reversible (`migrate games 0004` /
`migrate accounts 0003`), but reversing games/0005 restores the FULL unique
constraint and will fail if any game holds a removed seat whose name was
reused — restore from a backup instead of reverse-migrating a live DB.

**⚠️ Open item 3 — C9 restart guidance (code/schema flip together).** These
migrations are additive, but the C9 rule still applies: never `migrate` from
a new checkout while an old process keeps serving. Dev compose (bind-mounted
source): `docker compose restart api` after unzipping. Prod (baked image):
the deploy IS `docker compose -f docker-compose.prod.yml up -d --build` —
the entrypoint migrates on start, so code and schema flip together.

**⚠️ Open item 4 — branding trust note (terms of use).** §H ships venue
branding with NO logo moderation queue (§M): an image a creator-plan user
uploads goes straight to a public TV. The safety model is that the creator
plan is MANUALLY granted to known venues — you are trusting who you grant it
to. The staff Users tab shows every brand and can clear a logo / blank a
name in two clicks if that trust is misplaced. If creator ever becomes
self-serve, build the logo queue first.

**Zero new dependencies** — `backend/requirements.txt` and
`frontend/package.json` are untouched (nothing in #11 needed one; Patrick
Hand is a Google Fonts href swap).

Suite: **286 green** (`python backend/manage.py test accounts trivia games`)
— 252 baseline (verified against the unpacked tree per C5, not trusted from
the doc) + 24 §F/§G (games) + 8 §H (accounts) + 2 §K2 (trivia); §K1's legacy
pin was FLIPPED in place, not added.

---

### §F — Host removes players (soft removal, every surface audited)

**Semantics (decided per the doc, not negotiable):** removal is a SOFT flag,
`Participant.removed_at` (null = active — the ONLY liveness flag, same
convention as Question/Category `deleted_at`; named `removed_at` because a
participant is removed from a live game, not deleted content). Hard deletes
would cascade away Buzz + DrinkAssignment history and SET_NULL exactly the
`answered_by` attribution §G renders. The name constraint became PARTIAL
(third use of the house pattern) so a kicked troll's name — or a
legitimately-rejoining table's — is immediately reusable.

**The mutation** (`games/services.py remove_player`, house rule): host-only;
the HOST SEAT is unremovable (a game without its control seat is bricked);
FINISHED games refuse (history is sealed); works in lobby AND active.
Double-remove raises the NEW documented structured error
`{"detail", "code": "player_removed"}` (C4-safe: a new code, no mutated
shapes) so the kicked phone can distinguish "you were kicked" from generic
errors. Inside the row-locked transaction: the removed player's Buzz rows
for the CURRENTLY OPEN cell are deleted (live buzz order evaporates;
closed-cell history stays); if the open cell's `answered_by` is the removed
player AND drinks are not yet assigned, the win is voided
(answered_by/answered_correctly cleared, judgment marker cleared, buzzer
REOPENED — the round restarts); if drinks WERE assigned, everything stays
(the drink happened). If the removed player is `judged_participant`, the
marker clears either way. The cell is fetched separately from the locked
game (the select_for_update + nullable-FK Postgres foot-gun, house rule).

**Deliberate nuance (documented, followed the doc literally):**
`answer_revealed` is LEFT ALONE in the void-the-win branch. Judge-correct
performs the reveal, so a restarted round can have the answer already on
screen. Un-revealing what the room already saw is theater; the host's
practical move is to just close the cell. If this grates in real bars, the
one-line change is adding `answer_revealed = False` to that branch (and a
clearing-point note on the Game model comment).

**Consumer:** new host action `remove_player {participant_id}`, wired like
every other host action; NO REST twin (the host panel is live; reconnect
works). A kicked player's ALREADY-CONNECTED socket can't be caught by a
connect-time filter, so `receive_json` re-checks the seat on every message
(one indexed EXISTS query — the host pays it too, always passing): a removed
sender gets the `player_removed` structured error, then the NEW documented
app close code **4003** (docstring updated next to 4001). Reconnect attempts
die at `_get_participant` → the 4001 path (it now filters removed).

**The C6 grep** (`participants.filter`, `role=`, `ParticipantRole.PLAYER`,
`answered_by`, `winners`, `player_count`, `MAX_PLAYERS`, `FinalStandings`,
`ScoreStrip`) reconciled against §F3's list — every surface found, filtered,
and pinned by a test:

- **Snapshot:** removed participants are EXCLUDED from `participants`
  entirely (decision per the doc — clients are dumb renderers, so
  ScoreStrip / FinalStandings / lobby lists / drink pickers / the TV score
  footer all clean themselves with ZERO component changes). Filtered in
  Python over the prefetched list, never `.filter()` (which would re-query
  past the prefetch). NEW top-level snapshot field
  `former_players: [{id, name}]` — removed players holding at least one
  `answered_by` attribution — derived from the SAME prefetched
  participants + columns__cells pass (the cells_remaining pattern; no N+1).
- **Join cap:** the locked player_count filters removed — kicking frees a
  seat (pinned: fill to 6, kick, the 7th join is 201 — also live in smoke).
  The §I buzzer_sound round-robin rides the same count (pinned).
- **Token rejoin:** a removed seat's token can NOT reclaim it — the
  token-rejoin branch filters removed and falls through to a normal
  fresh-seat join (pinned: 201 with a NEW id/token, not 200).
- **finalize_game winners:** filters removed (a kicked troll can't tie for
  the crown); their tallies stay on the row (history is history — pinned).
- **assign_drink target + judge_buzz participant lookups:** active only.
- **Report:** keeps ALL participants (host-private, full history) via a new
  `ReportParticipantSerializer` adding a `removed` boolean; the frontend
  report badges them. Never rides a snapshot.
- **GameHistorySerializer.participant_count + the view's annotation:**
  active players only.

**Frontend:** the hook gains `removed` (set by the structured error OR close
4003). BuzzerPage detects a kick three ways (C2 thinking): the error, the
close code, or its participantId simply MISSING from a fresh snapshot (the
polling-adjacent path) — then clears the seat immediately (the token is dead
server-side) and shows the friendly full-screen card ("The host removed this
buzzer — grab a teammate's phone, or rejoin with a new name") with a Join
again button back to the name form; no shaming copy. The card renders AFTER
all hooks (hook-order safe). BoardPage: a kicked player-seat token on a TV
just flips to the polling fallback (`usePolling` gains `|| ws.removed`).
Host: `RemovePlayerButton` (the standing DeleteButton inline-confirm
pattern: arm → 3.5s auto-disarm → confirm) on every lobby-list row AND a
`manageteams` row under the ScoreStrip while active (ScoreStrip itself is
shared by phones/TVs and stays untouched). TV: nothing — removed seats fall
out of the snapshot (§N eyeball).

**Smoke** (kept small per F5): inside ws_flow after the drink round — host
removes TEAM A over WS, TEAM A gone from the next snapshot's participants, a
fresh join with the SAME name is 201 (cap freed + partial constraint, live),
and the already-fetched report shows TWO TEAM A rows: the removed original
(tallies + `removed: true`) and the fresh seat (`removed: false`). The #10
`participant_count == 6` history pin still holds (6 − 1 kicked + 1 rejoin).

### §G — Answered cells show who won them (frontend-only, as specified)

`BoardGrid` (the ONE renderer — host grid and TV both): a won cell now shows
the winning TEAM's name instead of ✓, resolved CLIENT-side from
`answered_by` against `participants` + §F's `former_players` (house style —
no name field added to CellSerializer, and that decision is pinned by a
suite tripwire asserting the serializer's exact field set). "Nobody got it"
keeps —. Unresolvable ids (pre-#11 games whose winner was hard-deleted by
ancient tooling — `answered_by` is SET_NULL) fall back to ✓. CSS:
`.cell__done--name` — hand font, `clamp(11px, 1.4vw, 16px)`, two-line
`-webkit-line-clamp` + ellipsis + `overflow-wrap: anywhere` (ALL-CAPS
50-char names in small cells), inheriting the gold `--won` color so it still
reads at TV distance; cell heights are fixed by the grid's `min-height`, so
the 8-column compact host grid doesn't blow up (§N eyeball).

### §H — Venue branding (creator-plan feature; billing stays §M)

**The honest answer on charging:** still no payment system, so v1 gates
branding on the manually-granted creator plan — a sellable "venue package"
today, already behind the plan gate when Stripe lands. A separate "venue"
plan value later is a PLAN_LIMITS + Users-tab config change (noted, not
built).

**Model (H1):** brand lives on the USER (`brand_name` 60ch, `brand_logo`
ImageField `brands/` with `validate_image`, `brand_logo_bytes`) — every game
they host is branded; per-game overrides are §M. `User.save()` runs the
WHOLE existing media pipeline (`trivia.images.prepare_media`, exactly like
Category.save(): resize-before-storage, EXIF strip, byte recount). Import
check done: `accounts.models` importing `trivia.validators` at module level
is safe (validators touches only settings/ValidationError at import; PIL is
deferred). `storage_bytes_used` gains the brand bytes (quota counters are an
"active" surface, C6); clearing the logo frees them because the column goes
to 0 on the full save (the old FILE stays on disk — the same deliberate
mismatch as deleted questions, still noted).

**API (H2):** Profile PATCH accepts brand_name + brand_logo (multipart) +
**`brand_logo_clear: true`** (the documented clear mechanism — chosen over
`brand_logo: ""` because multipart can't reliably express "empty file").
Free-plan WRITE of any brand field → a plain 403
`{"detail": "Branding is part of the creator plan."}` from the view (NOT a
quota shape — branding isn't counted); reads are fine everywhere; a
brand-free PATCH still works for free users (pinned). The storage quota DOES
apply to uploads (standard structured `quota_storage` 403). Register can't
sneak branding in (serializer create() drops the fields; pinned). Plan
lapse: the fields PERSIST but stop being SERVED — `effective_plan` gates the
snapshot's `brand`, so expiry turns branding off without destroying the
venue's upload, and flipping back restores it (both directions pinned).

**Snapshot:** `GameStateSerializer` gains top-level
`brand: {"name", "logo"} | null` from `game.host`, only when the host's
effective plan is creator AND something is set. `select_related("host")`
added to every snapshot queryset (consumer, GameStateView, the join view) —
the cells_remaining N+1 check repeated. WS snapshots have no request
context; the logo URL is root-relative there and absolutized when a request
exists (same behavior as every other FileField).

**Staff oversight (both required controls):** the Users tab list serializer
shows brand_name + brand_logo, and PATCHABLE_FIELDS grows by EXACTLY
`brand_name` + `brand_logo_clear` — everything else still 400s (the pinned
whitelist test was EXTENDED with the new keys the C4-safe way, and re-pins
that `brand_logo` itself and `is_staff` still 400). Staff never upload a
logo, only clear one. No logo moderation queue (§M) — see ⚠️ open item 4.

**Frontend (H3, FULL — the pressure valve wasn't needed):** Profile gains a
Branding panel (creator: name input, logo upload with preview, clear button,
quota note; free: the standard upsell card style). TV lobby shows the logo +
"tonight's trivia at THE KINGS ARMS" above the join code; during play a
small `brandlogo--tvhead` sits in the TV header next to the sound toggle —
present, never competing. The buzzer JOIN form shows "hosted by THE KINGS
ARMS" under the wordmark — pre-join there's no socket, so ONE
unauthenticated snapshot fetch supplies it (optional sugar; a failure shows
nothing). Post-join surfaces read the live snapshot. Users tab: brand name
editable inline (rides the normal Save PATCH), logo thumbnail with an
inline-confirm Clear. New `api.updateProfile` (JSON or multipart).

**Tests (H4):** creator multipart set; free write 403 exact body; register
can't set; storage quota applies + frees on clear (tiny-cap override);
snapshot shape/null + free-host null; lapse hides / flip-back restores while
fields persist; staff whitelist extended-not-loosened; admin list shows the
fields. No smoke (needs a creator account — same reasoning as #9's opt-in
media round-trip).

### §I — Trademark-safe copy (grep-zero achieved)

The fresh case-insensitive grep found exactly the four documented hits, all
fixed: App.jsx landing ("The trivia grid, the buzz order, the big reveals"),
HostPage points card ("Classic quiz-show scoring: +value right, −value
wrong"), shared.jsx comment ("The game grid"), README ("Quiz-show-style
trivia platform"). Verified grep-zero across frontend/src, backend, README,
DEPLOY, compose files, Caddyfile, index.html and the smoke script.
**Historical CHANGES.md entries were deliberately NOT rewritten** (a
changelog is a record, not marketing copy — the term below this entry refers
to what the docs said at the time); this new entry is written clean.

### §J — Legible hand font: Caveat → Patrick Hand

The complaint is the cursive `--font-hand` (Caveat), worst exactly where it
was used most: ANSWERS (report/preview/library answer lines, bulk summary)
plus drink attribution lines. **Delegated default taken: Patrick Hand** —
still casual/chalky for the chalkboard aesthetic, but upright, single-story,
dramatically more legible at these sizes. Google Fonts href swapped (Caveat
600;700 dropped, Patrick Hand added — it ships ONE weight, so the two
`font-weight: 600` declarations that leaned on Caveat's weights
(.board__cat, .previewcat) were removed). All 12 usage sites walked
(reality check per C5: the doc said 13 "including the host's private answer
card" — the token line + 12 usages is what the tree actually holds, and
.answercard was never on the hand font); Patrick Hand's body is larger than
Caveat's, so each site came down a notch: 22→20px, 20→18px, 19→17px,
clamp(17,2.2vw,24)→clamp(15,2vw,21), clamp(22,3vw,38)→clamp(20,2.8vw,34),
1.5rem→1.35rem, 1.6rem→1.45rem (.howstep__arrow untouched — it's a glyph).
Bebas Neue display faces untouched. **Fallback position if the owner still
reads it as cursive:** `--font-hand: var(--font-body)` + italic on the
answer lines (a two-line change, noted here as promised). §N step 7 is the
owner's eyeball.

### §K — Production cleanup

1. **Deprecated single-`category` write alias REMOVED** (the #10 "one
   session" promise, kept): field + validate() mapping branch deleted; the
   pin test flipped from "legacy write works" to "legacy write is a clean
   400 naming `categories`, creating nothing". Three suite helpers and the
   smoke's opt-in media round-trip still rode the alias — migrated to
   `categories` (the frontend already sent it; multipart lists post as
   repeated keys, which DRF's many-PK field reads fine).
2. **Dead media-template download FIXED:** built
   `frontend/public/question-media-template.zip` FROM the template directory
   (questions.csv at zip root + media/example.png) and committed it — Vite
   serves it at the exact path /create already links. Pinned by a suite
   round-trip on the COMMITTED bytes: dry-run (created: 3, nothing written)
   then real import (3 questions; the pipe row "TV|80s" lands in BOTH
   auto-created categories; the media row's image arrives sized through the
   pipeline). `create_categories=true` mirrors the /create form's checkbox —
   the template names don't pre-exist for a fresh creator.
3. **README refreshed** (one-paragraph-scale, not a rewrite): app bullets
   now mention M2M categories, themes, throttles, password flows, branding,
   kick, the library; the health probe; media caps corrected to the real
   10/8/25 MB + resize numbers; the roadmap dropped the already-shipped
   items (frontend, password reset, rate limiting) and gained the branding
   billing note.
4. **`manage.py check --deploy`** re-run with prod-ish env: exactly #10's
   disposition (W008 SSL_REDIRECT — Caddy 301s; W021 HSTS_PRELOAD and W005
   subdomains — owner's env calls). Confirmed, nothing churned.

### Files in this zip (repo-relative; unzip over the repo root)

Backend — games: `models.py` (removed_at + partial constraint),
`services.py` (remove_player + judge/drink/finalize filters),
`consumers.py` (action, per-message check, 4003, docstring),
`serializers.py` (participants filter, former_players, brand,
ReportParticipantSerializer, history count), `views.py` (join cap/rejoin/
history filters, select_related host), `tests.py` (+24),
`migrations/0005_…py` (NEW). accounts: `models.py` (brand fields + save
pipeline), `serializers.py` (brand fields, clear flag, create-drop),
`views.py` (ProfileView write gate), `admin_api.py` (whitelist + brand
oversight), `quotas.py` (brand bytes), `tests.py` (+8, whitelist pin
extended), `migrations/0004_…py` (NEW). trivia: `serializers.py` (§K1 alias
removed), `tests.py` (pin flipped, helpers migrated, +2 template-zip).

Frontend: `index.html` (fonts), `src/styles.css` (font swap + size walk,
§F/§G/§H styles), `src/components/shared.jsx` (§G names, §I comment),
`src/lib/useGameSocket.js` (removed state), `src/lib/api.js`
(updateProfile), `src/pages/HostPage.jsx` (kick UI, §I copy),
`src/pages/BuzzerPage.jsx` (kicked card, brand line),
`src/pages/BoardPage.jsx` (polling on 4003, brand surfaces),
`src/pages/ProfilePage.jsx` (Branding panel, report badge),
`src/pages/ModeratePage.jsx` (Users-tab brand oversight), `src/App.jsx`
(§I copy), `public/question-media-template.zip` (NEW).

Root: `README.md` (§I + §K3), `backend_smoke_test.py` (§F sequence, §K1
helper), `CHANGES.md` (this entry).

Package verified: unzipped over a fresh copy of the uploaded tree, diffed
against the worked tree (minus the standard exclusions) — empty; then from
the verified tree: migrate + seed_demo + the new test classes green.

---

## Session: multi-category questions · themes · board-complete + game-over messaging · production hardening (Handoff #10 §F–§I)

**⚠️ Open item 1 — MIGRATIONS *ARE* IN THE ZIP this session (§D amendment).**
The standing exclude-migrations rule only works for auto-generatable schema;
§F's FK→M2M conversion needs a HAND-WRITTEN data migration sandwiched between
schema steps (add M2M → copy every question's `category_id` into the through
table → drop the FK), which `makemigrations` cannot produce and which would
lose every question's category if skipped. So the zip ships
`trivia/migrations/0005_multi_category_and_category_soft_delete.py`
(hand-written; also carries §F5's `Category.deleted_at` + the partial unique
constraint) and `trivia/migrations/0006_theme.py` (auto-generated). **You run
only `python manage.py migrate`** (prod: the entrypoint already does).
**The forward path was TESTED against a database seeded from the PRISTINE
pre-§F tree** (seed_demo + a creator's own category/questions + a played
game): after migrating, all 30 questions kept their category (now inside
`categories`), the game's columns/cells were untouched, and same-name
category creation after a soft delete works on the new partial constraint.
**Rollback is out of scope**: the data migration's reverse raises on attempt
(once a question lives in several categories there is no single category_id
to restore) — restore from a DB backup instead.

**⚠️ Open item 2 — compose runs (owner-run, C3).** No Docker in this build
sandbox, so the environment-parity compose runs (suite + smoke through
Postgres + Redis) are OWNER-RUN — and they matter MORE this session: §I1
moves the throttle counters and the forgot-password cooldown onto Redis in
compose/prod (the sandbox runs exercised LocMem). Verified here instead:
full suite 204 → **252 tests green** on the SQLite fallback;
`backend_smoke_test.py` (extended: §I3 health pin, §G themes shape, §H1's
two cells_remaining asserts) green **TWICE** against a live local server on
pristine seed; the new surfaces additionally hand-exercised live with a
staff account (themes CRUD 201/200/204/409, pipe bulk upload creating one
question in two categories + auto-created category, library M2M filter
duplicate-free with `category_names`, category soft delete + same-name
recreate, login throttle 429 firing live while /api/health/ stays
unthrottled); `npm run build` clean. Also verify Postgres accepts the
partial unique constraints (SQLite did; Django supports both — the compose
migrate is the proof).

**⚠️ Open item 3 — §I owner decisions (also in DEPLOY.md §9b):**
1. **Confirm Caddy forwards X-Forwarded-For** (its default reverse_proxy
   does, and this repo's Caddyfile uses the default). The throttles read the
   client from XFF only when `DJANGO_BEHIND_PROXY=true` (the flag you
   already set for TLS); getting this wrong throttles the whole site as one
   IP. DEPLOY.md §9b has a 2-machine verification recipe.
2. **HSTS is your flag** (one-way door): `SECURE_HSTS_SECONDS` env, default
   0; suggested 31536000 once confident (+ optional
   `SECURE_HSTS_INCLUDE_SUBDOMAINS=true`). NOTE: `.env*` files are excluded
   from the zip by the deliverable rules, so add these two lines to your
   `.env.production.example` / droplet `.env` by hand — DEPLOY.md documents
   them.
3. **Backups / media lifecycle** stay manual ops — DEPLOY.md already had the
   pg_dump cron (§9); §9b adds the media-bucket note (soft-deleted content
   keeps its files by design, so the bucket only grows).
4. `docker compose ps` should now show the api service **(healthy)** — both
   compose files gained an /api/health/ healthcheck (python -c probe, no
   curl added to the image).

**requirements.txt: UNCHANGED — no image rebuild needed for deps.** §I1 uses
Django 6's built-in `django.core.cache.backends.redis.RedisCache` (redis-py
is already pinned for channels-redis).

---

### §F — Questions belong to multiple categories

**F1 model.** `Question.category` (FK) → `Question.categories =
M2M(Category, related_name="questions")`. Keeping the related_name was the
point: `category.questions` reverse lookups (usable_questions,
usable_question_count, similarity) kept their spelling; only filter
semantics were reviewed. Stated plainly (docstrings + here): **deleting a
Category no longer CASCADEs questions** — M2M rows just vanish; §F5 owns
deletion semantics now, and nothing relies on the old cascade.

**F2 write path.**
- QuestionSerializer: `categories` (PrimaryKeyRelatedField many, active
  categories only) — required on create, optional on PATCH (omitting keeps
  the set). Per-category permission: the unchanged rule (official | own |
  publicly-visible), applied to EVERY category; one ineligible id fails the
  whole create. Repeated ids in the list collapse.
- **Back-compat for ONE session:** single `category` id still accepted on
  WRITE (write_only, mapped to `[id]`, deprecated in the docstring) so
  in-flight tabs don't 400 mid-deploy. Responses carry `categories` only.
  Remove next session.
- **Bulk CSV:** the category column takes pipe-separated names (`TV|80s` —
  pipe, not comma: it's a CSV). Each name resolves/auto-creates exactly as
  one did; a row errors if ANY name is ambiguous/ineligible (same row-error
  shape); a repeated name within one row collapses. Both template CSVs under
  frontend/public/ gained a pipe example row (incl. the doc's own
  "TV|80s → Who shot J.R.?"); /create's upload help copy explains the pipe.
  NOTE: the media-template DIRECTORY's questions.csv was updated; the
  downloadable question-media-template.zip is not in the repo (it wasn't in
  the uploaded tree either) — if you regenerate it, zip the updated CSV.
- **Duplicate detection — BEHAVIOR CHANGE, decided:** the dedupe key is now
  `(owner, question_text)`; category dropped out. Same text in a second
  category is a DUPLICATE now (one question in both is the way to express
  it) — applies to the bulk `existing` set and `seen_in_file`; pinned. An
  upload of existing text under a different category is skipped and does
  NOT silently recategorize the existing question.
- **Revise** copies categories (`new.categories.set(old.categories.all())`
  inside the existing transaction). Revise's editable-field set did NOT grow
  (recategorizing is a normal PATCH concern); the library's inline edit
  did NOT gain a category multi-select (not cheap enough to be free — the
  revise endpoint would need the field too; punt noted).
- seed_demo: questions keyed on (owner=None, question_text), categories
  attached via `.add()` — idempotent, 5×5 counts pinned intact.

**F3 game builder.** `create_game` still takes `category_ids`; columns are
processed IN THE ORDER GIVEN with a `used_question_ids` exclusion set, so a
question in two selected categories appears AT MOST ONCE per board. The
shortage check runs against the EXCLUDED pool ("Movies (5) + 80s Movies (5)
sharing 3" refuses a 5-per build instead of silently duplicating); shortage
attribution is order-dependent — the LATER column reports short (accepted +
docstring'd; error shape/message format unchanged). `usable_question_count`
stays a per-category distinct count (catcard meaning unchanged); the create
screen's warning stays cosmetic — the server refusal is the gate (rule 4).
`replace_cell_question` needed no change (it already excludes the whole
board) — pinned anyway.

**F4 read surfaces (C6 grep run over the whole tree; reconciled):**
- similarity: "same category first" → "shares ANY category"
  (`categories__in`, `.distinct()`); per-match context is `category_names`
  (sorted list) replacing category_id/category_name; global thin-pool
  fallback unchanged.
- Library `?category=` → `categories__id` + `.distinct()` (paginated
  querysets stay duplicate-free — pinned live and in suite).
- `ModerationQuestionSerializer.category_name` → **`category_names`**
  (sorted list; replaced, not aliased — our serializer, our frontend).
  Library/queue/Flagged cards, SimilarMatches rows and the /create question
  list all render the list.
- Board/report/host-preview serializers UNTOUCHED — cells get their
  category context from `BoardColumn.category`, which still exists and
  still says which column the question was played under.
- QuestionViewSet list: prefetch categories, M2M filter, `.distinct()` on
  both auth branches.
- **C6 finds beyond the doc's list** (expect-to-find, found):
  `accounts/emails.py` built the moderation-outcome email's "in <category>"
  from `item.category.name` → now a sorted joined name list; the three test
  modules' helpers/call-sites used the FK kwarg (updated); trivia/admin's
  QuestionAdmin list_display/list_filter (updated; joined-names column).
  Quota counters were already text/owner-keyed — verified, no change needed
  for §F1 (they DID need §F5's deleted filter, below).

**F5 category soft delete (pulled in from §M — justified: the M2M removed
the cascade so deletion needed new semantics anyway, and hard-deleting an
ever-PLAYED category was a guaranteed ProtectedError 500).**
- `Category.deleted_at` (null = active; the ONLY liveness flag — no boolean
  twin). Owner DELETE → soft, 204, uniform rule. Deleting a PLAYED category
  succeeds; its games' snapshots/history/reports keep the name (pinned).
- `unique_category_name_per_owner` is now PARTIAL
  (`condition=deleted_at__isnull=True`) so a deleted name can be reused —
  verified on SQLite; Postgres in the owner-run compose pass. Theme names
  got the same treatment from day one (`unique_active_theme_name`).
- Absence audit (each surface pinned): CategoryViewSet queryset (listings +
  404 on detail/PATCH/DELETE), `eligible_categories` in bulk upload (a
  deleted name is "no such category"; auto-create makes a FRESH row, never
  resolves to the deleted one), `create_game` (deleted id = "Unknown
  category ids"), moderation categories queue list + the `categories`
  count (queue-consistent, like questions in #9), `categories_used` +
  `storage_bytes_used` quota counters (the C6 lesson again), §G theme
  listings (both the host list and the staff serializer hide deleted
  categories). Deleted categories REMAIN in board columns, snapshots,
  reports, history.
- Questions are NOT cascaded: a question whose categories are all deleted
  becomes undrawable (draws go through a live category) but stays in its
  owner's list and is recategorizable via PATCH — pinned. /create's
  category delete button copy updated accordingly ("its questions stay in
  your list").
- The shared moderation `_act` deleted-guard now applies to categories too;
  its 409 detail is model-agnostic ("This item was deleted…") — a message
  string, not a structured shape (C4-safe).
- **Pressure valve NOT needed:** F5 shipped complete, including the
  frontend copy change. Staff category delete endpoint / restore / category
  revise stay §M.

### §G — Themes

- `trivia.Theme`: name (+ partial-unique among active), description,
  `categories` M2M (related_name="themes"), created_at, deleted_at (soft
  delete from day one). Staff-managed, official-only v1 — no owner column.
  This IS the tag table.
- `GET /api/themes/` (any authenticated user): active themes by name,
  unpaginated; each `{id, name, description, categories: [{id, name,
  usable_question_count}]}` — categories filtered to the requester's
  visibility (same rule as /api/categories/, deleted excluded), counts per
  user exactly like CategorySerializer.
- Staff CRUD `GET/POST /api/moderation/themes/`, `PATCH/DELETE .../<id>/`
  (router, unpaginated): delete is SOFT (204), double delete 409 (house
  flavor; detail queryset sees deleted rows so the race is a 409, not 404),
  active-name uniqueness validated in the serializer (400), name reusable
  after delete. IsAdminUser everywhere; non-staff 403 / anon 401 pinned.
- **Game creation API UNCHANGED** — themes are discovery/selection only;
  create_game's docstring now says so explicitly (per the doc: so nobody
  "improves" it into a theme_id parameter without a reason).
- seed_demo: 3 themes over the seeded categories ("Screens & Sounds" →
  Movies+Music, "Brain Food" → Science+Geography, "Night Out" →
  Music+Food & Drink); idempotent (name-matched, categories .set()); adds
  rows only — the 5×5 smoke assumption untouched (pinned).
- Host UI (/host create): a **theme strip** above the category grid — an
  "All categories" chip + one per theme. Tapping FILTERS the grid (a view,
  not a reset: selections made under other filters stay selected; an
  "N selected" chip keeps the tally visible) and offers **"✨ Pick for me"**:
  auto-selects up to 5 of the theme's categories with
  `usable_question_count >= perCategory`, highest counts first (5 per the
  owner's "up to 5"; the manual grid still allows 8). DECISION: Pick-for-me
  REPLACES the current selection — it's the one-tap "give me a board"; say
  the word and it becomes additive. Thin/empty themes render disabled with
  "not enough questions yet". Selection state is the same `selected` array;
  the server refusal (F3) remains the gate.
- Staff UI: sixth /moderate tab **"Themes"** — list with inline create/edit
  (name, description, category multi-select fed by api.categories) and
  soft delete with confirm; Library-tab row/form patterns reused; no
  pagination.

### §H — Board-complete + buzzer game-over

- **H1 snapshot:** `cells_remaining` — top-level SerializerMethodField on
  GameStateSerializer counting cells with state != "answered" from the SAME
  prefetched columns/cells the `columns` field serializes (no N+1; every
  snapshot caller prefetches columns__cells). Derived, never stored; both
  transports get it free (C2). Semantics pinned: OPEN counts as remaining;
  0 exactly after the LAST close_cell; reveal/judgment alone never move it;
  per_category × columns at lobby.
- **H2 host:** when active && cells_remaining === 0 && no open cell — a
  prominent banner over the board ("That's the whole board 🎉 — finish the
  game to crown the winner") with the EXISTING finish/confirm flow moved in
  (the same confirmFinish state — reused, not forked; the header Finish
  stays too).
- **H3 board:** same condition on the TV — a quiet hand-chalk line under
  the grid ("All questions played — waiting for the host to wrap up"). No
  takeover, no animation.
- **H4 buzzer:** status === "finished" now renders a proper finale instead
  of the dead grey buzz circle: big display-face "GAME OVER 🍻",
  FinalStandings (shared component, reused), the personal line ("You gave
  3 🍺 and took 1 🍻" / final score), "hand the phone back" footnote, and a
  🏆 flourish on the winner's own phone. Winner check derived LOCALLY from
  the live snapshot exactly the way FinalStandings ranks (points → score,
  drinks → drinks_given) — the doc's suspicion was right: `winners` lives on
  history/report serializers, not the snapshot, and FinalStandings'
  derivation sufficed, so NO new snapshot field. Socket stays open (late
  snapshots still render); no new WS events.
- Smoke: two cheap asserts inside the existing ws_flow (== 15 on first
  snapshot, == 14 after the one close_cell); the suite plays a whole 1×2
  board at the services level.

### §I — Production hardening

- **I1 Redis cache:** when REDIS_URL is set, `CACHES["default"]` = Django
  6's built-in RedisCache on the same instance as channels, key prefix
  "cache"; else LocMem (dev/tests unchanged). No new dependency. Quiet fix:
  the forgot-password cooldown (LocMem = per-process since #9) is global on
  Redis — as are the new throttle counters.
- **I2 auth throttles** (accounts/throttling.py, applied PER-VIEW — never a
  global default; join + the polling snapshot stay unthrottled and that's
  pinned by test): login 10/min, register 5/min, password_forgot 5/min,
  password_reset 5/min per client IP; rates in
  REST_FRAMEWORK["DEFAULT_THROTTLE_RATES"]. 429 body is DRF's default
  {"detail"} — a NEW status, not a mutated shape (C4); the frontend's
  errorText already renders it. **Proxy handling:** ProxyAwareAnonThrottle
  reads settings.DJANGO_BEHIND_PROXY at CALL time (so override_settings
  works in tests) — behind the proxy the ident is the LAST X-Forwarded-For
  entry (NUM_PROXIES=1 semantics; the one trusted hop appended it), else
  REMOTE_ADDR and spoofable XFF is ignored; all three cases pinned. The §K1
  per-account cooldown is unchanged and independent; a tiny-rate test pins
  that every 200 keeps the identical enumeration-proof body. TEST SEAM
  NOTE: DRF's SimpleRateThrottle captures THROTTLE_RATES as a CLASS
  attribute at import, so tests pin tiny rates by patching the classes'
  `rate`, not by override_settings(REST_FRAMEWORK=…) — documented in the
  test helper. Smoke-adjacent note: the smoke run performs ~5 logins; the
  10/min limit leaves headroom for the standing run-it-twice, but a tight
  loop of MANY back-to-back smoke runs from one IP can 429 login (observed
  live, working as designed — space the runs).
- **I3 health check:** GET /api/health/ (AllowAny, no auth classes at all —
  a stale token can't 401 a probe — unthrottled): DB SELECT 1 + (when
  REDIS_URL is set) a cache set/get probe; {"status":"ok"} 200 exact
  (smoke-pinned) or 503 {"status":"degraded", <component>: <why>}.
  Registered as a static path in config/urls.py before every include;
  /api/health/ can't be swallowed by games/<code>/ (different prefix —
  checked). Both compose files: api healthcheck via a python -c urllib
  probe (the image has Python; no curl added); db/redis keep their native
  pings.
- **I4 deploy check pass** (run with DEBUG=false + prod-ish env). FIXED:
  SESSION_COOKIE_SECURE + CSRF_COOKIE_SECURE auto-on under
  DJANGO_BEHIND_PROXY (safe exactly when TLS terminates in front);
  SECURE_HSTS_SECONDS env-driven default 0 (+ optional
  SECURE_HSTS_INCLUDE_SUBDOMAINS) — the owner's one-way door, documented in
  DEPLOY.md §9b. DELIBERATELY SKIPPED: SECURE_SSL_REDIRECT (Caddy already
  301s http→https at the proxy — the check's own suggested alternative),
  SECURE_HSTS_PRELOAD (an explicit browser-list submission, not wanted),
  W005 subdomains (owner's env call), SECRET_KEY (already env-driven).
- **I5 logging:** a modest LOGGING dict — console handler, INFO root (in
  dev too: a DEBUG root drowns the console in asyncio/SQL chatter),
  disable_existing_loggers=False so Django's request-error logging keeps
  propagating. accounts.emails' send-failure warning verified surfacing on
  the console via the suite's forced-failure test (visible in the run log:
  "Email send failed … RuntimeError: ESP down"). Known cosmetic effect:
  django.request 4xx warnings now echo during test runs. Sentry stays §M.
- DEPLOY.md §9b (new): health-check verification, the 2-machine
  X-Forwarded-For confirmation recipe, the HSTS flag, media-bucket
  lifecycle note; §9's pg_dump cron already existed and stands.

### Tests & verification

- Suite: **204 → 252 green** (SQLite fallback; compose = owner-run).
  New: MultiCategoryApiTests (8), BulkPipeCategoryTests (6),
  SimilaritySharesAnyCategoryTests (1), CategorySoftDeleteTests (10 — the
  F5 absence audit incl. played-category delete with intact report/snapshot,
  name reuse, quota counters, orphan behavior), ThemeApiTests (5, incl.
  seed idempotence), MultiCategoryBoardTests (5 — no-duplicates, overlap
  shortage + order-dependent attribution both ways, deleted-id, replace
  regression), CellsRemainingTests (1, whole tiny board),
  AuthThrottleTests (4), ThrottleIdentTests (3), HealthCheckTests (4).
  Updated pins: category_names in the moderation list, revise-copies-
  categories, test helpers to M2M.
- Smoke: extended (health pin, themes shape, cells_remaining ×2) and green
  TWICE on pristine seed; server started/stopped per §D (and yes — C8
  demonstrated itself again when a cleanup pkill-alike matched its own
  compound command; killed by PID as instructed).
- `npm run build` clean. `manage.py check` clean; `check --deploy`
  disposition above.
- Files changed: backend — trivia/{models,serializers,views,bulk_upload,
  moderation,similarity,urls,admin,themes(new),tests,
  migrations/0005(new,hand-written),migrations/0006(new),
  management/commands/seed_demo}.py; games/{services,serializers,tests}.py;
  accounts/{quotas,emails,views,throttling(new),tests}.py;
  config/{settings,urls,health(new)}.py. Frontend — lib/api.js,
  pages/{CreatePage,HostPage,ModeratePage,BoardPage,BuzzerPage}.jsx,
  styles.css, public/question-template.csv,
  public/question-media-template/questions.csv. Root —
  backend_smoke_test.py, docker-compose.yml, docker-compose.prod.yml,
  DEPLOY.md, CHANGES.md.


---

# Changed files from this session — unzip over the repo root

## Session: site chrome + auth everywhere · winner takeover + answer pop · age gate · question lifecycle · admin user management · transactional email (Handoff #9 §F–§K)

**⚠️ Open item 1 — MIGRATIONS ARE NOT IN THE ZIP (by design).** This session
adds model fields (accounts.User.limit_overrides; trivia.Question.deleted_at
+ Question.replaced_by) but the generated migration files are deliberately
excluded per the deliverable box: after unzipping, run
`python manage.py makemigrations && python manage.py migrate` (in prod: run
makemigrations, commit the files, then deploy — the prod entrypoint only runs
`migrate`). All changes are additive (a defaulted JSONField, a nullable
DateTimeField, a nullable self-FK) — safe against the live database.

**⚠️ Open item 2 — compose runs (owner-run).** No Docker in this build
sandbox (same as #7/#8), so the environment-parity rule's compose runs
(suite + smoke through Postgres + Redis) are OWNER-RUN. Verified here
instead: the full suite 155 → **204 tests** green on the SQLite fallback;
`backend_smoke_test.py` (extended with §K's password flows) green TWICE
against a live local server on pristine seed (twice = the change-password
round-trip really is re-runnable); the library / revise / delete / users
endpoints additionally hand-exercised live with a staff account (revise
lineage visible in ?deleted=only, staff delete 200→409, users PATCH
round-trip, is_staff-in-body 400); `npm run build` clean.

**⚠️ Open item 3 — Resend / DNS / email verification (owner-run).** The
suite verifies email logic against Django's locmem backend and the live
smoke sees the console backend print real reset links; a REAL end-to-end
send can only be done by you:
1. Resend dashboard → add **drinkquiry.com** as a domain and create the
   SPF/DKIM DNS records it shows you. **No new API key is needed** — Resend
   keys are ACCOUNT-scoped; domains are verified per-domain within the
   account, so your existing eventquiry key sends for drinkquiry.com once
   the domain is verified.
   (Answering your question directly: sending `From: …@eventquiry.com`
   WOULD work today since that domain is already verified — but the
   from-domain vs link-domain mismatch (links point at drinkquiry.com)
   reads phishy to humans and spam filters. Fine as a brief stopgap by
   pointing DEFAULT_FROM_EMAIL at eventquiry.com; not recommended to keep.)
2. Prod `.env`: set `RESEND_API_KEY`, `DEFAULT_FROM_EMAIL`,
   `FRONTEND_BASE_URL` (all documented in .env.production.example, which
   this zip updates). Unset key = console backend (dev-safe default).
3. `docker compose build api` — requirements.txt gained **django-anymail**
   (the plain package; the Resend backend speaks HTTP via requests, no
   [resend] extra exists to install — verified against anymail 15.0,
   pinned `>=13`).
4. Run one real flow on prod (forgot-password to your own address is the
   easiest full round-trip).

### §F — Site chrome: SiteNav + auth everywhere

- **frontend/src/components/SiteNav.jsx (new):** wordmark→/, links Host /
  Make questions / Profile (+ Moderate only when the PROFILE says is_staff —
  cosmetic gate as always, per-token cached in module state), auth corner
  (signed out → "Log in" → /login; signed in → display name + Log out).
  Logout calls the real `/api/auth/logout/` (Knox revokes server-side,
  best-effort .catch), clears dq_auth, navigates home. Chalkboard-native:
  thin --line bottom border, --dim links hover --paper, active route --gold,
  wraps on mobile (no hamburger — the link count is small).
- **Where it renders:** App.jsx wraps a `ChromeLayout` (SiteNav + Outlet)
  around `/`, `/login`, `/reset-password`, `/host`, `/create`, `/moderate`,
  `/profile`. NOT on `/board/:code` (clean TV) and NOT on
  `/game/buzzer/:code`. **Delegated extension:** you said "except the game
  board"; the buzzer is excluded for the same reason (full-screen party
  surface for account-less guests). One-line revert: move its `<Route>`
  inside ChromeLayout in App.jsx. Note: the board route in the tree is
  `/board/:code` (the handoff doc said `/game/board/` — followed the tree).
- **Live auth state:** storage.js saveAuth/clearAuth now dispatch a
  `dq-auth-changed` window event; the nav (and each auth-gated page)
  listens, so a login from any inline AuthScreen or a logout from the nav
  updates everything instantly. api.js's dead-token cleanup now calls
  clearAuth() instead of a raw removeItem for the same reason.
- **frontend/src/components/AuthScreen.jsx (new; §F1):** extracted verbatim
  from HostPage.jsx (behavior identical), plus §K1's "Forgot password?"
  path. HostPage re-exports it (`export { default as AuthScreen } ...`) so
  any old import path keeps working; ProfilePage imports from the new home.
- **/login route (§F3):** renders AuthScreen; after auth navigates to
  `?next=` if present, else /host. /create and /moderate's "Go to login"
  buttons now point at `/login?next=…` instead of /host.
- **Header dedup (delegated call, flagged):** with the SiteNav carrying
  identity + cross-links + logout, the per-page pageheads on /host (create
  screen), /create, /moderate and /profile were REMOVED — one identity bar
  per page, not two stacked ones. The live host panel keeps its
  game-specific header (code chip, connection dot, board link, finish)
  minus the now-duplicate wordmark. /host and /profile keep their inline
  AuthScreen fallback exactly as before. The landing footer's
  Host/Make questions/Profile links were removed (same list as the nav
  directly above); wordmark + drink-responsibly line stay.

### §G — Board feel: winner takeover + the answer pops

Frontend-only, zero backend change — both features render snapshot fields
that already exist, so WS and polling boards get them identically (§C2).

- **G1 takeover (BoardPage):** when `current_cell.last_judgment.correct ===
  true`, a fixed full-screen overlay (chalkboard-dark, teal radial glow)
  takes the TV: "✔ CORRECT" eyebrow, the winner's NAME at
  clamp(56px, 13vw, 200px) in the display face — one line,
  nowrap/hidden/ellipsis at max-width 92vw (your call: truncation over
  shrink-to-fit), the revealed answer beneath it in the §G2 card, and the
  drink attribution line rendered LIVE on the overlay (the drink is
  assigned while it's up). Lifetime == the judgment marker's; #8's clearing
  semantics (close, reset, explicit reopen, next buzz, next cell) already
  cover every exit. WRONG keeps #8's red banner only — no takeover. Scale/
  fade entrance; the existing global prefers-reduced-motion kill-switch
  covers all new animations.
- **G2 answer card (BoardPage):** diagnosis per the handoff — the answer was
  big but competing. Fix by subtraction: while `revealed_answer != null`
  the question text, media and value chip drop to 0.25 opacity
  (`.tv__question--revealed`, CSS transition), and the answer moves into
  `.tv__answercard`: near-black rounded card, faint gold border,
  strengthened glow, small "THE ANSWER" eyebrow, ~200ms scale-in. Built as
  one reusable class — the same card renders inside the G1 takeover
  (slightly smaller text via a --takeover modifier) and for the host's
  explicit "nobody got it" reveal on the dimmed page. The old bare
  `.tv__answer` style is superseded on the board (class left in CSS,
  harmless).

### §H — Age gate

- **frontend/src/components/AgeGate.jsx (new):** rendered at the App level
  above ALL routes (buzzer and board included). Title "One thing first —",
  body "Drinkquiry is trivia with drinking-game references. Points mode is
  for everyone; drinks mode is for adults." Primary "I'm of legal drinking
  age" (autofocused; Escape does nothing — it must be answered), secondary
  "I'm not" → friendly decline note ("come back with the grown-ups, or ask
  your host to run points mode") with a back link. Permanent "Drink
  responsibly. 🍻" line on both paths. It's a good-faith notice and the copy
  doesn't pretend otherwise.
- **Persistence:** localStorage key **dq_age_ack_v1** (ISO timestamp) via
  new storage.js helpers loadAgeAck/saveAgeAck — versioned so a future copy
  change can re-prompt; confirmed once → never again on that browser.
- **Noted wrinkle:** on a TV/QR-scan flow the modal renders above the join
  screen once; first tap dismisses it and the join form is right there —
  acceptable friction, by design.

### §I — Question lifecycle: soft delete, versioned edits, admin library

- **Model (trivia/models.py):** `Question.deleted_at` (null = active; the
  ONLY liveness flag, no boolean twin) and `Question.replaced_by`
  (self-FK, SET_NULL, related_name="replaces") — the §I3 lineage pointer.
- **The absence audit** — every "active questions" surface now filters
  `deleted_at__isnull=True`, each pinned by its own test:
  `games/services.usable_questions` (game builds AND the §J3 replace pool),
  `Category.usable_question_count`, `QuestionViewSet.get_queryset` (public
  + owner listings; get_object routes through it, so a deleted question
  404s on retrieve/PATCH/DELETE/report), the moderation pending queue AND
  the counts badge (so the number matches the list), the flags list
  (belt-and-suspenders — delete/revise resolve flags themselves), the
  similarity candidate pool, and the bulk-upload duplicate check (deleting
  a question and re-uploading the same text works). **Audit finding beyond
  the handoff's list:** the QUOTA counters (accounts/quotas.questions_used
  and storage_bytes_used) also had to exclude deleted rows — otherwise a
  user who deletes everything stays at their limit forever, and the
  existing SMOKE_MEDIA cleanup's "quota freed" guarantee would silently
  break. Deliberate small mismatch, documented in the code: a deleted
  question's media FILES stay on disk/bucket (live snapshots of games
  containing it still serialize the media) but stop counting against
  storage quota. Deleted rows deliberately REMAIN in: board cells,
  snapshots, finished reports, game history, usage_count aggregates.
- **Owner delete (§I2):** QuestionViewSet.perform_destroy → soft delete,
  usual 204. Uniform rule, no never-played special case — this also makes
  the latent bug unreachable (BoardCell.question is PROTECT, so
  hard-deleting any ever-played question was a guaranteed ProtectedError
  500). Pinned: deleting a PLAYED question succeeds and the finished
  report still shows its text.
- **Staff delete (§I2):** POST /api/moderation/questions/<id>/delete/ —
  any owner's question; 409 if already deleted; resolves open flags (the
  report rows persist as history). Restore/un-delete punted (§M — the row
  is intact, cheap later).
- **Revise (§I3):** POST /api/moderation/questions/<id>/revise/ with any
  subset of {question_text, answer, difficulty (1–5), visibility}. One
  transaction: NEW row copying all fields + edits, same owner/category,
  media files kept BY NAME REFERENCE (two rows, ONE stored file — a future
  hard-purge must never delete files a replacement still references;
  media re-upload is §M); new row is **approved** (delegated default:
  staff edits don't re-enter their own queue — one line to flip to
  PENDING); old row soft-deleted + replaced_by set + open flags resolved.
  409 on already-deleted. Returns the new row (201) in the moderation
  serializer shape. **Games already built keep the OLD text** — cells
  point at the old row; a mid-game swap under players would be worse
  (stated in the docstring, pinned by test).
- **Library API (§I4):** ModerationQuestionViewSet.list grew:
  `?search=` (question_text OR answer icontains), `?category=<id>`,
  `?status=` gains the NEW value `all` (existing values and the queue's
  pending default untouched — C4-style additive), `?owner=` (email
  icontains; the value `official` → owner__isnull=True), `?deleted=`
  active(default)/only/all — the ONE staff surface where deleted rows are
  visible (serializer now carries deleted_at + replaced_by), `?ordering=`
  whitelisted to created_at/-created_at/usage_count/-usage_count (id
  tiebreak for deterministic pages), page_size 25 (LibraryPagination).
  Filters COMPOSE — the frontend always sends status=all for the library.
  Review actions (approve/reject) now 409 on a deleted question. The
  pending-queue default view is pinned unchanged by a dedicated test; the
  queue tabs' allPages just sees smaller pages (25 vs 50) and behaves
  identically.
- **Library UI (§I5):** fourth /moderate tab "Library" (staff chrome/toast
  plumbing reused, as prescribed). Debounced (~300ms) search with a
  stale-response sequence guard, selects for category/status/deleted/
  ordering (component state — URL-string state skipped as not "easy" in
  this tree, noted), compact rows (2-line-clamped text, answer, badges for
  status/deleted/superseded-by-#id, usage, owner, created/deleted date),
  prev/next + "page X of Y · N questions" from count. Per-row: Edit →
  inline ReviseForm → on 201 the row swaps to the NEW question with a
  toast; Delete → one-click inline confirm → deleted badge (409 from a
  racing reviewer handled). Deleted-only view is read-only. **The library
  fetch returns {results, count, next, previous} as-is via
  api.moderationLibrary — never allPages** (that helper stays for the
  small queue worklists).

### §J — Admin user management

- **Payments truth (stated in the UI, the module docstring, and here):**
  there is NO payment system in the codebase — nothing to "view". `plan`
  is hand-set. "Grant create access" and "override payment for a demo" are
  both plan=creator (a demo adds plan_expires_at — the existing expiry
  machinery lapses it to free automatically); "up their allowances" is the
  new per-user override. The Users tab shows plan + expiry + an explicit
  "billing: not wired yet — plans are set manually here" note. Stripe is
  §M.
- **§J1 — User.limit_overrides (JSONField, default dict):** same keys as a
  PLAN_LIMITS entry (games_per_month/categories/questions/storage_bytes),
  all optional; a key REPLACES the plan value; null = unlimited; missing =
  plan default. Wired in exactly ONE place — quotas.limits_for() does
  `dict(plan_base).update(overrides)` — so every quota check, every
  structured 403's `limit`, and the profile meters pick overrides up with
  no other change (pinned: boundary 403 carries the OVERRIDDEN limit).
  **Pinned as intended:** overrides apply to the EFFECTIVE plan's base,
  i.e. they survive a plan lapse — a grant to the USER, not the plan.
  Validation (quotas.validate_overrides, shared with the PATCH): known
  keys only, values null or int ≥ 0, bools rejected. Module docstring
  updated ("per-plan defaults + per-user JSON overrides").
- **§J2 — API (accounts/admin_api.py + admin_urls.py, new):** mounted at
  /api/moderation/users/ from config/urls.py BEFORE trivia's include
  (static-before-parameterized house rule; staff namespace stays uniform
  while the code lives with accounts). GET list: page_size 25, ?search=
  (email OR display_name icontains), ?plan=, ?is_staff=, -date_joined
  default; row = id/email/display_name/plan/**effective_plan** (so a
  lapsed demo is visible as creator-but-effectively-free)/plan_expires_at/
  is_staff/date_joined/limit_overrides + the usage block via
  quotas.usage() (a few COUNTs per row × 25 — fine, not prematurely
  optimized, per the handoff). PATCH <id>/: accepts plan/plan_expires_at/
  limit_overrides ONLY; **any other body field → 400** (the delegated
  ignored-or-400 pick: silently ignoring a privilege-looking field like
  is_staff would be worse than refusing; pinned). is_staff/email/password
  are NOT editable here — staff-granting stays in Django admin/shell so a
  compromised moderator account can't mint staff (docstring). Both
  endpoints IsAdminUser (non-staff 403 / anon 401 pinned).
- **§J3 — UI:** fifth /moderate tab "Users". Search + plan filter,
  paginated like the library. Row header: name/email, staff badge
  (read-only), plan chip with "(lapsed → free)" when expiry has passed, a
  "custom limits" badge when overrides exist. Expanded card: plan select +
  expiry date input with the demo recipe spelled out ("Demo access:
  creator + an expiry — it lapses to free automatically"); the four
  allowance fields as number inputs each with an "unlimited" checkbox
  (null) and the plan/effective limit as placeholder, current usage
  beside each; Save → PATCH → toast; the honest payments note.

### §K — Transactional email (Resend via Anymail)

- **Settings (env-driven, zero-code domain switch):** RESEND_API_KEY set →
  anymail Resend backend; unset → console backend (dev + local smoke; the
  suite uses Django's locmem regardless). DEFAULT_FROM_EMAIL (default
  "Drinkquiry <hello@drinkquiry.com>") and FRONTEND_BASE_URL (reset links;
  default the Vite dev origin). Three vars documented in
  .env.production.example with the full domain guidance (see Open item 3).
- **accounts/emails.py (new):** ONE send body (_send) — default from,
  catch-Exception, log a warning, never raise. **Sending never breaks the
  action** (pinned twice: a raising backend doesn't 500 approve, doesn't
  500 password-change). Plain text; HTML templates are §M.
- **§K1 forgot/reset:**
  POST /api/auth/password/forgot/ {email} — ALWAYS the identical 200 body
  whether or not the account exists (pinned, suite + smoke). Existing
  account → link `{FRONTEND_BASE_URL}/reset-password?uid=<b64 pk>&token=…`
  via Django's default_token_generator. Cooldown: per-user 60s via
  cache.add (atomic set-if-absent) — hitting it silently SKIPS THE SEND
  and never changes the body (enumeration again; pinned). Per-IP limiting
  is §M. POST /api/auth/password/reset/ {uid, token, new_password} —
  generic 400 on bad/expired token (never "no such user"), Django password
  validators, then **revokes EVERY Knox token** for the user (pinned: old
  token 401s). Frontend: "Forgot password?" on AuthScreen's login mode →
  tiny email form with always-success copy; new /reset-password route
  (ResetPasswordPage.jsx) reads uid/token from the query, new-password ×2
  form, success → /login.
- **§K2 change password:** POST /api/auth/password/change/
  {current_password, new_password} — Knox-authed; wrong current → 400;
  validators; keeps THIS request's AuthToken and deletes every other one;
  sends the "if this wasn't you…" notification (fail-silent). Frontend: a
  collapsible "Change password" panel on /profile (current + new + confirm,
  success toast).
- **§K3 approval notifications:** the queue's _act (approve AND reject) and
  the flag-resolve reject all call one helper,
  send_moderation_outcome_email(item, approved, actor). Approve: "Your
  {question|category} was approved" naming the item (+ category for
  questions). Reject includes the moderation note — **delegated default:**
  you asked for approved; reject-with-reason is the same hook and kinder
  than silence (one `else` branch to remove). Skips: owner is None
  (official) and actor == owner (staff self-review noise). All pinned
  (content, both skips, category flavor, flag-resolve path, raising
  backend).

### Tests & smoke (§L)

- Suite **155 → 204** (`python backend/manage.py test accounts trivia
  games`), all green on the SQLite fallback. New: the §I absence audit
  (one test per surface incl. the quota counters), destroy-on-played +
  report intact, revise lineage/validation/409s/media-by-reference/
  played-games-keep-old-text, library search/owner=official/deleted-only/
  ordering-whitelist/pagination-shape/25-page-size, pending-queue-default
  pinned, staff-only 403s, review-actions-409-on-deleted; §J limits_for
  merge semantics, overridden-boundary 403, profile meters,
  lapse-with-overrides, validate_overrides, users list/search/filters/
  PATCH round-trip/validation/is_staff-400/staff-only+anon; §K forgot
  parity + cooldown + token round-trip killing Knox + bad-token 400s +
  weak-password 400, change wrong-current/keeps-current-kills-others/
  notification/anon-401/raising-backend, §K3 email content + all skip
  rules + flag-resolve + raising-backend-on-approve.
- Smoke: §K4 additions only — password_flows() runs LAST (its second
  change revokes the run's original token, used by nothing afterwards):
  wrong-current 400 → change → current token survives + old password
  rejected → re-login with the new password → change BACK → original
  login works (RE-RUNNABLE, proven by running the whole smoke twice on
  one DB); forgot with the real smoke email vs a randomized ghost email →
  identical 200s (randomized so the cooldown can't diverge quick
  re-runs). No delivery assertions in smoke (console backend prints to
  the server log — verified the reset email + working link appears
  there). Full smoke green end-to-end on pristine seed_demo (the 5×5
  usable_question_count assumption is untouched by the soft-delete
  filters — verified live). Approval-email flows stay suite-only (smoke
  has no staff user by design — its non-staff 403 checks depend on that).

### Files

New: backend/accounts/admin_api.py, backend/accounts/admin_urls.py,
backend/accounts/emails.py, frontend/src/components/AuthScreen.jsx,
frontend/src/components/SiteNav.jsx, frontend/src/components/AgeGate.jsx,
frontend/src/pages/ResetPasswordPage.jsx.
Modified: backend/accounts/{models,quotas,views,urls,tests}.py,
backend/config/{settings,urls}.py, backend/games/services.py,
backend/trivia/{models,views,serializers,moderation,similarity,
bulk_upload,tests}.py, backend/requirements.txt (django-anymail — rebuild
the api image), backend_smoke_test.py, .env.production.example,
frontend/src/App.jsx, frontend/src/lib/{api,storage}.js,
frontend/src/pages/{BoardPage,HostPage,CreatePage,ModeratePage,
ProfilePage}.jsx (BuzzerPage untouched), frontend/src/styles.css,
CHANGES.md.
(Generated locally but NOT shipped: accounts/migrations/0003_user_limit_
overrides.py, trivia/migrations/0004_question_deleted_at_question_
replaced_by.py — see Open item 1.)


---

## Session: gameplay feel + drinks overhaul + board polish + content tooling (Handoff #8 §F–§K)

**⚠️ Open item 1 — MIGRATIONS ARE NOT IN THE ZIP (by design).** This session
adds model fields/tables (Game.judged_participant/judged_correct,
BoardCell.drinks_assigned, trivia.QuestionReport) but the generated migration
files are deliberately excluded per the handoff's deliverable box: after
unzipping, run `python manage.py makemigrations && python manage.py migrate`
(in prod: exec into the api container, or just `docker compose up -d --build`
AFTER makemigrations has produced the files and they're committed — the prod
entrypoint only runs `migrate`, it does NOT makemigrations). All changes are
additive (nullable FKs / defaulted bool / a new table), safe against the live
database.

**⚠️ Open item 2 — compose runs.** This session's environment had no Docker
(same as #7), so the environment-parity rule's compose runs (Django suite +
smoke through Postgres + Redis) are OWNER-RUN. Verified here instead: the
full suite 109 → **155 tests** green on the SQLite fallback;
`backend_smoke_test.py` (extended, see below) green end-to-end against a live
local server; every new endpoint additionally hand-exercised live (host-seat
token equality with the created game's token, board detail + replace with
no-duplicate assertion, flag 201→409 with status untouched); the frontend
builds clean with the one new dependency.

New files:
- backend/trivia/similarity.py — §K1 dependency-free near-duplicate ranking:
  normalize (casefold, strip punctuation, drop stopwords), Jaccard on the
  remaining significant words, candidates from the same category with a
  global fallback when the category pool is thin (< 5), top 5 returned with
  the §J1 usage count and the answer. A review AID only — nothing acts on it.
- (generated locally, NOT shipped): games/migrations/0004_*,
  trivia/migrations/0003_questionreport.py — regenerate on your side.

Backend (modified):
- backend/games/models.py — §F: Game.judged_participant (nullable FK,
  SET_NULL) + judged_correct (nullable bool), the persisted marker behind the
  snapshot's current_cell.last_judgment; clearing points documented on the
  field. §G: BoardCell.drinks_assigned (default False), the once-per-cell
  marker.
- backend/games/services.py — the big one. (1) §F judge_buzz moved here from
  the consumer: judging CORRECT now ALSO performs the reveal via the same
  _perform_reveal body the explicit reveal uses (rule 5: revealed_answer
  stays the only vehicle; no new answer path) and sets the judgment marker;
  judging WRONG sets the marker, does NOT reveal, and keeps the automatic
  buzzer reopen — which deliberately does NOT clear the marker (the "✘ WRONG"
  banner must be visible). Marker cleared at: open_cell, close_cell,
  reset_buzzer, EXPLICIT host open_buzzer, the NEXT buzz (a new team
  supersedes the old verdict on screen), finish_game; lock_buzzer keeps it.
  (2) §G assign_drink: single mutation for the player's give_drink and the
  host's assign_drinks fallback; validates drinks mode + judged-correct
  current cell + (for non-host actors) sender IS the winner; checks-and-sets
  drinks_assigned inside the row-locked transaction; second attempt raises
  StructuredActionError with the documented {"detail", "code":
  "drinks_already_assigned"} payload (lesson C4: exact shape). ANY seat is a
  valid target — host included — and self-assignment is allowed (comment
  marks the one-line forbid spot). The old host-path exclusion of the winner
  as a target is gone (owner-approved). Winner credit (drinks_given + score)
  unchanged. (3) §J2 draw preference: usable questions annotated with
  host_uses (cells in THIS host's games) + global_uses (all games), ordered
  difficulty → host_uses → global_uses → random. Difficulty stays the primary
  key (same difficulty-slot behavior; Python's stable sort preserves the
  preference within each difficulty), the 3× fetch window and the shortage
  400 contract are unchanged, and usage is DERIVED from the cells table — no
  counter columns (§J1 derive-first). (4) §J3 replace_cell_question:
  lobby-only single-cell redraw — same category, closest difficulty to the
  outgoing question (Abs(F(difficulty) − old)), §J2 preference order,
  excluding every question already on the board. (5) The remaining consumer
  bodies (register_buzz, set_buzzer, reset_buzzer) moved here too since §F
  changes them (marker clearing); behavior otherwise byte-identical,
  including the check ORDER in register_buzz (locked-check before the
  duplicate-buzz IntegrityError, as before).
- backend/games/consumers.py — thin database_sync_to_async wrappers around
  services for everything now; NEW player action give_drink
  {target_participant_id} handled BEFORE the host-only gate; assign_drinks
  routes into the same services.assign_drink; the error relay spreads a
  StructuredActionError's payload into the frame ({"type","detail","code"})
  while plain ActionErrors stay {"type","detail"} exactly as before. Header
  docstring updated. No reveal event is emitted on judge-correct — both
  frontends already prefer the snapshot's revealed_answer (§B4), and the
  judgment broadcast IS a snapshot.
- backend/games/serializers.py — OpenCellSerializer gains last_judgment
  ({participant_id, name, correct} | null; reads the root serializer's Game
  instance so no extra query in the nested case), drinks_assigned, and
  drink_assignment ({from/to ids+names, amount} | null; oldest assignment
  first so pre-#8 games that had host-spam duplicates show their first).
  Still deliberately NO question id in the open cell (an authenticated user
  could resolve an id to its answer via /api/questions/ — a rule-5 side
  door; noted in the docstring). New host-private BoardDetail* serializers
  (§J3): per-cell question_id + text + ANSWER + difficulty — the host's own
  board, never any part of a snapshot.
- backend/games/views.py — §H1: join name normalized .strip().upper() BEFORE
  the uniqueness/create logic, so the name-taken 400 and the IntegrityError
  race path both see the normalized value; rejoin is by token so pre-§H1
  mixed-case seats keep reclaiming (pinned by test). §I: GameHostSeatView
  (GET /api/games/<code>/host-seat/, Knox host-only → {participant,
  participant_token}) — the ONE new endpoint resume needed; history already
  listed unfinished games (no status filter) so it only gained a pinned test
  + docstring. §J3: GameBoardDetailView (GET .../board/, host-only) and
  CellReplaceView (POST .../cells/<id>/replace/, host-only; ActionErrors →
  plain {"detail"} 409: started / no-such-cell / nothing-left-to-swap). The
  snapshot view select_relates judged_participant (no N+1 for the marker).
- backend/games/urls.py — the three new routes.
- backend/trivia/models.py — §K2 QuestionReport (question FK, reporter FK,
  optional reason, status open/resolved, created_at) with a PARTIAL unique
  constraint: one OPEN report per (question, reporter) — the trivial rate
  limiter; once resolved the same host may flag again. Filing never touches
  moderation_status (the feature's explicit ask). Docstring documents what
  reject actually does to an approved question.
- backend/trivia/views.py — §K2 POST /api/questions/<id>/report/: any
  AUTHENTICATED host (get_permissions bypasses IsCreator for this action —
  flagging isn't content creation, so free-plan hosts can flag; visibility
  scoping still applies via get_queryset). Second open flag → 409 (pinned;
  the doc said pick 400 or 409 — 409 matches the moderation double-act
  guard's flavor). IntegrityError caught OUTSIDE the atomic block (house
  pattern).
- backend/trivia/serializers.py — §J1 _UsageCountMixin (annotation-first with
  a counting fallback) on both moderation serializers: questions = cells
  referencing it across all games; categories = board columns (unique per
  (game, category), so column count == game count). §K2
  FlaggedQuestionSerializer: the moderation question shape + open reports
  (reporter, reason, created_at) + report_count.
- backend/trivia/moderation.py — §J1 usage_count annotations in both
  viewset querysets. §K1 GET /api/moderation/questions/<id>/similar/ — a
  detail sub-endpoint (chosen over a `similar` block on the list serializer
  so the queue page stays snappy; the frontend fetches per card); works for
  any status so the Flagged tab reuses it. §K2 ModerationFlagsView (GET
  /api/moderation/flags/ — questions with open reports, oldest flag first,
  unpaginated worklist) + ModerationFlagResolveView (POST
  .../flags/<qid>/resolve/ {"action": "dismiss"} or {"action": "reject",
  "note": ...}; reject applies the SAME field semantics as the queue's
  reject — status=rejected + note, note required — and both resolve all open
  reports; resolving with nothing open → 409 mirroring the double-act
  guard). The pending queue's approve/reject endpoints are UNTOUCHED (still
  pending-only 409 — pinned by a new test); /api/moderation/counts/ keeps
  its exact pre-#8 shape (smoke asserts set(counts) == {categories,
  questions}) — the Flagged tab counts from its own list instead.
- backend/trivia/urls.py — the two flag routes (static, before the router).

Frontend (modified):
- frontend/package.json (+ package-lock.json) — ONE new dependency per the
  §H4 policy: qrcode.react (^4.2.0, tiny, maintained, renders SVG locally,
  zero network calls). Everything else is dep-free as before.
- frontend/src/lib/api.js — gameHostSeat, gameBoard, replaceCell,
  reportQuestion, moderationSimilar, moderationFlags, moderationFlagResolve.
- frontend/src/pages/BoardPage.jsx — §F: with a verdict present the board
  LEADS with a big "✔ CORRECT — TEAM" / "✘ WRONG — TEAM" banner
  (teal-gradient / chalk-red) and the revealed answer directly under it;
  while a verdict OR revealed answer is on screen the buzzer-lock chip is
  not rendered AT ALL (no green→red flash — the lock is implied) and the
  buzz list yields the floor. All derived from snapshot fields, so WS and
  polling boards behave identically (§B4) — zero hook changes. §G: drink
  attribution line ("TEAM A sends 1 drink to QUIZMASTER 🍺") from
  current_cell.drink_assignment; the footer drink tallies gain a labeled
  🎤 host row ONCE the host has taken a drink (chosen presentation: labeled
  row, drink displays only, never score displays — a permanent zero-row for
  the host read as noise). §H4: QR on the lobby (absolute buzzer URL from
  window.location.origin — never a hardcoded domain) on a white rounded
  tile with quiet-zone margin, sized to scan from a couch.
- frontend/src/pages/BuzzerPage.jsx — §H1: join input uppercases the VALUE
  in the change handler + .capsinput CSS (server normalizes again; cosmetic
  per rule 4). §F: verdict banner ("You got it! 🎉" / "Wrong — drink's
  coming 🍻" for the judged team, "X got it" / "X whiffed — buzz in!" for
  the rest) from last_judgment + own participant id. §G: when this seat IS
  the judged-correct winner and current_cell.drinks_assigned is false, a
  "Who drinks N 🍺? Your call." picker over ALL seats — themselves labeled
  "(us!)", the host labeled "(the host)" — sending the new give_drink
  action; once assigned, an attribution line ("… sends 1 🍺 to YOU — drink
  up!" when targeted). Enabled/disabled all snapshot-derived (rule 1).
- frontend/src/pages/HostPage.jsx — §G: the assign panel now leads with
  "THEIR phone picks who drinks" (the winner assigns; the host panel is the
  labeled fallback), targets ALL seats (winner "(the winners)", host
  "(you)"), hides once current_cell.drinks_assigned and shows the
  attribution + "one per question" note instead. §I: resumeHostGame()
  exported helper (host-seat fetch → saveSeat + saveHostGame) + a "Pick up
  where you left off" panel on the create screen listing unfinished games
  with Resume. §J3: LobbyPreview panel in the lobby — per-category
  expandable question lists from the host-private board detail (question +
  answer + value), per-row ↻ Replace (patches the returned cell in place;
  409s toast) and 🚩 flag. §K2: FlagButton (exported) also under the
  host-private answer card on the open cell — question_id comes from the
  §F1 answer endpoint's response (captured alongside the answer), NOT from
  the public snapshot. A host 409 on flag renders as already-done.
- frontend/src/pages/ProfilePage.jsx — §I: unfinished history rows get a
  ▶ Resume control (shared resumeHostGame, then navigate to /host where the
  normal connect flow reattaches).
- frontend/src/pages/ModeratePage.jsx — §K: third "Flagged" tab (own
  endpoint; tab count from the list length — counts/ shape untouched);
  FlaggedCard shows the question + answer + open reports with reporters and
  reasons + §J1 usage badge + §K1 lookalikes, resolved by "Dismiss flags
  (keep it)" or Reject-with-note whose UI copy documents the ACTUAL
  behavior ("unlists it from public categories and future game builds;
  games already built keep their copy"). §K1: SimilarMatches under every
  pending question card (per-card fetch; failure degrades to nothing —
  approve/reject never blocked). §J1: usage badges on question AND category
  cards.
- frontend/src/App.jsx — §H5: a real landing page. Hero keeps the join-code
  input as the undisputed #1 job (one screen-ish on mobile), new one-line
  pitch ("Bar trivia where the losers drink."), Host CTA, a three-step
  how-it-works strip (laptop → TV → phones), footer with nav + a wink.
- frontend/src/styles.css — §H2: .tv__answer scaled to clamp(44px, 7.5vw,
  96px) gold with glow (the star of the moment). §H3: .tv__joiner,
  .tv__score, .scorecard rebuilt as 3D chalk buttons (bigger radius,
  layered drop + inset shadows, subtle gradient; offline state gets a
  pressed-in inset so connected/offline still reads; buzz flash untouched).
  New: verdict banners (board + phone), drink picker/attribution styles, QR
  tile, resume rows, lobby preview list, flag/similar/usage styles, landing
  page sections. Token block untouched.

Tests (109 → 155):
- backend/games/tests.py — JudgmentFlowTests (judge-correct reveals WITH the
  judgment + marker shape; judge-wrong doesn't reveal and the marker
  SURVIVES the auto-reopen; clears at close/reset/explicit-reopen/next-buzz
  and next cell opens clean; lock keeps it; idempotent when host revealed
  first), DrinkAssignmentTests (winner-from-phone; second attempt BOTH
  paths → StructuredActionError with the exact 2-key payload; non-winner
  rejected; host fallback consumes the same marker; host-as-target;
  self-target; snapshot assigned+attribution shape; no drinks without a
  judged-correct current cell; points mode refused),
  JoinNameNormalizationTests (uppercased server-side; case variants collide
  → 400; pre-existing mixed-case seat rejoins by token → 200 name
  unchanged), ResumeTests (history flags lobby/active/finished; host-seat
  exact shape + token; rival 403 with no token leak; anon 401; unknown
  404), DrawPreferenceTests (next game avoids this host's used questions
  when alternatives exist; falls back to repeats when they don't; other
  hosts' usage only breaks ties; shortage message pinned verbatim; a USED
  easy question still beats an UNUSED hard one for the top row — difficulty
  slotting wins), BoardDetailAndReplaceTests (host sees questions+answers;
  rival 403/anon 401 with no SECRET- leak; replace picks the
  closest-difficulty spare and excludes the board; 409 when nothing left;
  409 after start; host-private). One pre-existing assertion updated for
  §H1 ("Team A" → "TEAM A" in the snapshot) — the only test the session
  changed rather than added.
- backend/trivia/tests.py — SimilarQuestionsTests (planted near-duplicate
  ranks first with usage_count + answer; never matches itself; staff-only;
  list carries usage_count after a real game references a question),
  QuestionFlagTests (free-plan host can flag; second open flag 409 pinned,
  different reporter fine; anon 401; flagging changes NOTHING — status,
  category listings, usable_questions all untouched; Flagged tab staff-only
  with report_count/reports/usage/answer; dismiss keeps + closes + re-flag
  possible + double-resolve 409; reject requires note, applies the queue's
  field semantics, unlists from public listing while a game can still hold
  the question; a flag does NOT make an approved question actionable in the
  pending queue — its 409 guard pinned).
- backend_smoke_test.py — extended per §L and re-verified green live:
  lowercase 'team a' joins come back 'TEAM A' and 'team b' hits the
  name-taken 400 (§H1; all downstream name assertions updated to caps);
  judge-wrong asserts the marker + answer-still-hidden; judge-correct
  asserts revealed_answer arrives WITH the judgment (the explicit reveal
  MOVED to after the judgment so this is actually proven — it still runs and
  still asserts the legacy answer_reveal event); the WINNING team's socket
  gives the drink TO THE HOST SEAT, attribution asserted; second attempt
  from the winner AND the host fallback both assert the exact
  {"type","detail","code":"drinks_already_assigned"} frame with tallies
  untouched; reconnect/report assertions follow the drink to the host row.
  Teams A/B keep playing to the finish exactly as before.

Decisions made (owner-approved via the handoff doc; each trivially
revertible):
- Judgment marker clearing points as listed above; "next buzz clears the old
  verdict" chosen so the board flips from "✘ WRONG — X" to the fresh buzz
  the instant another team is in.
- Drinks: once-per-cell as a BoardCell bool (serializes cleanest; the
  DrinkAssignment row is the attribution record); self-assignment allowed;
  host row appears in DRINK tallies only, labeled, only once nonzero.
- Flag re-file: 409 (not 400). Board-detail endpoint: host-only, any status
  (harmless host-private; the UI only surfaces it in the lobby). Lobby
  preview includes ANSWERS (host-private, same trust level as the §F1
  answer endpoint and the finished report — the host can't vet a question
  without its answer).
- counts/ endpoint shape unchanged; Flagged tab self-counts.

NOT done / carried to §M: forbid-self-drinks toggle (comment marks the
spot), auto-flag threshold, trigram/embedding similarity, per-question
quality stats, QR table tents — plus everything already in §M.

---

## Session: media hardening + player cap + production deploy + buzzer sounds (Handoff #7 §F/§G/§H/§I)

**⚠️ Open item — compose runs.** This session's environment had no Docker, so
the environment-parity rule's compose runs (Django suite + smoke through
Postgres + Redis) are STILL OWNER-RUN and remain the prerequisite before/while
following DEPLOY.md (its top box has the exact commands). Verified here
instead: the full suite (86 → **109 tests**) green AND warning-free with
warnings escalated to errors (the `UnorderedObjectListWarning` is fixed — see
below); `backend_smoke_test.py` green end-to-end against a live local server
in BOTH media modes (local disk, and s3 against a real S3-API server — moto);
the §F1 s3 path verified end-to-end (see below); the frontend builds clean.

New files:
- backend/trivia/images.py — §F2/§F3 shared implementation: header-only
  decompression-bomb guard (`check_image_pixels`, > 40 MP rejected BEFORE any
  full decode; PIL's own `MAX_IMAGE_PIXELS` backstop set at 2× so our check —
  not a nondeterministic Pillow warning inside DRF's image field — produces
  the reject message), `maybe_resize_image` (EXIF orientation FIRST via
  exif_transpose, downscale to ≤ 1920 px longest edge, JPEG q82 for photos /
  optimized PNG when alpha, EXIF stripped by re-encode, animated GIFs left
  byte-for-byte intact, PIL-unparseable files left alone — the fake-PNG test
  fixtures pin that), and `prepare_media`, the models' save()-time choke
  point: resize runs BEFORE the file hits storage (verified: the bucket only
  ever receives the resized object) and `media_bytes`/`photo_bytes` are
  recomputed post-resize. Targeted saves (moderation's update_fields) skip
  the recount — no storage round-trips per approval.
- backend/trivia/migrations/0002_category_photo_bytes_question_media_bytes.py
  and 0003_backfill_media_bytes.py — §F3 columns + best-effort backfill from
  existing files (missing files count 0, never crash).
- backend/games/migrations/0003_participant_buzzer_sound.py — §I field.
- frontend/src/lib/sounds.js — §I: 4 distinct sub-second WebAudio-synthesized
  buzzer voices (no audio files, no deps, no licensing); `ensureAudio()` for
  gesture-time unlock, `playBuzz(n)` used by both surfaces. Display-only.
- docker-compose.prod.yml, frontend/Dockerfile, Caddyfile,
  backend/entrypoint.prod.sh, .env.production.example, DEPLOY.md — §H, the
  production stack (see below).
- docker-compose.minio.yml — §F1 opt-in overlay: MinIO + api flipped to s3
  mode for local verification of the Spaces code path. NOT in the default dev
  compose. Browser note for signed URLs documented in the file.

Backend (modified):
- backend/config/settings.py — §F1 addendum: s3 OPTIONS also wire
  `location` from AWS_S3_LOCATION (optional key prefix for sharing one
  bucket between apps, e.g. eventquiry-prod/drinkquiry/...; empty = bucket
  root, the previous behavior). Verified end-to-end against the S3-API
  server: keys land under the prefix and signed URLs include it.
- backend/config/settings.py — §F2 limits: MAX_IMAGE_BYTES 5→10 MB (now the
  reject ceiling), MAX_AUDIO_BYTES 10→8 MB, MAX_VIDEO_BYTES 50→25 MB; new
  MAX_IMAGE_PIXELS (40 MP), IMAGE_RESIZE_THRESHOLD_BYTES (1 MB),
  IMAGE_MAX_DIMENSION (1920), IMAGE_JPEG_QUALITY (82).
  DATA_UPLOAD_MAX_MEMORY_SIZE 60→10 MB with the real semantics documented:
  per the Django docs it covers the NON-file body (multipart file data is
  excluded), so the true ceilings are the per-file validators, the bulk zip
  cap (200 MB in bulk_upload.py), and the reverse proxy. §F1: s3 OPTIONS now
  wire access_key/secret_key EXPLICITLY from env (AWS_S3_* or plain AWS_*
  names) instead of boto3's implicit discovery, plus querystring_expire
  (default 1 h; snapshot refetch cadence makes expiry a non-issue — noted in
  DEPLOY.md). §F3: PLAN_LIMITS gains "storage_bytes" (free 0, creator
  500 MB; None = unlimited; a MISSING key also reads unlimited so pre-§F3
  PLAN_LIMITS overrides in tests keep working). §G:
  MAX_PLAYERS_PER_GAME = 6. §H: SECURE_PROXY_SSL_HEADER behind
  DJANGO_BEHIND_PROXY (opt-in — trusting the header off-proxy would be
  spoofable), set true in the prod env template.
- backend/trivia/validators.py — validate_image additionally runs the §F2
  pixel guard when it holds a readable file (direct path); the bulk path runs
  the SAME check on the zip member stream. Error style unchanged (DRF field
  errors / bulk row errors).
- backend/trivia/models.py — photo_bytes / media_bytes columns; Category.save
  + Question.save call images.prepare_media — the ONE choke point both the
  serializer path and bulk create_rows funnel through.
- backend/trivia/bulk_upload.py — §F2: image members get the pixel guard via
  a lazy PIL open of the member stream (no full extraction), surfaced as the
  usual row error; §F3: ParseResult.media_bytes_total accumulates the
  uncompressed bytes of accepted media rows (per row, matching what
  create_rows stores) for the batch storage check.
- backend/trivia/views.py — FIX for the compose-run warning: the Question
  list queryset (the view that tripped UnorderedObjectListWarning) and the
  Category list queryset now end in .order_by("id"). Chosen over
  Meta.ordering deliberately: the list-view fix can't regress other callers
  (board building's explicit ordering, bulk dedupe, moderation). §F3:
  storage_quota_denial on category/question create AND update-with-file
  (conservative: a replaced file's old bytes count until the row saves), and
  batch_storage_quota_denial in bulk after the questions check (denial order:
  categories → questions → storage).
- backend/accounts/quotas.py — §F3: storage_bytes_used (Sum over the
  persisted columns — never lists a bucket; row deletion frees quota because
  the columns go with the row), usage() gains the "storage" block,
  storage_quota_denial / batch_storage_quota_denial through the same
  contract: payload numbers are raw BYTES in exactly
  {"detail","code":"quota_storage","used","limit"} (+"requested" bytes from
  the batch helper), human text formats MB. quota_denial/batch_quota_denial
  untouched — no keys added to the documented shape.
- backend/games/models.py — §I: Participant.buzzer_sound (1–4, default 1,
  display-only; host seat gets one, never plays it).
- backend/games/views.py — §G: join is now atomic — select_for_update() on
  the Game row, count role=player, at/over 6 → 409 with the NEW separate
  contract {"detail","code":"game_full","limit":6} via Response(payload, 409)
  (NOT the quota helpers). The locked queryset has no select_related (lesson
  C2). Rejoin-with-valid-token is checked BEFORE the cap → still 200 at a
  full table (reload flow pinned by tests + smoke). Name-taken 400 unchanged;
  the IntegrityError is caught OUTSIDE the atomic block so the rollback is
  clean. §I: buzzer_sound assigned in the same transaction,
  (player_count % 4) + 1.
- backend/games/serializers.py — ParticipantSerializer + buzzer_sound (in
  snapshot + join response); GameStateSerializer + top-level max_players from
  settings so lobby copy stays a dumb render (rule 1). Answer serialization
  untouched (rule 5).

Frontend (modified):
- frontend/src/pages/BuzzerPage.jsx — §G: joins detect code === "game_full"
  → friendly chalkboard "table's full, share a teammate's buzzer" screen
  (cosmetic; server is the gate), with reclaim-seat offered if a token is
  held. §I: buzz press plays the player's OWN sound (press = the autoplay
  gesture; instant feedback pre-round-trip); sound id from the snapshot self.
- frontend/src/pages/BoardPage.jsx — §I: 🔊 sound toggle (default OFF, no
  persistence; the click unlocks WebAudio). WS mode consumes the hook's
  existing lastBuzz (rule 2 — useGameSocket UNTOUCHED); polling mode extends
  the same buzz-count snapshot diff the flash already used to identify the
  newest buzz and play its team's sound (§B4's house technique). Sound id
  from the snapshot's participants; falls back to the buzz order if a stale
  backend omits the field. §G: lobby shows "N/6 teams" from max_players.
- frontend/src/pages/HostPage.jsx — lobby "Teams joined (N/6)" +
  table-full hint, both from the snapshot's max_players.
- frontend/src/pages/CreatePage.jsx — §F2 copy: image ≤ 10 MB (auto-resized),
  audio ≤ 8 MB, video ≤ 25 MB in MEDIA_LIMITS, the media type options, the
  photo hint, and the bulk panel hint. §F3: usage meters gain a storage line
  through the shared UsageMeterLine (bytes formatted where the entries are
  built — fmtMB local to the page — NOT inside the shared component; entry
  skipped against older backends without the block); quotaMessage() handles
  quota_storage incl. the batch "requested" (bytes → MB at the message).
- frontend/src/pages/ProfilePage.jsx — same storage meter line, same
  build-time formatting.
- frontend/src/styles.css — tv__teamcount + tv__soundtoggle (chalkboard
  token-friendly, additive only).
- frontend/src/components/shared.jsx, lib/api.js, lib/useGameSocket.js,
  lib/storage.js — UNTOUCHED (rules 2/3; quotaError already matches
  quota_storage via its quota_* prefix; mediaUrl's contract unchanged).

Production deploy (§H, all new files above):
- docker-compose.prod.yml: db (named volume, password REQUIRED via
  ${POSTGRES_PASSWORD:?}), redis, api (image is the code — no source bind
  mount, which is what makes git-pull-and-rebuild the deploy; entrypoint runs
  migrate + collectstatic --noinput then daphne; expose-only, no host port),
  web (Caddy; ports 80/443; cert volumes persist across rebuilds), restart
  policies on everything.
- frontend/Dockerfile: node:22 builds dist → COPIED into caddy:2-alpine
  (copy chosen over a shared volume: volumes serve stale files after
  rebuilds; the copy makes `up -d --build` ship every frontend change).
  Build context = repo root so the image takes the root Caddyfile too.
- Caddyfile: {$DOMAIN} from env → automatic Let's Encrypt; /api /ws /admin
  reverse-proxied to api:8000 (WS upgrade native); /static served from the
  collectstatic volume via file_server (DELIBERATE deviation from the
  handoff's "proxy /static to api:8000" line: Django doesn't serve static
  with DEBUG=false and the doc's own settings-check bullet says "static via
  collectstatic + Caddy"); /media served from the media volume in LOCAL mode
  and simply never matched in Spaces mode (documented in-file); SPA fallback
  try_files → index.html so /host, /profile, /board/CODE survive hard
  reloads.
- .env.production.example: EVERY required var with a comment — DOMAIN,
  DJANGO_SECRET_KEY (generate command included), DJANGO_DEBUG=false,
  DJANGO_ALLOWED_HOSTS (one entry; also gates wss Origins via
  AllowedHostsOriginValidator — same-origin, so one domain covers both),
  CSRF_TRUSTED_ORIGINS (admin logins), DJANGO_BEHIND_PROXY, POSTGRES_*,
  MEDIA_BACKEND + the full Spaces block, AWS_QUERYSTRING_EXPIRE.
- DEPLOY.md: droplet (Ubuntu 24.04, 2 GB) → DNS A record BEFORE first boot →
  ufw 22/80/443 → Docker install → clone → env → up -d --build →
  createsuperuser → seed/bulk content → 8-point verification checklist
  ending in prod smoke WITH the loud smoke-writes-data warning → the
  git-pull update workflow (incl. the one-line-change acceptance loop) →
  pg_dump cron backups (+ managed-Postgres note) → logs. Prerequisite box on
  top: the owner-run compose suite+smoke.

backend_smoke_test.py:
- Profile usage shape now includes "storage".
- After the reclaim check: asserts snapshot max_players == 6, joins Teams
  C–F, asserts the 7th join's 409 is EXACTLY {"detail","code","limit"} with
  game_full/6, asserts reclaim still 200 AT the cap, and asserts
  buzzer_sound in the snapshot with the 1,2,3,4,1,2 round-robin. The extra
  teams only prove the cap — the WS flow continues with Teams A/B unchanged
  (history's participant_count assertion updated 2 → 6 accordingly).
- OPT-IN media round-trip (SMOKE_MEDIA=1 + SMOKE_CREATOR_EMAIL/PASSWORD +
  pip install pillow): uploads a 2600 px photo through the API, asserts the
  URL fetches and the stored object is the resized one (≤ 1920 px, smaller
  than input), asserts signed bucket URLs when the media host differs from
  the app host (Spaces mode), then deletes the rows (frees §F3 quota).
  Default smoke still runs with zero setup. Verified green in BOTH modes
  this session (local disk; s3 via a moto S3 server).

§F1 verification performed this session (no Spaces credentials available; no
Docker for MinIO — used a moto S3-API server, same wire protocol): with
MEDIA_BACKEND=s3 + the explicit env credentials, an uploaded 2600×1400 photo
landed in the bucket under questions/images/, the serialized URL was absolute
and signed with an expiry, the UNSIGNED URL was denied (private ACL), and the
ONLY object ever stored was the already-resized file (11.7 KB vs the 58 KB
input) — resize-before-storage confirmed at the bucket. The owner re-proves
this against real DO Spaces via DEPLOY.md §5–§7 or docker-compose.minio.yml.

Tests (86 → 109, green and warning-free with -W error::RuntimeWarning):
- trivia.MediaProcessingTests (§F2): per-type oversize rejects on the direct
  path with the existing error surface; decompression-bomb fixture (64 MP,
  < 1 MB of bytes) → clean 400 on BOTH entrances, never an OOM; resize to
  ≤ 1920 px + smaller-than-input + JPEG re-encode + EXIF (incl. a GPS tag)
  stripped; EXIF Orientation=6 fixture transposed BEFORE the fit (portrait
  out); PNG-with-alpha stays PNG; small images stored byte-for-byte; the
  same resize through the bulk zip entrance. Existing oversize row-error test
  updated to the new 10 MB ceiling.
- trivia.StorageQuotaTests (§F3): counted from persisted post-resize sizes;
  single-file 403 in EXACTLY the documented shape; PATCH-with-file checked;
  batch 403 carries requested = total batch bytes; deletion frees quota;
  free plan reports storage 0 and is blocked by the questions quota first;
  category photos count.
- games.JoinCapAndSoundTests (§G/§I): 6th join 201, 7th → the exact 409
  shape (int limit — Response, not coerced exception detail); host seat
  excluded from the count; rejoin at cap → 200; name-taken 400 unchanged;
  max_players in the snapshot; round-robin 1,2,3,4,1; buzzer_sound in
  snapshot participants (host seat included) and the join response.

Also:
- .gitignore: + frontend/node_modules/, frontend/dist/ (droplet/build
  hygiene; docker builds them inside the image anyway).

Punted / carried forward additions: SMOKE_MEDIA leaves no rows (it cleans
up), but the media FILES it stores are not deleted (Django never deletes
storage on row delete) — folds into the existing "smoke cleanup pass" item.
Stale media_bytes if a PATCH clears a file via update_fields-less partial
edits is prevented (full saves recount), but a hypothetical
save(update_fields=...) with a fresh file from new code would need
media_bytes added to update_fields — documented in images.prepare_media.


## Session: host-private answers + reveal-for-polling-boards + game history/profile (Handoff #6 §F/§G/§H)

Backend (new):
- backend/games/tests.py — NEW suite (27 tests): the games app's first regression
  gate. §F1 answer endpoint (shape, host-only 403, anon 401, no-cell 409, 404),
  §F2/rule-5 money tests (snapshot `revealed_answer` null → answer → null across
  close and the next opened cell, with the answer string asserted absent from the
  ENTIRE serialized pre-reveal payload), §G1 outcomes (finished_at + winners, tie
  stores all, drinks-mode reading, abandoned games, idempotent finish, finish
  clears reveal), §G2 history (requester-scoped, newest-first, paginated,
  "history" not swallowed by the code route) and report (401/403/404, the pinned
  409-until-finished rule, finished report full detail with answers).
- backend/games/migrations/0002_game_answer_revealed_game_winners.py — adds
  Game.answer_revealed (bool) and Game.winners (M2M → Participant).
- frontend/src/pages/ProfilePage.jsx — NEW /profile route (see Frontend below).

Backend (modified):
- backend/games/models.py — Game.answer_revealed: true only between reveal and
  close_cell (rule 5's one sanctioned snapshot path); Game.winners: outcome
  persisted once at finish, never derived on read; empty = abandoned or no
  players.
- backend/games/services.py — the four live mutations §F/§G touch moved here from
  the consumer (open_cell, reveal_answer, close_cell, finalize_game) so the test
  suite exercises exactly what the socket runs; ActionError moved along (consumer
  re-imports it). open_cell/close_cell now also clear answer_revealed.
  reveal_answer persists the flag and returns the answer text for the unchanged
  WS event; it fetches the cell separately from the locked game row (the
  select_for_update+select_related(nullable FK) Postgres foot-gun from CHANGES).
  finalize_game (§G1): sets finished_at, computes winners = highest `score` among
  role=player participants, ties included, idempotent on repeat finish.
  **Documented drinks-mode winner reading: `score` is the credit side — the
  consumer already adds cell.value to the correct answerer's score on
  assign_drinks ("drinks dealt double as the leaderboard"), so highest score ==
  most drinks dealt; drinks_taken is the penalty side and never decides the
  winner.** Pinned by test_drinks_mode_winner_is_highest_score_credits.
- backend/games/consumers.py — open_cell/close_cell/finish_game delegate to the
  services above (behavior identical + the reveal/winners additions);
  reveal_answer now persists Game.answer_revealed, sends the `answer_reveal`
  event EXACTLY as before (WS boards/hook untouched — §B4-style dual path), and
  then also falls through to the usual snapshot broadcast per the house
  persist-then-broadcast pattern.
- backend/games/serializers.py — GameStateSerializer gains top-level
  `revealed_answer` (SerializerMethodField: the open cell's answer iff
  answer_revealed, else null) — assembled at the snapshot, OpenCellSerializer
  untouched and still answer-free. New purpose-built read serializers, separate
  from the live-snapshot ones: GameHistorySerializer (code, mode, status,
  created_at, finished_at, winners as sorted names, participant_count = player
  seats — the host's control seat is not a team; fed by a view annotation),
  GameReportSerializer (+ ReportColumn/ReportQuestion: participants with final
  tallies, winners as {id, name} for highlight-by-id, and every cell WITH
  question_text + answer + answered_by_name/answered_correctly).
- backend/games/views.py — GameAnswerView: GET /api/games/{code}/answer/ (Knox;
  host-only 403 for any other Knox user, 409 when no cell is open, 404 unknown
  code; works pre-reveal — that's its point; returns {"question_id","answer"}).
  GameHistoryView: GET /api/games/history/ — requester's games, newest-first,
  DRF-paginated, player_count annotation. GameReportView: GET
  /api/games/{code}/report/ — 401 anon, 403 non-host, **chosen non-finished
  behavior: 409 until status == finished** (so a report can never exist for a
  live game and rule 5 can't be violated through it).
- backend/games/urls.py — games/history/ registered BEFORE games/<code>/ so the
  static path can't be swallowed by the code lookup (pinned by test);
  + games/<code>/answer/ and games/<code>/report/.
- backend/accounts/tests.py, backend/trivia/tests.py — docstring run commands
  updated to the canonical `python manage.py test accounts trivia games`.
- backend_smoke_test.py — after open_cell: §F1 round-trip (host 200 with exact
  shape, second Knox user 403, anon 401) and the pre-reveal polled snapshot
  asserted answer-free; after reveal: `revealed_answer` present in the polled
  snapshot (the polling-board path's first live coverage); after close_cell:
  gone again; after finish_game: /api/games/history/ shows the game with
  winners ["Team B"] + participant_count 2, its /report/ carries tallies,
  winners and every answer, and the free user's Knox token 403s on it (anon
  401). rest() now returns both Knox tokens to ws_flow.

Frontend:
- frontend/src/pages/ProfilePage.jsx — NEW /profile (§G3): Knox-gated with the
  SAME login screen as /host (imported AuthScreen, not forked; a 401 mid-visit
  falls back to it since api.js already clears dq_auth). Identity + plan panel
  from GET /api/auth/profile/ with the shared UsageMeterLine (games this month +
  content quotas); game history via allPages (newest-first): code, mode, date,
  status, winners, team count. Selecting a finished game loads its report:
  tallies sorted by score with winner rows highlighted by id, then the full
  board with every question's answer (teal chalk-hand). Non-finished games
  render a "no report — recorded at finish" note and are never fetched (the 409
  route). Chalkboard styling reusing panel/h2/footnote/final__*.
- frontend/src/pages/HostPage.jsx — AuthScreen exported for /profile; Profile
  link in the creation header next to ModerationLink; HostGame takes the Knox
  auth and, when the SNAPSHOT shows a newly opened cell (tracked by cell id —
  rule 1: display data only, all gating still snapshot-derived), fetches
  /answer/ and shows it in a visually distinct dashed-teal card labelled
  "Answer (only you see this)", hidden once the reveal happens (the gold room
  card takes over). Fetch failure keeps the panel fully usable: judging buttons
  live, WS reveal as fallback, inline Retry. Answers are tagged with their cell
  id so a slow response for a closed cell can never render; cleared on close.
  Reveal display + the Reveal-answer button now derive from the snapshot's
  `revealed_answer` with the hook's event value as fallback (hook untouched).
- frontend/src/pages/BoardPage.jsx — reveal derives from the snapshot's
  `revealed_answer` in BOTH transports (rule 1 done properly): polling boards
  finally show reveals; WS boards prefer the field and keep the event-driven
  value as a fallback for older backends, so nothing regresses. Buzzer ignores
  the field (unchanged).
- frontend/src/pages/CreatePage.jsx — meter formatting moved to the shared
  UsageMeterLine (UsageMeters is now a thin wrapper feeding live counts);
  Profile link added to the header.
- frontend/src/components/shared.jsx — ProfileLink; UsageMeterLine (single
  meter renderer for /create and /profile; entries {used, block, noun},
  limit null = unlimited, null used skipped).
- frontend/src/lib/api.js — gameAnswer / gameHistory (allPages) / gameReport.
- frontend/src/styles.css — .answercard--private (+ __err), profile classes
  (.idblock*, .planchip*, .history*, .historyrow*, .report*, .reportq*,
  .final__list--report); existing tokens/classes reused everywhere else.

Docs:
- README.md + prior imperative "Run" lines in this file — canonical test
  command is now `python manage.py test accounts trivia games` (historical
  "Verified:" lines record what was actually run then and are unchanged).

Contracts unchanged (deliberately): OpenCellSerializer still excludes `answer`;
the WS `answer_reveal` event payload is byte-identical; useGameSocket untouched
(rule 2); storage/token contract untouched; quota payloads untouched.

Verified: `python manage.py test accounts trivia games` = 86 tests
(13 accounts + 46 trivia + 27 games) green and the FULL extended smoke suite
green (including the new §F1/§F2/§G live checks), both on the local fallback
(SQLite + in-memory channels). Frontend builds clean (`vite build`).
**⚠️ Compose parity (Postgres + Redis) — including the Handoff #5 backlog — was
NOT run this session: no Docker in the build environment. It remains the open
item from Handoff #5 §C and must be run per the environment-parity rule before
calling this done** (`docker compose cp backend_smoke_test.py api:/tmp/ &&
docker compose exec api sh -c "pip install requests websockets && python
/tmp/backend_smoke_test.py"` after `python manage.py test accounts trivia games`
inside the api container).

Still open / punted (carried forward from Handoff #6 §I): deleting/archiving
hosted games from /profile; player-side history (waits for participant
accounts); everything else in §I unchanged.

## Session: moderation review queue (Handoff #4 §F) + bulk question upload (§G)

Backend (new):
- backend/trivia/moderation.py — staff-only review API (all IsAdminUser):
  GET /api/moderation/{categories,questions}/ (paginated, oldest-first, ?status=
  filter defaulting to pending; detail lookups see every status so double-acting →
  409, not 404), POST …/{id}/approve/ (clears any stale note) and …/{id}/reject/
  (requires non-empty {"note"} → 400 without; writes moderation_note), and
  GET /api/moderation/counts/ for the nav badge. Approving a category does NOT
  touch its questions — every item is vetted separately.
- backend/trivia/bulk_upload.py — CSV parsing/validation for the bulk importer:
  UTF-8 (BOM tolerated), required header, ≤500 rows / ≤1 MB, row numbers 1-based
  including the header and counted by CSV *record* (multi-line quoted cells don't
  skew them), category matched by name (exact then case-insensitive; own > official
  > public precedence, ambiguity → row error), duplicate detection by
  (category, question_text) per owner including intra-file repeats.
- backend/trivia/tests.py — NEW suite (25 tests): every §H case for both features.
  Run `python manage.py test accounts trivia games` (inside compose for parity).

Backend (modified):
- backend/trivia/views.py — POST /api/questions/bulk/ action: parse/validate ALL
  rows, then all-or-nothing in one transaction; row errors → 400 {created: 0,
  errors: [{row, field, message}], skipped}; success → 201; dry_run → 200, nothing
  written; skip_duplicates default true (idempotent re-uploads); batch quota check
  (used + rows_to_create > limit → structured 403 + "requested"), applied on dry
  runs too; official=true is staff-only (else plain-detail 403) and creates
  owner-less public/approved quota-exempt rows against official categories only.
- backend/trivia/models.py — Category.accepts_questions_from(user): the shared
  "may add questions here" rule (official | own | publicly-visible), used by both
  QuestionSerializer.validate and the bulk importer instead of duplicating it.
- backend/trivia/serializers.py — validate() now calls the shared helper;
  ModerationCategorySerializer/ModerationQuestionSerializer add owner_email,
  owner_display_name (+ category_name for questions). Question `answer` stays in
  these — needed for review; OpenCellSerializer still excludes it from snapshots.
- backend/trivia/urls.py — moderation routes registered (counts path + router).
- backend/trivia/permissions.py — IsCreator lets the "bulk" action through like
  "create": the view's quota/staff checks govern it, so free users get the
  structured 403 and free-plan staff can still seed official content.
- backend/accounts/quotas.py — refactored through a shared _denial(user, kind,
  count); quota_denial() unchanged in shape, new batch_quota_denial() adds
  "requested" for bulk (denies when used + count > limit).
- backend/accounts/serializers.py — is_staff exposed read-only on the profile
  (the only accounts change; frontend gates /moderate on it cosmetically).
- backend_smoke_test.py — new live-surface checks: non-staff → 403 on
  /api/moderation/*, free-user bulk CSV dry-run → structured quota 403 with
  "requested", and an optional staff round-trip (reject-needs-note → approve →
  409 on repeat) when SMOKE_STAFF_EMAIL/SMOKE_STAFF_PASSWORD are exported.

Frontend:
- frontend/src/pages/ModeratePage.jsx — NEW /moderate route: tabs
  Categories/Questions with pending counts, cards oldest-first showing question,
  answer, difficulty, category, owner, visibility, and rendered media via
  mediaUrl() (img / audio / video controls); Approve, and Reject with an inline
  required note. Cards leave the list on action; a 409 (another reviewer got
  there first) drops the card and resyncs. Non-staff get a "Staff only" panel;
  plain REST + refresh, no WS.
- frontend/src/pages/CreatePage.jsx — "Bulk upload" panel below the question
  form: picking a file auto-runs a dry_run upload; results render as a summary
  line plus a row/column/problem error table; "Import N questions" does the real
  POST; "Download template" serves /question-template.csv; staff see an
  "Official content" checkbox (toggling re-runs the dry run, since official
  matches official categories only). quotaMessage() now uses "requested"
  ("This file has 60 questions but your plan has 40 left"). Shell shows the
  staff moderation link.
- frontend/src/components/shared.jsx — ModerationLink: /moderate link with the
  pending-count badge (rendered only when profile.is_staff — cosmetic; the
  server enforces IsAdminUser).
- frontend/src/lib/api.js — bulkQuestions, moderationCounts/List/Approve/Reject.
- frontend/src/pages/HostPage.jsx — CreateScreen keeps the full profile (games
  meter derived as before) and shows the moderation link for staff.
- frontend/src/App.jsx — /moderate route.
- frontend/src/styles.css — .pendingbadge, .modcard*, .bulkerrors table,
  .bulksummary, .bulkofficial (chalkboard tokens throughout).
- frontend/public/question-template.csv — NEW downloadable template.

Verified: `python manage.py test accounts trivia` (38 tests) green;
backend_smoke_test.py fully green against a live server including the staff
round-trip branch; §J steps 2–6 walked at the API level (bad-row 400 → fix →
dry-run → import → duplicate skip → moderate reject-with-note visible to owner
→ official upload usable instantly and quota-exempt → non-staff 403).
Still on you per §C/§J: the same two commands through docker compose
(Postgres + Redis), and the §J.1 realtime walkthrough (nothing realtime was
touched, but verify anyway).

---

## Session: paid tiers (Handoff #3 §D) + optional contract repairs (§E)

Backend:
- backend/accounts/models.py — `is_creator` column replaced by `plan` (free/creator) +
  `plan_expires_at`; `is_creator`/`effective_plan` are derived properties (expiry in the
  past collapses to free), so IsCreator and the profile serializer needed no call-site changes.
- backend/accounts/migrations/0002_plan_fields.py — adds fields, backfills
  plan="creator" where is_creator was true, drops the old column (reversible).
- backend/accounts/quotas.py — NEW: all quota counting + the structured 403 payload
  ({detail, code: "quota_*", used, limit}). Views return it via Response(…, 403) rather
  than PermissionDenied(dict) because DRF coerces ints/None in detail dicts to strings.
- backend/config/settings.py — PLAN_LIMITS. Product decision: free games_per_month is
  None (hosting stays ungated, as today); set a number to enable free game limits —
  enforcement/profile/frontend already handle it. Creator: 25 categories / 500 questions.
- backend/trivia/permissions.py — IsCreator is a plan check. POSTs pass through to the
  view's quota gate (free limits are 0), so free users get the structured quota 403;
  updates/deletes still require an active paid plan (plain 403), as before.
- backend/trivia/views.py, backend/games/views.py — quota gates on category/question/game
  creation, checked before validation/uploads.
- backend/accounts/serializers.py — profile now returns plan (the *effective* plan, so
  clients never do expiry math), plan_expires_at, and the usage block from the handoff.
- backend/accounts/admin.py — plan + plan_expires_at editable/filterable; this is the
  manual grant flow now (replaces "tick is_creator"). Derived boolean shown read-only.
- backend/games/consumers.py — §E1: invalid WS token is now accept-then-close 4001
  (was handshake 403 → browser 1006); §E2: incremental {type:"buzz", participant_id,
  name, order} emitted before each post-buzz snapshot. Frontend fallbacks untouched.
- backend/accounts/tests.py — NEW: 13 tests for §D6 (quota shapes, tiny-limit
  boundaries via override_settings, expiry-as-free, profile usage accuracy).
  Run: python manage.py test accounts trivia games

Frontend:
- frontend/src/lib/api.js — quotaError() helper for the structured quota 403s.
- frontend/src/pages/CreatePage.jsx — gate is plan !== "free" (upsell copy unchanged);
  usage meters ("2 of 25 categories · 41 of 500 questions", live counts from the loaded
  lists); quota 403s get friendly limit/upsell copy, other 403s keep the old path.
- frontend/src/pages/HostPage.jsx — creation screen shows "N of M games left this month"
  only when a limit applies (nothing today); quota_games 403 → upgrade copy.

Tests/docs:
- backend_smoke_test.py — new checks: profile shape (D3), free-user structured quota
  403, §E1 close-code 4001 (replaces the handshake-403 assertion), §E2 buzz event.
  Quota *boundaries* live in the Django suite, not here, so repeat runs never trip limits.
- README.md — monetisation section rewritten for the plan model + admin grant flow.

Verified: python manage.py test accounts (13/13) and the full smoke suite green against
a live server. Env-parity note: this session's changes are plain count queries + one
consumer event (no locking/select_related changes), but per the standing rule, run the
suite once through docker compose (Postgres + Redis) before shipping.

---

## Previous session

Backend (two fixes, both verified on real Postgres 16 + Redis):
- backend/games/consumers.py — judge/assign_drinks/close_cell used
  select_for_update().select_related("current_cell"); Postgres rejects FOR UPDATE on the
  nullable side of an outer join, crashing the consumer mid-action (SQLite masked it).
  select_related removed from the three locking queries; semantics unchanged.
- backend/requirements.txt — pins redis>=4.6,<8 (redis-py 8 crashes channels-redis
  consumers after ~20s idle: "Timeout reading from redis:6379").

Apply both with: docker compose up --build

New:
- HANDOFF_3.md — next-chat handoff: both production incidents + environment-parity rule,
  frontend socket-lifecycle fix, paid-tier spec, remaining items, smoke tests
- frontend/src/pages/CreatePage.jsx — creator content UI (/create)
- backend_smoke_test.py — automated REST+WS end-to-end test (point DATABASE_URL/REDIS_URL
  at real services for production parity)

Modified (frontend):
- frontend/src/lib/useGameSocket.js — REWRITTEN: single-socket lifecycle, invalid-token
  detection (rejected-handshake + REST probe), lastBuzz from snapshot diffs
- frontend/src/pages/HostPage.jsx — "Your content" link; "Reconnecting — controls paused"
  banner whenever the socket is down
- frontend/src/lib/api.js — allPages() pagination, content update/delete helpers,
  401 clears stored Knox auth
- frontend/src/App.jsx — /create route; landing join-code validation
- frontend/src/styles.css — chalkboard restyle + /create styles + reconnect banner
- frontend/index.html — Bebas Neue + Caveat fonts; theme-color
- frontend/README.md — backend deviations, /create docs

After unzipping: docker compose up --build
Then: cd frontend && npm install && npm run dev
