# Deploying Drinkquiry to production (DigitalOcean droplet, HTTPS)

Handoff #7 §H. Target: `https://<your-domain>` serving the SPA, the API,
`/admin`, and working `wss://` buzzers, all from one droplet running the
`docker-compose.prod.yml` stack (Postgres + Redis + Django/daphne + Caddy).
Caddy obtains and renews the Let's Encrypt certificate automatically.

Assumes a competent dev who hasn't done this exact stack. Every command block
is copy-pasteable. Jenkins/CI deploys are punted — the manual
`git pull && rebuild` loop below IS the deliverable.

> **Prerequisite from the handoff:** run the Django suite AND
> `backend_smoke_test.py` through docker compose (Postgres + Redis) on your
> dev machine first, so the prod stack isn't the first-ever Redis smoke:
>
> ```bash
> docker compose up -d --build
> docker compose exec api python manage.py test accounts trivia games
> docker compose cp backend_smoke_test.py api:/tmp/ && \
>   docker compose exec api sh -c "pip install requests websockets && python /tmp/backend_smoke_test.py"
> ```

## 1. Create the droplet

- DigitalOcean → Create → Droplet. **Ubuntu 24.04 LTS**, Basic, **2 GB RAM**
  is plenty (1 GB works but docker builds get tight). Add your SSH key.
- Note the droplet's public IP.

## 2. DNS

Create an **A record** for your domain (e.g. `quiz.example.com`) pointing at
the droplet IP. Do this BEFORE first start — Caddy requests the certificate
on boot and Let's Encrypt must be able to resolve and reach the name.
Check it resolves: `dig +short quiz.example.com`.

## 3. Firewall

```bash
ssh root@<droplet-ip>
ufw allow 22/tcp
ufw allow 80/tcp     # Let's Encrypt HTTP challenge + https redirect
ufw allow 443/tcp
ufw enable
```

## 4. Install Docker + the compose plugin

```bash
apt-get update
apt-get install -y ca-certificates curl git
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
  https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" \
  > /etc/apt/sources.list.d/docker.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
```

## 5. Clone and configure

```bash
git clone <your-repo-url> /opt/drinkquiry
cd /opt/drinkquiry
cp .env.production.example .env
nano .env
```

Fill in **every** value — the file documents each one. Non-negotiables:

- `DOMAIN` — your real domain.
- `DJANGO_SECRET_KEY` — generate:
  `python3 -c "import secrets; print(secrets.token_urlsafe(64))"`.
- `DJANGO_DEBUG=false`, `DJANGO_ALLOWED_HOSTS=<domain>`,
  `CSRF_TRUSTED_ORIGINS=https://<domain>`, `DJANGO_BEHIND_PROXY=true`.
- `POSTGRES_PASSWORD` — anything long and random (compose refuses to start
  without it).
- Media: `MEDIA_BACKEND=s3` + the Spaces block (recommended — media survives
  droplet rebuilds), or `MEDIA_BACKEND=local` to keep uploads in a docker
  volume served by Caddy at `/media`.

HTTPS is not optional here: Knox host tokens and participant seat tokens ride
every request and WS handshake, and the frontend's `WS_BASE` derives `wss:`
from the `https:` page origin automatically.

### ⚠️ Turnstile: THREE env names, TWO halves, or registration breaks

Handoff #12 added Cloudflare Turnstile on **register** (opt-in). It is a
**coupled pair** — a backend secret and a frontend build-time key — and the
single most likely way to break production sign-ups is shipping one half
without the other. All three names, in one place:

| Name | Where it lives | What it does |
| --- | --- | --- |
| `TURNSTILE_SECRET_KEY` | `.env` (backend) | Turns the feature ON. When set, register **requires** a valid token and verification **fails CLOSED** (Cloudflare unreachable ⇒ registration refused, never waved through). |
| `TURNSTILE_SITE_KEY` | `.env` (backend) | The public widget key's server-side copy (kept for future serving; harmless but set it). |
| `VITE_TURNSTILE_SITE_KEY` | **frontend build env** | Baked into the SPA **at build time** (the `VITE_API_BASE` pattern). Without it the register form never renders the widget, never sends a token — and with the secret set, every sign-up 400s. |

The failure mode to burn in: **backend secret set + frontend built without
the VITE var = nobody can register**, and nothing errors until a real person
tries. The reverse (VITE set, secret unset) is merely cosmetic: the widget
renders and the token is sent, but the backend ignores it while the feature
is off. So the rule is one-directional and simple:

> **If `TURNSTILE_SECRET_KEY` is in `.env`, every production frontend build
> — including every rebuild in step 8 — MUST carry
> `VITE_TURNSTILE_SITE_KEY`.** Put it next to `VITE_API_BASE` wherever your
> frontend build gets its env (the compose web-image build args), and it
> rides every rebuild for free.

Dev, the Django suite and `backend_smoke_test.py` all run **keyless** (both
default `""`, feature entirely absent) — zero setup for local work, and the
smoke never needs a Turnstile token. Widget creation itself (free) is in the
Cloudflare dashboard → Turnstile; CHANGES.md #12 has the walk-through.

### DigitalOcean Spaces setup (when `MEDIA_BACKEND=s3`)

1. DO control panel → Spaces → Create Space (same region as the droplet,
   e.g. `nyc3`). Leave file listing OFF (the app uses signed URLs; objects
   are uploaded with a private ACL).
2. API → Spaces Keys → Generate New Key → put the pair in
   `AWS_S3_ACCESS_KEY_ID` / `AWS_S3_SECRET_ACCESS_KEY`.
3. `AWS_S3_ENDPOINT_URL=https://<region>.digitaloceanspaces.com` (the region
   endpoint, NOT the bucket subdomain), `AWS_S3_REGION_NAME=<region>`,
   `AWS_STORAGE_BUCKET_NAME=<space name>`.

**Signed URLs & expiry:** with the private ACL + `querystring_auth`, every
media URL in a snapshot is a signed URL with an expiry (default 1 h,
`AWS_QUERYSTRING_EXPIRE`). This is a non-issue in practice: polling boards
refetch the snapshot every 1.5 s and WS boards receive a fresh snapshot on
every mutation, so clients always hold young URLs. `/media` on the proxy is
simply never used in this mode (media URLs point at the bucket).

## 6. First start

```bash
cd /opt/drinkquiry
docker compose -f docker-compose.prod.yml up -d --build
docker compose -f docker-compose.prod.yml logs -f web api   # watch first boot
```

The api entrypoint migrates and collects static before daphne starts; Caddy
fetches the certificate on its first request cycle (seconds, if DNS is
right). Then:

```bash
docker compose -f docker-compose.prod.yml exec api python manage.py createsuperuser
```

Load content — either the demo seed:

```bash
docker compose -f docker-compose.prod.yml exec api python manage.py seed_demo
```

…or real content: promote your account's plan in `/admin` (or use the
superuser) and run a bulk upload from `/create`.

## 7. Verification checklist

Work through ALL of these before calling it live:

1. `https://<domain>` loads the SPA; `http://` redirects to `https://`.
2. Hard-reload a deep route (`https://<domain>/host`) — the SPA must come
   back, not a 404 (Caddy's `try_files` fallback).
3. `https://<domain>/admin/` — log in as the superuser (exercises static
   files, CSRF_TRUSTED_ORIGINS and the proxy-SSL header at once).
4. Host a full game: log in at `/host`, create a game, open
   `/board/<CODE>` on a TV/laptop, join from a REAL PHONE on mobile data
   (not the droplet's network) at `/game/buzzer/<CODE>` — the buzz must land
   over `wss://` and flash the board.
5. Media: upload a large phone photo to a question in `/create`; confirm it
   renders on the board and (Spaces mode) that the image URL in devtools
   points at `…digitaloceanspaces.com…` with signature query params, and
   that the object appears in the Space at `questions/images/…` already
   resized (≤ 1920 px).
6. Join 6 teams; a 7th phone gets the friendly "table's full" screen; one of
   the 6 reloads mid-game and reclaims its seat.
7. Board sound toggled on: different teams' buzzes play different sounds.
8. Prod smoke, from your machine:

   ```bash
   SMOKE_BASE=https://<domain> SMOKE_ORIGIN=https://<domain> python backend_smoke_test.py
   ```

   > ⚠️ **The smoke test WRITES real rows into the production database** —
   > test accounts (`host@test.com`, `free-…@test.com`) and a finished test
   > game with fake teams. That's fine (useful, even) BEFORE launch; think
   > twice about running it against a live database people are using, or
   > clean up after it in `/admin`.

## 8. Updating (the whole deploy workflow)

```bash
ssh root@<droplet-ip>
cd /opt/drinkquiry
git pull
docker compose -f docker-compose.prod.yml up -d --build
```

That's it — the entrypoint migrates on start, the web image rebuild picks up
any frontend change (the SPA is baked into the Caddy image, so a rebuild is
the ship). Confirm with the one-line-change loop once: edit any visible
frontend string, pull + rebuild, hard-refresh the browser.

> **Turnstile reminder (see §5):** if `TURNSTILE_SECRET_KEY` is in `.env`,
> this rebuild — like every rebuild — must carry `VITE_TURNSTILE_SITE_KEY`
> in the frontend build env, or the fresh SPA ships without the widget and
> registration breaks silently.

## 9. Backups (minimum viable)

`pgdata` is a docker volume on the droplet — a dead droplet loses it. The
floor is a nightly `pg_dump` on the droplet:

```bash
mkdir -p /opt/drinkquiry-backups
crontab -e
# add:
15 4 * * * cd /opt/drinkquiry && docker compose -f docker-compose.prod.yml exec -T db pg_dump -U drinkquiry drinkquiry | gzip > /opt/drinkquiry-backups/db-$(date +\%F).sql.gz && ls -t /opt/drinkquiry-backups/db-*.sql.gz | tail -n +15 | xargs -r rm
```

(That keeps 14 days.) The grown-up option later is DO **Managed Postgres**
(point `DATABASE_URL` at it in `.env` and drop the db service) plus DO's
droplet backups; Spaces media is already off-droplet.

**The MEDIA story (Handoff #12 §J3 — owner-run, untestable from the
sandbox).** The dump above is the DATABASE only. In local media mode the
`backend/media/` volume holds every question image/audio/video, category
photo and brand logo — it needs its own nightly copy (e.g. add
`&& tar czf /opt/drinkquiry-backups/media-$(date +\%F).tgz -C /opt/drinkquiry/backend media`
to the cron line, or rsync it off-droplet). In S3/Spaces mode, turn ON
**bucket versioning** in the Spaces settings instead — that's the media
backup. Retention on all of it is the owner's call.

**Restore** is the two halves back together: `gunzip -c db-YYYY-MM-DD.sql.gz
| docker compose -f docker-compose.prod.yml exec -T db psql -U drinkquiry
drinkquiry` into a FRESH database, plus untarring the matching media copy
back into place (or nothing, in Spaces mode — the bucket is the media).

## 9c. Uptime monitoring (Handoff #12 §J4)

Point any free monitor (UptimeRobot et al.) at `GET /api/health/` — it
exists precisely for this. Expected body: `{"status": "ok"}` (a failing DB
or Redis turns it into a 503 `{"status": "degraded", ...}`, which is
exactly what you want paged on).

## 9b. Hardening pass (Handoff #10 §I) — three owner decisions

**Health check.** `GET /api/health/` (no auth) answers `{"status": "ok"}`
after probing the DB and (when `REDIS_URL` is set) the cache; any failing
dependency turns it into a 503 `{"status": "degraded", ...}`. The compose
files now use it as the `api` service's healthcheck — after a deploy,
`docker compose -f docker-compose.prod.yml ps` should show the api
`(healthy)`. It's also the right target for any external uptime monitor.
NOTE (#14b): the in-container probe sends `Host: localhost:8000`, so
`DJANGO_ALLOWED_HOSTS` must include `localhost` (see
`.env.production.example`) or every probe 400s and the container reads
(unhealthy) forever.

**Auth throttling & X-Forwarded-For (confirm once).** login/register/
password-forgot/password-reset are now rate-limited per client IP (10/min
login, 5/min the rest; 429 past the limit). Behind Caddy the client IP is
read from `X-Forwarded-For`, gated on the same `DJANGO_BEHIND_PROXY=true`
you already set. Caddy's default `reverse_proxy` sends the header, and this
repo's Caddyfile uses the default — but confirm after deploy: hammer
`/api/auth/login/` 11× from ONE machine (expect a 429) while a second
machine still gets 400s. If instead the second machine is 429'd too, the
header isn't arriving and the whole site is being counted as one IP — fix
the proxy config before anything else. Game join and the board snapshot are
deliberately NOT throttled (a bar full of phones is one NAT IP).

**HSTS (your flag, one-way door).** `python manage.py check --deploy` will
keep suggesting HSTS. It's off by default because browsers pin https for the
whole max-age — turning it on with any http dependency left breaks that
dependency for every visitor until the timer runs out. Once you're confident
everything is https-only, set `SECURE_HSTS_SECONDS=31536000` in `.env`
(optionally `SECURE_HSTS_INCLUDE_SUBDOMAINS=true`) and redeploy.

**Media-bucket lifecycle (still manual ops).** Spaces has no automatic
pruning here: soft-deleted questions/categories keep their files by design
(history), so the bucket only grows. Fine for now; revisit with a lifecycle
rule or an orphan-sweep script when it matters.

## 10. Logs & poking around

```bash
docker compose -f docker-compose.prod.yml logs -f api    # Django/daphne
docker compose -f docker-compose.prod.yml logs -f web    # Caddy (TLS issuance lives here)
docker compose -f docker-compose.prod.yml exec api python manage.py shell
```

## Appendix: verifying s3 mode locally without Spaces

`docker-compose.minio.yml` (opt-in overlay, documented inside the file) runs
MinIO and flips the dev api into s3 mode against it — same code path as
Spaces, zero cost. This session also verified the s3 backend end-to-end
against an S3-API server (object lands in the bucket, serialized URLs are
signed + absolute, unsigned reads are denied, and the stored object is the
already-resized file). The Spaces steps in §5–§7 above re-run that proof
against the real thing.
